// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* gdn_impl_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_gdn_impl(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_gdn_impl(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[13];
  void* stack_ffi_any = stack;
  if (!((num_args == 9))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "gdn_impl: num_args should be 9", (long long)(num_args), (long long)(9));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_impl: args pointer is NULL");
    return -1;
  }
  int32_t Q_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((Q_handle_type_index == 0) || (Q_handle_type_index == 4)) || (Q_handle_type_index == 7)) || (64 <= Q_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input Q expected pointer or tensor handle");
    return -1;
  }
  int32_t K_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((K_handle_type_index == 0) || (K_handle_type_index == 4)) || (K_handle_type_index == 7)) || (64 <= K_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input K expected pointer or tensor handle");
    return -1;
  }
  int32_t V_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((V_handle_type_index == 0) || (V_handle_type_index == 4)) || (V_handle_type_index == 7)) || (64 <= V_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input V expected pointer or tensor handle");
    return -1;
  }
  int32_t G_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((G_handle_type_index == 0) || (G_handle_type_index == 4)) || (G_handle_type_index == 7)) || (64 <= G_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input G expected pointer or tensor handle");
    return -1;
  }
  int32_t Beta_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((Beta_handle_type_index == 0) || (Beta_handle_type_index == 4)) || (Beta_handle_type_index == 7)) || (64 <= Beta_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input Beta expected pointer or tensor handle");
    return -1;
  }
  int32_t H0_handle_type_index = (((TVMFFIAny*)args)[5].type_index);
  if (!(((((H0_handle_type_index == 0) || (H0_handle_type_index == 4)) || (H0_handle_type_index == 7)) || (64 <= H0_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input H0 expected pointer or tensor handle");
    return -1;
  }
  int32_t Hist_handle_type_index = (((TVMFFIAny*)args)[6].type_index);
  if (!(((((Hist_handle_type_index == 0) || (Hist_handle_type_index == 4)) || (Hist_handle_type_index == 7)) || (64 <= Hist_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input Hist expected pointer or tensor handle");
    return -1;
  }
  int32_t Sout_handle_type_index = (((TVMFFIAny*)args)[7].type_index);
  if (!(((((Sout_handle_type_index == 0) || (Sout_handle_type_index == 4)) || (Sout_handle_type_index == 7)) || (64 <= Sout_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input Sout expected pointer or tensor handle");
    return -1;
  }
  int32_t O_handle_type_index = (((TVMFFIAny*)args)[8].type_index);
  if (!(((((O_handle_type_index == 0) || (O_handle_type_index == 4)) || (O_handle_type_index == 7)) || (64 <= O_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input O expected pointer or tensor handle");
    return -1;
  }
  void* Q_handle = ((Q_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* K_handle = ((K_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* V_handle = ((V_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* G_handle = ((G_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* Beta_handle = ((Beta_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  void* H0_handle = ((H0_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[5].v_ptr) + 24)) : (((TVMFFIAny*)args)[5].v_ptr));
  void* Hist_handle = ((Hist_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[6].v_ptr) + 24)) : (((TVMFFIAny*)args)[6].v_ptr));
  void* Sout_handle = ((Sout_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[7].v_ptr) + 24)) : (((TVMFFIAny*)args)[7].v_ptr));
  void* O_handle = ((O_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[8].v_ptr) + 24)) : (((TVMFFIAny*)args)[8].v_ptr));
  bool gdn_impl_Q_is_null = (Q_handle == NULL);
  if (!(!gdn_impl_Q_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_impl.Q is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_impl_K_is_null = (K_handle == NULL);
  if (!(!gdn_impl_K_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_impl.K is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_impl_V_is_null = (V_handle == NULL);
  if (!(!gdn_impl_V_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_impl.V is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_impl_G_is_null = (G_handle == NULL);
  if (!(!gdn_impl_G_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_impl.G is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_impl_Beta_is_null = (Beta_handle == NULL);
  if (!(!gdn_impl_Beta_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_impl.Beta is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_impl_H0_is_null = (H0_handle == NULL);
  if (!(!gdn_impl_H0_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_impl.H0 is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_impl_Hist_is_null = (Hist_handle == NULL);
  if (!(!gdn_impl_Hist_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_impl.Hist is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_impl_Sout_is_null = (Sout_handle == NULL);
  if (!(!gdn_impl_Sout_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_impl.Sout is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_impl_O_is_null = (O_handle == NULL);
  if (!(!gdn_impl_O_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_impl.O is expected to have non-NULL pointer");
    return -1;
  }
  void* gdn_impl_Q_shape = (((DLTensor*)Q_handle)[0].shape);
  void* gdn_impl_K_shape = (((DLTensor*)K_handle)[0].shape);
  void* gdn_impl_V_shape = (((DLTensor*)V_handle)[0].shape);
  void* gdn_impl_G_shape = (((DLTensor*)G_handle)[0].shape);
  void* gdn_impl_Beta_shape = (((DLTensor*)Beta_handle)[0].shape);
  void* gdn_impl_H0_shape = (((DLTensor*)H0_handle)[0].shape);
  void* gdn_impl_Hist_shape = (((DLTensor*)Hist_handle)[0].shape);
  void* gdn_impl_Sout_shape = (((DLTensor*)Sout_handle)[0].shape);
  void* gdn_impl_O_shape = (((DLTensor*)O_handle)[0].shape);
  if (!(((((DLTensor*)Q_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Q ndim mismatch, expected 3", (long long)((((DLTensor*)Q_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable seq requires at least one non-null buffer among: gdn_impl.Q, gdn_impl.K, gdn_impl.V, gdn_impl.G, gdn_impl.Beta, gdn_impl.Hist, gdn_impl.O");
    return -1;
  }
  int32_t seq = ((int32_t)((int64_t*)gdn_impl_Q_shape)[1]);
  void* gdn_impl_Q_strides = (((DLTensor*)Q_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)Q_handle)[0].device.device_id);
  void* Q = (((DLTensor*)Q_handle)[0].data);
  if (!(((((DLTensor*)K_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input K ndim mismatch, expected 3", (long long)((((DLTensor*)K_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_impl_K_strides = (((DLTensor*)K_handle)[0].strides);
  void* K = (((DLTensor*)K_handle)[0].data);
  if (!(((((DLTensor*)V_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input V ndim mismatch, expected 3", (long long)((((DLTensor*)V_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_impl_V_strides = (((DLTensor*)V_handle)[0].strides);
  void* V = (((DLTensor*)V_handle)[0].data);
  if (!(((((DLTensor*)G_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input G ndim mismatch, expected 3", (long long)((((DLTensor*)G_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_impl_G_strides = (((DLTensor*)G_handle)[0].strides);
  void* G = (((DLTensor*)G_handle)[0].data);
  if (!(((((DLTensor*)Beta_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Beta ndim mismatch, expected 2", (long long)((((DLTensor*)Beta_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_impl_Beta_strides = (((DLTensor*)Beta_handle)[0].strides);
  void* Beta = (((DLTensor*)Beta_handle)[0].data);
  if (!(((((DLTensor*)H0_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input H0 ndim mismatch, expected 3", (long long)((((DLTensor*)H0_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_impl_H0_strides = (((DLTensor*)H0_handle)[0].strides);
  void* H0 = (((DLTensor*)H0_handle)[0].data);
  if (!(((((DLTensor*)Hist_handle)[0].ndim) == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Hist ndim mismatch, expected 4", (long long)((((DLTensor*)Hist_handle)[0].ndim)), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_impl_Hist_strides = (((DLTensor*)Hist_handle)[0].strides);
  void* Hist = (((DLTensor*)Hist_handle)[0].data);
  if (!(((((DLTensor*)Sout_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Sout ndim mismatch, expected 3", (long long)((((DLTensor*)Sout_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_impl_Sout_strides = (((DLTensor*)Sout_handle)[0].strides);
  void* Sout = (((DLTensor*)Sout_handle)[0].data);
  if (!(((((DLTensor*)O_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input O ndim mismatch, expected 3", (long long)((((DLTensor*)O_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_impl_O_strides = (((DLTensor*)O_handle)[0].strides);
  void* O = (((DLTensor*)O_handle)[0].data);
  if (!(((((((DLTensor*)Q_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Q_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Q_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input Q dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_Q_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Q shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_Q_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_Q_shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Q shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_Q_shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval;
  if ((gdn_impl_Q_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)gdn_impl_Q_strides)[2]);
  }
  if (!((condval == 1))) {
    int32_t condval_1;
    if ((gdn_impl_Q_strides == NULL)) {
      condval_1 = 1;
    } else {
      condval_1 = ((int32_t)((int64_t*)gdn_impl_Q_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Q strides[2] violates packed ABI constraint", (long long)(condval_1), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((gdn_impl_Q_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)gdn_impl_Q_strides)[1]);
  }
  if (!(((condval_2 == 16) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input Q strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_3;
  if ((gdn_impl_Q_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)gdn_impl_Q_strides)[0]);
  }
  if (!((((seq * 16) == condval_3) || (seq == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input Q strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Q_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Q byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Q_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Q_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Q device_type mismatch, expected ext_dev", (long long)((((DLTensor*)Q_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(Q == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input Q data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)K_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)K_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)K_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input K dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_K_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input K shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_K_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_Q_shape)[1]) == ((int32_t)((int64_t*)gdn_impl_K_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input K shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_Q_shape)[1])), (long long)(((int32_t)((int64_t*)gdn_impl_K_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_K_shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input K shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_K_shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_4;
  if ((gdn_impl_K_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)gdn_impl_K_strides)[2]);
  }
  if (!((condval_4 == 1))) {
    int32_t condval_5;
    if ((gdn_impl_K_strides == NULL)) {
      condval_5 = 1;
    } else {
      condval_5 = ((int32_t)((int64_t*)gdn_impl_K_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input K strides[2] violates packed ABI constraint", (long long)(condval_5), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_6;
  if ((gdn_impl_K_strides == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)gdn_impl_K_strides)[1]);
  }
  if (!(((condval_6 == 16) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input K strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_7;
  if ((gdn_impl_K_strides == NULL)) {
    condval_7 = 1;
  } else {
    condval_7 = ((int32_t)((int64_t*)gdn_impl_K_strides)[0]);
  }
  if (!((((seq * 16) == condval_7) || (seq == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input K strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)K_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input K byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)K_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)K_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input K device_id violates packed ABI constraint", (long long)((((DLTensor*)K_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)K_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input K device_type mismatch, expected ext_dev", (long long)((((DLTensor*)K_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(K == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input K data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)V_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)V_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)V_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input V dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_V_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input V shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_V_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_Q_shape)[1]) == ((int32_t)((int64_t*)gdn_impl_V_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input V shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_Q_shape)[1])), (long long)(((int32_t)((int64_t*)gdn_impl_V_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_V_shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input V shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_V_shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_8;
  if ((gdn_impl_V_strides == NULL)) {
    condval_8 = 1;
  } else {
    condval_8 = ((int32_t)((int64_t*)gdn_impl_V_strides)[2]);
  }
  if (!((condval_8 == 1))) {
    int32_t condval_9;
    if ((gdn_impl_V_strides == NULL)) {
      condval_9 = 1;
    } else {
      condval_9 = ((int32_t)((int64_t*)gdn_impl_V_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input V strides[2] violates packed ABI constraint", (long long)(condval_9), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_10;
  if ((gdn_impl_V_strides == NULL)) {
    condval_10 = 1;
  } else {
    condval_10 = ((int32_t)((int64_t*)gdn_impl_V_strides)[1]);
  }
  if (!(((condval_10 == 16) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input V strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_11;
  if ((gdn_impl_V_strides == NULL)) {
    condval_11 = 1;
  } else {
    condval_11 = ((int32_t)((int64_t*)gdn_impl_V_strides)[0]);
  }
  if (!((((seq * 16) == condval_11) || (seq == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input V strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)V_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input V byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)V_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)V_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input V device_id violates packed ABI constraint", (long long)((((DLTensor*)V_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)V_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input V device_type mismatch, expected ext_dev", (long long)((((DLTensor*)V_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(V == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input V data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)G_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)G_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)G_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input G dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_G_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input G shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_G_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_Q_shape)[1]) == ((int32_t)((int64_t*)gdn_impl_G_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input G shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_Q_shape)[1])), (long long)(((int32_t)((int64_t*)gdn_impl_G_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_G_shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input G shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_G_shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_12;
  if ((gdn_impl_G_strides == NULL)) {
    condval_12 = 1;
  } else {
    condval_12 = ((int32_t)((int64_t*)gdn_impl_G_strides)[2]);
  }
  if (!((condval_12 == 1))) {
    int32_t condval_13;
    if ((gdn_impl_G_strides == NULL)) {
      condval_13 = 1;
    } else {
      condval_13 = ((int32_t)((int64_t*)gdn_impl_G_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input G strides[2] violates packed ABI constraint", (long long)(condval_13), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_14;
  if ((gdn_impl_G_strides == NULL)) {
    condval_14 = 1;
  } else {
    condval_14 = ((int32_t)((int64_t*)gdn_impl_G_strides)[1]);
  }
  if (!(((condval_14 == 16) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input G strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_15;
  if ((gdn_impl_G_strides == NULL)) {
    condval_15 = 1;
  } else {
    condval_15 = ((int32_t)((int64_t*)gdn_impl_G_strides)[0]);
  }
  if (!((((seq * 16) == condval_15) || (seq == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input G strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)G_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input G byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)G_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)G_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input G device_id violates packed ABI constraint", (long long)((((DLTensor*)G_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)G_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input G device_type mismatch, expected ext_dev", (long long)((((DLTensor*)G_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(G == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input G data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Beta_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Beta_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Beta_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input Beta dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_Beta_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Beta shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_Beta_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_Q_shape)[1]) == ((int32_t)((int64_t*)gdn_impl_Beta_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Beta shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_Q_shape)[1])), (long long)(((int32_t)((int64_t*)gdn_impl_Beta_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_16;
  if ((gdn_impl_Beta_strides == NULL)) {
    condval_16 = 1;
  } else {
    condval_16 = ((int32_t)((int64_t*)gdn_impl_Beta_strides)[1]);
  }
  if (!(((condval_16 == 1) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input Beta strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_17;
  if ((gdn_impl_Beta_strides == NULL)) {
    condval_17 = 1;
  } else {
    condval_17 = ((int32_t)((int64_t*)gdn_impl_Beta_strides)[0]);
  }
  if (!(((((int32_t)((int64_t*)gdn_impl_Q_shape)[1]) == condval_17) || (((int32_t)((int64_t*)gdn_impl_Q_shape)[1]) == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input Beta strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Beta_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Beta byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Beta_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Beta_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Beta device_id violates packed ABI constraint", (long long)((((DLTensor*)Beta_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Beta_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Beta device_type mismatch, expected ext_dev", (long long)((((DLTensor*)Beta_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(Beta == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input Beta data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)H0_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)H0_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)H0_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input H0 dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_H0_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input H0 shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_H0_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_H0_shape)[1]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input H0 shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_H0_shape)[1])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_H0_shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input H0 shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_H0_shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_18;
  if ((gdn_impl_H0_strides == NULL)) {
    condval_18 = 1;
  } else {
    condval_18 = ((int32_t)((int64_t*)gdn_impl_H0_strides)[2]);
  }
  if (!((condval_18 == 1))) {
    int32_t condval_19;
    if ((gdn_impl_H0_strides == NULL)) {
      condval_19 = 1;
    } else {
      condval_19 = ((int32_t)((int64_t*)gdn_impl_H0_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input H0 strides[2] violates packed ABI constraint", (long long)(condval_19), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_20;
  if ((gdn_impl_H0_strides == NULL)) {
    condval_20 = 1;
  } else {
    condval_20 = ((int32_t)((int64_t*)gdn_impl_H0_strides)[1]);
  }
  if (!((condval_20 == 16))) {
    int32_t condval_21;
    if ((gdn_impl_H0_strides == NULL)) {
      condval_21 = 1;
    } else {
      condval_21 = ((int32_t)((int64_t*)gdn_impl_H0_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input H0 strides[1] violates packed ABI constraint", (long long)(condval_21), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_22;
  if ((gdn_impl_H0_strides == NULL)) {
    condval_22 = 1;
  } else {
    condval_22 = ((int32_t)((int64_t*)gdn_impl_H0_strides)[0]);
  }
  if (!((condval_22 == 256))) {
    int32_t condval_23;
    if ((gdn_impl_H0_strides == NULL)) {
      condval_23 = 1;
    } else {
      condval_23 = ((int32_t)((int64_t*)gdn_impl_H0_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input H0 strides[0] violates packed ABI constraint", (long long)(condval_23), (long long)(256));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)H0_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input H0 byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)H0_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)H0_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input H0 device_id violates packed ABI constraint", (long long)((((DLTensor*)H0_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)H0_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input H0 device_type mismatch, expected ext_dev", (long long)((((DLTensor*)H0_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(H0 == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input H0 data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Hist_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Hist_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Hist_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input Hist dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_Hist_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Hist shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_Hist_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_Q_shape)[1]) == ((int32_t)((int64_t*)gdn_impl_Hist_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Hist shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_Q_shape)[1])), (long long)(((int32_t)((int64_t*)gdn_impl_Hist_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_Hist_shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Hist shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_Hist_shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_Hist_shape)[3]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Hist shape[3] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_Hist_shape)[3])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_24;
  if ((gdn_impl_Hist_strides == NULL)) {
    condval_24 = 1;
  } else {
    condval_24 = ((int32_t)((int64_t*)gdn_impl_Hist_strides)[3]);
  }
  if (!((condval_24 == 1))) {
    int32_t condval_25;
    if ((gdn_impl_Hist_strides == NULL)) {
      condval_25 = 1;
    } else {
      condval_25 = ((int32_t)((int64_t*)gdn_impl_Hist_strides)[3]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Hist strides[3] violates packed ABI constraint", (long long)(condval_25), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_26;
  if ((gdn_impl_Hist_strides == NULL)) {
    condval_26 = 1;
  } else {
    condval_26 = ((int32_t)((int64_t*)gdn_impl_Hist_strides)[2]);
  }
  if (!((condval_26 == 16))) {
    int32_t condval_27;
    if ((gdn_impl_Hist_strides == NULL)) {
      condval_27 = 1;
    } else {
      condval_27 = ((int32_t)((int64_t*)gdn_impl_Hist_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Hist strides[2] violates packed ABI constraint", (long long)(condval_27), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_28;
  if ((gdn_impl_Hist_strides == NULL)) {
    condval_28 = 1;
  } else {
    condval_28 = ((int32_t)((int64_t*)gdn_impl_Hist_strides)[1]);
  }
  if (!(((condval_28 == 256) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input Hist strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_29;
  if ((gdn_impl_Hist_strides == NULL)) {
    condval_29 = 1;
  } else {
    condval_29 = ((int32_t)((int64_t*)gdn_impl_Hist_strides)[0]);
  }
  if (!((((seq * 256) == condval_29) || (seq == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input Hist strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Hist_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Hist byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Hist_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Hist_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Hist device_id violates packed ABI constraint", (long long)((((DLTensor*)Hist_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Hist_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Hist device_type mismatch, expected ext_dev", (long long)((((DLTensor*)Hist_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(Hist == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input Hist data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Sout_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Sout_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Sout_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input Sout dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_Sout_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Sout shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_Sout_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_Sout_shape)[1]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Sout shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_Sout_shape)[1])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_Sout_shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Sout shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_Sout_shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_30;
  if ((gdn_impl_Sout_strides == NULL)) {
    condval_30 = 1;
  } else {
    condval_30 = ((int32_t)((int64_t*)gdn_impl_Sout_strides)[2]);
  }
  if (!((condval_30 == 1))) {
    int32_t condval_31;
    if ((gdn_impl_Sout_strides == NULL)) {
      condval_31 = 1;
    } else {
      condval_31 = ((int32_t)((int64_t*)gdn_impl_Sout_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Sout strides[2] violates packed ABI constraint", (long long)(condval_31), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_32;
  if ((gdn_impl_Sout_strides == NULL)) {
    condval_32 = 1;
  } else {
    condval_32 = ((int32_t)((int64_t*)gdn_impl_Sout_strides)[1]);
  }
  if (!((condval_32 == 16))) {
    int32_t condval_33;
    if ((gdn_impl_Sout_strides == NULL)) {
      condval_33 = 1;
    } else {
      condval_33 = ((int32_t)((int64_t*)gdn_impl_Sout_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Sout strides[1] violates packed ABI constraint", (long long)(condval_33), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_34;
  if ((gdn_impl_Sout_strides == NULL)) {
    condval_34 = 1;
  } else {
    condval_34 = ((int32_t)((int64_t*)gdn_impl_Sout_strides)[0]);
  }
  if (!((condval_34 == 256))) {
    int32_t condval_35;
    if ((gdn_impl_Sout_strides == NULL)) {
      condval_35 = 1;
    } else {
      condval_35 = ((int32_t)((int64_t*)gdn_impl_Sout_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Sout strides[0] violates packed ABI constraint", (long long)(condval_35), (long long)(256));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Sout_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Sout byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Sout_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Sout_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Sout device_id violates packed ABI constraint", (long long)((((DLTensor*)Sout_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Sout_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input Sout device_type mismatch, expected ext_dev", (long long)((((DLTensor*)Sout_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(Sout == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input Sout data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)O_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)O_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)O_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input O dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_O_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input O shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_O_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_Q_shape)[1]) == ((int32_t)((int64_t*)gdn_impl_O_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input O shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_Q_shape)[1])), (long long)(((int32_t)((int64_t*)gdn_impl_O_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_impl_O_shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input O shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_impl_O_shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_36;
  if ((gdn_impl_O_strides == NULL)) {
    condval_36 = 1;
  } else {
    condval_36 = ((int32_t)((int64_t*)gdn_impl_O_strides)[2]);
  }
  if (!((condval_36 == 1))) {
    int32_t condval_37;
    if ((gdn_impl_O_strides == NULL)) {
      condval_37 = 1;
    } else {
      condval_37 = ((int32_t)((int64_t*)gdn_impl_O_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input O strides[2] violates packed ABI constraint", (long long)(condval_37), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_38;
  if ((gdn_impl_O_strides == NULL)) {
    condval_38 = 1;
  } else {
    condval_38 = ((int32_t)((int64_t*)gdn_impl_O_strides)[1]);
  }
  if (!(((condval_38 == 16) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input O strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_39;
  if ((gdn_impl_O_strides == NULL)) {
    condval_39 = 1;
  } else {
    condval_39 = ((int32_t)((int64_t*)gdn_impl_O_strides)[0]);
  }
  if (!((((seq * 16) == condval_39) || (seq == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input O strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)O_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input O byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)O_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)O_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input O device_id violates packed ABI constraint", (long long)((((DLTensor*)O_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)O_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_impl input O device_type mismatch, expected ext_dev", (long long)((((DLTensor*)O_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(O == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_impl input O data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)12);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (Beta == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = Beta;
  if (G == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = G;
  if (H0 == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = H0;
  if (Hist == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = Hist;
  if (K == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = K;
  if (O == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_ptr) = O;
  if (Q == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_ptr) = Q;
  if (Sout == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_ptr) = Sout;
  if (V == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_ptr) = V;
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)seq);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = ((int64_t)8);
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = (int64_t)256;
  (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = (int64_t)0;
  if (gdn_impl_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "gdn_impl_kernel", &gdn_impl_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(gdn_impl_kernel_packed, (TVMFFIAny*) stack_ffi_any, 12, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_gdn_impl(self, args, num_args, result);
}
