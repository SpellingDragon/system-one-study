// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* rope_kernel_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_rope_kernel(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t TVMFFIEnvTensorAlloc(void*, void*);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_rope_kernel(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[6];
  void* stack_ffi_any = stack;
  if (!((num_args == 5))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "rope_kernel: num_args should be 5", (long long)(num_args), (long long)(5));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "rope_kernel: args pointer is NULL");
    return -1;
  }
  int32_t QKV_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((QKV_handle_type_index == 0) || (QKV_handle_type_index == 4)) || (QKV_handle_type_index == 7)) || (64 <= QKV_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_kernel input QKV expected pointer or tensor handle");
    return -1;
  }
  int32_t Cos_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((Cos_handle_type_index == 0) || (Cos_handle_type_index == 4)) || (Cos_handle_type_index == 7)) || (64 <= Cos_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_kernel input Cos expected pointer or tensor handle");
    return -1;
  }
  int32_t Sin_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((Sin_handle_type_index == 0) || (Sin_handle_type_index == 4)) || (Sin_handle_type_index == 7)) || (64 <= Sin_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_kernel input Sin expected pointer or tensor handle");
    return -1;
  }
  int32_t FREQ_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((FREQ_handle_type_index == 0) || (FREQ_handle_type_index == 4)) || (FREQ_handle_type_index == 7)) || (64 <= FREQ_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_kernel input FREQ expected pointer or tensor handle");
    return -1;
  }
  int32_t allocator_anchor_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!((allocator_anchor_type_index == 70))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "rope_kernel: allocator anchor must be a Tensor", (long long)(allocator_anchor_type_index), (long long)(70));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!((((TVMFFIAny*)args)[4].v_ptr) == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "rope_kernel: allocator anchor is NULL");
    return -1;
  }
  if (!(((((DLTensor*)((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + (int64_t)24)))[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "rope_kernel: allocator anchor has the wrong device type", (long long)((((DLTensor*)((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + (int64_t)24)))[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t dev_id = (((DLTensor*)((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + (int64_t)24)))[0].device.device_id);
  void* QKV_handle = ((QKV_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* Cos_handle = ((Cos_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* Sin_handle = ((Sin_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* FREQ_handle = ((FREQ_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  bool rope_kernel_QKV_is_null = (QKV_handle == NULL);
  if (!(!rope_kernel_QKV_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "rope_kernel.QKV is expected to have non-NULL pointer");
    return -1;
  }
  bool rope_kernel_Cos_is_null = (Cos_handle == NULL);
  if (!(!rope_kernel_Cos_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "rope_kernel.Cos is expected to have non-NULL pointer");
    return -1;
  }
  bool rope_kernel_Sin_is_null = (Sin_handle == NULL);
  if (!(!rope_kernel_Sin_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "rope_kernel.Sin is expected to have non-NULL pointer");
    return -1;
  }
  bool rope_kernel_FREQ_is_null = (FREQ_handle == NULL);
  void* rope_kernel_QKV_shape = (((DLTensor*)QKV_handle)[0].shape);
  void* rope_kernel_Cos_shape = (((DLTensor*)Cos_handle)[0].shape);
  void* rope_kernel_Sin_shape = (((DLTensor*)Sin_handle)[0].shape);
  void* condval;
  if (!rope_kernel_FREQ_is_null) {
    condval = (((DLTensor*)FREQ_handle)[0].shape);
  } else {
    uint64_t v_ = (uint64_t)0;
    condval = (*(void* *)(&(v_)));
  }
  void* rope_kernel_FREQ_shape = condval;
  if (!(((((DLTensor*)QKV_handle)[0].ndim) == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input QKV ndim mismatch, expected 4", (long long)((((DLTensor*)QKV_handle)[0].ndim)), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* rope_kernel_QKV_strides = (((DLTensor*)QKV_handle)[0].strides);
  void* QKV = (((DLTensor*)QKV_handle)[0].data);
  if (!(((((DLTensor*)Cos_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input Cos ndim mismatch, expected 2", (long long)((((DLTensor*)Cos_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* rope_kernel_Cos_strides = (((DLTensor*)Cos_handle)[0].strides);
  void* Cos = (((DLTensor*)Cos_handle)[0].data);
  if (!(((((DLTensor*)Sin_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input Sin ndim mismatch, expected 2", (long long)((((DLTensor*)Sin_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* rope_kernel_Sin_strides = (((DLTensor*)Sin_handle)[0].strides);
  void* Sin = (((DLTensor*)Sin_handle)[0].data);
  if (!((rope_kernel_FREQ_is_null || ((((DLTensor*)FREQ_handle)[0].ndim) == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_kernel input FREQ ndim mismatch, expected 1");
    return -1;
  }
  void* condval_1;
  if (!rope_kernel_FREQ_is_null) {
    condval_1 = (((DLTensor*)FREQ_handle)[0].strides);
  } else {
    uint64_t v__1 = (uint64_t)0;
    condval_1 = (*(void* *)(&(v__1)));
  }
  void* rope_kernel_FREQ_strides = condval_1;
  void* condval_2;
  if (!rope_kernel_FREQ_is_null) {
    condval_2 = (((DLTensor*)FREQ_handle)[0].data);
  } else {
    uint64_t v__2 = (uint64_t)0;
    condval_2 = (*(void* *)(&(v__2)));
  }
  void* FREQ = condval_2;
  if (!(((((((DLTensor*)QKV_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)QKV_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)QKV_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_kernel input QKV dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)rope_kernel_QKV_shape)[0]) == 64))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input QKV shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)rope_kernel_QKV_shape)[0])), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)rope_kernel_QKV_shape)[1]) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input QKV shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)rope_kernel_QKV_shape)[1])), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)rope_kernel_QKV_shape)[2]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input QKV shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)rope_kernel_QKV_shape)[2])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)rope_kernel_QKV_shape)[3]) == 64))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input QKV shape[3] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)rope_kernel_QKV_shape)[3])), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((rope_kernel_QKV_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)rope_kernel_QKV_strides)[3]);
  }
  if (!((condval_3 == 1))) {
    int32_t condval_4;
    if ((rope_kernel_QKV_strides == NULL)) {
      condval_4 = 1;
    } else {
      condval_4 = ((int32_t)((int64_t*)rope_kernel_QKV_strides)[3]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input QKV strides[3] violates packed ABI constraint", (long long)(condval_4), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_5;
  if ((rope_kernel_QKV_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)rope_kernel_QKV_strides)[2]);
  }
  if (!((condval_5 == 64))) {
    int32_t condval_6;
    if ((rope_kernel_QKV_strides == NULL)) {
      condval_6 = 1;
    } else {
      condval_6 = ((int32_t)((int64_t*)rope_kernel_QKV_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input QKV strides[2] violates packed ABI constraint", (long long)(condval_6), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_7;
  if ((rope_kernel_QKV_strides == NULL)) {
    condval_7 = 1;
  } else {
    condval_7 = ((int32_t)((int64_t*)rope_kernel_QKV_strides)[1]);
  }
  if (!((condval_7 == 512))) {
    int32_t condval_8;
    if ((rope_kernel_QKV_strides == NULL)) {
      condval_8 = 1;
    } else {
      condval_8 = ((int32_t)((int64_t*)rope_kernel_QKV_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input QKV strides[1] violates packed ABI constraint", (long long)(condval_8), (long long)(512));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_9;
  if ((rope_kernel_QKV_strides == NULL)) {
    condval_9 = 1;
  } else {
    condval_9 = ((int32_t)((int64_t*)rope_kernel_QKV_strides)[0]);
  }
  if (!((condval_9 == 1536))) {
    int32_t condval_10;
    if ((rope_kernel_QKV_strides == NULL)) {
      condval_10 = 1;
    } else {
      condval_10 = ((int32_t)((int64_t*)rope_kernel_QKV_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input QKV strides[0] violates packed ABI constraint", (long long)(condval_10), (long long)(1536));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)QKV_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input QKV byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)QKV_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)QKV_handle)[0].device.device_id) == dev_id))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input QKV device_id violates packed ABI constraint", (long long)((((DLTensor*)QKV_handle)[0].device.device_id)), (long long)(dev_id));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)QKV_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input QKV device_type mismatch, expected ext_dev", (long long)((((DLTensor*)QKV_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(QKV == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_kernel input QKV data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Cos_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Cos_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Cos_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_kernel input Cos dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)rope_kernel_Cos_shape)[0]) == 64))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input Cos shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)rope_kernel_Cos_shape)[0])), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)rope_kernel_Cos_shape)[1]) == 32))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input Cos shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)rope_kernel_Cos_shape)[1])), (long long)(32));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_11;
  if ((rope_kernel_Cos_strides == NULL)) {
    condval_11 = 1;
  } else {
    condval_11 = ((int32_t)((int64_t*)rope_kernel_Cos_strides)[1]);
  }
  if (!((condval_11 == 1))) {
    int32_t condval_12;
    if ((rope_kernel_Cos_strides == NULL)) {
      condval_12 = 1;
    } else {
      condval_12 = ((int32_t)((int64_t*)rope_kernel_Cos_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input Cos strides[1] violates packed ABI constraint", (long long)(condval_12), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_13;
  if ((rope_kernel_Cos_strides == NULL)) {
    condval_13 = 1;
  } else {
    condval_13 = ((int32_t)((int64_t*)rope_kernel_Cos_strides)[0]);
  }
  if (!((condval_13 == 32))) {
    int32_t condval_14;
    if ((rope_kernel_Cos_strides == NULL)) {
      condval_14 = 1;
    } else {
      condval_14 = ((int32_t)((int64_t*)rope_kernel_Cos_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input Cos strides[0] violates packed ABI constraint", (long long)(condval_14), (long long)(32));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Cos_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input Cos byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Cos_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Cos_handle)[0].device.device_id) == dev_id))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input Cos device_id violates packed ABI constraint", (long long)((((DLTensor*)Cos_handle)[0].device.device_id)), (long long)(dev_id));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Cos_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input Cos device_type mismatch, expected ext_dev", (long long)((((DLTensor*)Cos_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(Cos == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_kernel input Cos data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Sin_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Sin_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Sin_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_kernel input Sin dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)rope_kernel_Sin_shape)[0]) == 64))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input Sin shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)rope_kernel_Sin_shape)[0])), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)rope_kernel_Sin_shape)[1]) == 32))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input Sin shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)rope_kernel_Sin_shape)[1])), (long long)(32));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_15;
  if ((rope_kernel_Sin_strides == NULL)) {
    condval_15 = 1;
  } else {
    condval_15 = ((int32_t)((int64_t*)rope_kernel_Sin_strides)[1]);
  }
  if (!((condval_15 == 1))) {
    int32_t condval_16;
    if ((rope_kernel_Sin_strides == NULL)) {
      condval_16 = 1;
    } else {
      condval_16 = ((int32_t)((int64_t*)rope_kernel_Sin_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input Sin strides[1] violates packed ABI constraint", (long long)(condval_16), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_17;
  if ((rope_kernel_Sin_strides == NULL)) {
    condval_17 = 1;
  } else {
    condval_17 = ((int32_t)((int64_t*)rope_kernel_Sin_strides)[0]);
  }
  if (!((condval_17 == 32))) {
    int32_t condval_18;
    if ((rope_kernel_Sin_strides == NULL)) {
      condval_18 = 1;
    } else {
      condval_18 = ((int32_t)((int64_t*)rope_kernel_Sin_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input Sin strides[0] violates packed ABI constraint", (long long)(condval_18), (long long)(32));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Sin_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input Sin byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Sin_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Sin_handle)[0].device.device_id) == dev_id))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input Sin device_id violates packed ABI constraint", (long long)((((DLTensor*)Sin_handle)[0].device.device_id)), (long long)(dev_id));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Sin_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input Sin device_type mismatch, expected ext_dev", (long long)((((DLTensor*)Sin_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(Sin == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_kernel input Sin data pointer is NULL");
    return -1;
  }
  uint8_t condval_19;
  if (!rope_kernel_FREQ_is_null) {
    condval_19 = (((DLTensor*)FREQ_handle)[0].dtype.code);
  } else {
    condval_19 = (uint8_t)2;
  }
  uint8_t condval_20;
  if (!rope_kernel_FREQ_is_null) {
    condval_20 = (((DLTensor*)FREQ_handle)[0].dtype.bits);
  } else {
    condval_20 = (uint8_t)32;
  }
  uint16_t condval_21;
  if (!rope_kernel_FREQ_is_null) {
    condval_21 = (((DLTensor*)FREQ_handle)[0].dtype.lanes);
  } else {
    condval_21 = (uint16_t)1;
  }
  if (!((rope_kernel_FREQ_is_null || (((condval_19 == (uint8_t)2) && (condval_20 == (uint8_t)32)) && (condval_21 == (uint16_t)1))))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_kernel input FREQ dtype mismatch, expected float32");
    return -1;
  }
  int32_t condval_22;
  if (!rope_kernel_FREQ_is_null) {
    condval_22 = ((int32_t)((int64_t*)rope_kernel_FREQ_shape)[0]);
  } else {
    condval_22 = 0;
  }
  if (!((rope_kernel_FREQ_is_null || (condval_22 == 32)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_kernel input FREQ shape[0] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_23;
  if ((rope_kernel_FREQ_strides == NULL)) {
    condval_23 = 1;
  } else {
    condval_23 = ((int32_t)((int64_t*)rope_kernel_FREQ_strides)[0]);
  }
  if (!((rope_kernel_FREQ_is_null || (condval_23 == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_kernel input FREQ strides[0] violates packed ABI constraint");
    return -1;
  }
  uint64_t condval_24;
  if (!rope_kernel_FREQ_is_null) {
    condval_24 = (((DLTensor*)FREQ_handle)[0].byte_offset);
  } else {
    condval_24 = (uint64_t)0;
  }
  if (!((rope_kernel_FREQ_is_null || ((uint64_t)0 == condval_24)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_kernel input FREQ byte_offset violates packed ABI constraint");
    return -1;
  }
  int32_t condval_25;
  if (!rope_kernel_FREQ_is_null) {
    condval_25 = (((DLTensor*)FREQ_handle)[0].device.device_id);
  } else {
    condval_25 = 0;
  }
  if (!((rope_kernel_FREQ_is_null || (condval_25 == dev_id)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_kernel input FREQ device_id violates packed ABI constraint");
    return -1;
  }
  int32_t condval_26;
  if (!rope_kernel_FREQ_is_null) {
    condval_26 = (((DLTensor*)FREQ_handle)[0].device.device_type);
  } else {
    condval_26 = 0;
  }
  if (!((rope_kernel_FREQ_is_null || (condval_26 == 12)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_kernel input FREQ device_type mismatch, expected ext_dev");
    return -1;
  }
  if (!((rope_kernel_FREQ_is_null || !(FREQ == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_kernel input FREQ data pointer is NULL");
    return -1;
  }
  TL_ALIGN(128) TVMFFIAny stack_1[1];
  void* callee_allocated_output_storage = stack_1;
  TVMFFIAny stack_2[2];
  void* callee_allocated_output_shape_storage = stack_2;
  TVMFFIAny stack_3[3];
  void* callee_allocated_output_prototype_storage = stack_3;
  (((int64_t*)callee_allocated_output_shape_storage)[0]) = (int64_t)64;
  (((int64_t*)callee_allocated_output_shape_storage)[1]) = (int64_t)3;
  (((int64_t*)callee_allocated_output_shape_storage)[2]) = (int64_t)8;
  (((int64_t*)callee_allocated_output_shape_storage)[3]) = (int64_t)64;
  uint64_t v__3 = (uint64_t)0;
  (((DLTensor*)callee_allocated_output_prototype_storage)[0].data) = (*(void* *)(&(v__3)));
  (((DLTensor*)callee_allocated_output_prototype_storage)[0].shape) = (int64_t*)((void*)((char*)callee_allocated_output_shape_storage + (int64_t)0));
  uint64_t v__4 = (uint64_t)0;
  (((DLTensor*)callee_allocated_output_prototype_storage)[0].strides) = (int64_t*)(*(void* *)(&(v__4)));
  (((DLTensor*)callee_allocated_output_prototype_storage)[0].ndim) = 4;
  (((DLTensor*)callee_allocated_output_prototype_storage)[0].dtype.code) = (uint8_t)2;
  (((DLTensor*)callee_allocated_output_prototype_storage)[0].dtype.bits) = (uint8_t)32;
  (((DLTensor*)callee_allocated_output_prototype_storage)[0].dtype.lanes) = (uint16_t)1;
  (((DLTensor*)callee_allocated_output_prototype_storage)[0].byte_offset) = (uint64_t)0;
  (((DLTensor*)callee_allocated_output_prototype_storage)[0].device.device_id) = dev_id;
  (((DLTensor*)callee_allocated_output_prototype_storage)[0].device.device_type) = (DLDeviceType)12;
  int32_t O_allocation_status = TVMFFIEnvTensorAlloc((((DLTensor*)callee_allocated_output_prototype_storage) + 0), ((void*)((char*)callee_allocated_output_storage + (int64_t)8)));
  if (O_allocation_status != 0) {
    return O_allocation_status;
  }
  void* O_handle = ((void*)((char*)(((TVMFFIAny*)callee_allocated_output_storage)[0].v_ptr) + (int64_t)24));
  bool rope_kernel_O_is_null = (O_handle == NULL);
  if (!(!rope_kernel_O_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "rope_kernel.O is expected to have non-NULL pointer");
    return -1;
  }
  void* rope_kernel_O_shape = (((DLTensor*)O_handle)[0].shape);
  if (!(((((DLTensor*)O_handle)[0].ndim) == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input O ndim mismatch, expected 4", (long long)((((DLTensor*)O_handle)[0].ndim)), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* rope_kernel_O_strides = (((DLTensor*)O_handle)[0].strides);
  void* O = (((DLTensor*)O_handle)[0].data);
  if (!(((((((DLTensor*)O_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)O_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)O_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_kernel input O dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)rope_kernel_O_shape)[0]) == 64))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input O shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)rope_kernel_O_shape)[0])), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)rope_kernel_O_shape)[1]) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input O shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)rope_kernel_O_shape)[1])), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)rope_kernel_O_shape)[2]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input O shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)rope_kernel_O_shape)[2])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)rope_kernel_O_shape)[3]) == 64))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input O shape[3] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)rope_kernel_O_shape)[3])), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_27;
  if ((rope_kernel_O_strides == NULL)) {
    condval_27 = 1;
  } else {
    condval_27 = ((int32_t)((int64_t*)rope_kernel_O_strides)[3]);
  }
  if (!((condval_27 == 1))) {
    int32_t condval_28;
    if ((rope_kernel_O_strides == NULL)) {
      condval_28 = 1;
    } else {
      condval_28 = ((int32_t)((int64_t*)rope_kernel_O_strides)[3]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input O strides[3] violates packed ABI constraint", (long long)(condval_28), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_29;
  if ((rope_kernel_O_strides == NULL)) {
    condval_29 = 1;
  } else {
    condval_29 = ((int32_t)((int64_t*)rope_kernel_O_strides)[2]);
  }
  if (!((condval_29 == 64))) {
    int32_t condval_30;
    if ((rope_kernel_O_strides == NULL)) {
      condval_30 = 1;
    } else {
      condval_30 = ((int32_t)((int64_t*)rope_kernel_O_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input O strides[2] violates packed ABI constraint", (long long)(condval_30), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_31;
  if ((rope_kernel_O_strides == NULL)) {
    condval_31 = 1;
  } else {
    condval_31 = ((int32_t)((int64_t*)rope_kernel_O_strides)[1]);
  }
  if (!((condval_31 == 512))) {
    int32_t condval_32;
    if ((rope_kernel_O_strides == NULL)) {
      condval_32 = 1;
    } else {
      condval_32 = ((int32_t)((int64_t*)rope_kernel_O_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input O strides[1] violates packed ABI constraint", (long long)(condval_32), (long long)(512));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_33;
  if ((rope_kernel_O_strides == NULL)) {
    condval_33 = 1;
  } else {
    condval_33 = ((int32_t)((int64_t*)rope_kernel_O_strides)[0]);
  }
  if (!((condval_33 == 1536))) {
    int32_t condval_34;
    if ((rope_kernel_O_strides == NULL)) {
      condval_34 = 1;
    } else {
      condval_34 = ((int32_t)((int64_t*)rope_kernel_O_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input O strides[0] violates packed ABI constraint", (long long)(condval_34), (long long)(1536));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)O_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input O byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)O_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)O_handle)[0].device.device_id) == dev_id))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input O device_id violates packed ABI constraint", (long long)((((DLTensor*)O_handle)[0].device.device_id)), (long long)(dev_id));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)O_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_kernel input O device_type mismatch, expected ext_dev", (long long)((((DLTensor*)O_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(O == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_kernel input O data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)12);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (Cos == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = Cos;
  if (O == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = O;
  if (QKV == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = QKV;
  if (Sin == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = Sin;
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = ((int64_t)64);
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = (int64_t)0;
  if (rope_kernel_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "rope_kernel_kernel", &rope_kernel_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(rope_kernel_kernel_packed, (TVMFFIAny*) stack_ffi_any, 5, &result_2) != 0) {
    return -1;
  }
  (((TVMFFIAny*)result)[0].type_index) = 70;
  (((TVMFFIAny*)result)[0].zero_padding) = 0;
  (((TVMFFIAny*)result)[0].v_int64) = 0;
  (((TVMFFIAny*)result)[0].v_ptr) = (((TVMFFIAny*)callee_allocated_output_storage)[0].v_ptr);
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_rope_kernel(self, args, num_args, result);
}
