// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* attn_impl_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_attn_impl(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_attn_impl(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[8];
  void* stack_ffi_any = stack;
  if (!((num_args == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "attn_impl: num_args should be 4", (long long)(num_args), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "attn_impl: args pointer is NULL");
    return -1;
  }
  int32_t Q_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((Q_handle_type_index == 0) || (Q_handle_type_index == 4)) || (Q_handle_type_index == 7)) || (64 <= Q_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel attn_impl input Q expected pointer or tensor handle");
    return -1;
  }
  int32_t K_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((K_handle_type_index == 0) || (K_handle_type_index == 4)) || (K_handle_type_index == 7)) || (64 <= K_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel attn_impl input K expected pointer or tensor handle");
    return -1;
  }
  int32_t V_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((V_handle_type_index == 0) || (V_handle_type_index == 4)) || (V_handle_type_index == 7)) || (64 <= V_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel attn_impl input V expected pointer or tensor handle");
    return -1;
  }
  int32_t O_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((O_handle_type_index == 0) || (O_handle_type_index == 4)) || (O_handle_type_index == 7)) || (64 <= O_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel attn_impl input O expected pointer or tensor handle");
    return -1;
  }
  void* Q_handle = ((Q_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* K_handle = ((K_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* V_handle = ((V_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* O_handle = ((O_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  bool attn_impl_Q_is_null = (Q_handle == NULL);
  if (!(!attn_impl_Q_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "attn_impl.Q is expected to have non-NULL pointer");
    return -1;
  }
  bool attn_impl_K_is_null = (K_handle == NULL);
  if (!(!attn_impl_K_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "attn_impl.K is expected to have non-NULL pointer");
    return -1;
  }
  bool attn_impl_V_is_null = (V_handle == NULL);
  if (!(!attn_impl_V_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "attn_impl.V is expected to have non-NULL pointer");
    return -1;
  }
  bool attn_impl_O_is_null = (O_handle == NULL);
  if (!(!attn_impl_O_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "attn_impl.O is expected to have non-NULL pointer");
    return -1;
  }
  void* attn_impl_Q_shape = (((DLTensor*)Q_handle)[0].shape);
  void* attn_impl_K_shape = (((DLTensor*)K_handle)[0].shape);
  void* attn_impl_V_shape = (((DLTensor*)V_handle)[0].shape);
  void* attn_impl_O_shape = (((DLTensor*)O_handle)[0].shape);
  if (!(((((DLTensor*)Q_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input Q ndim mismatch, expected 3", (long long)((((DLTensor*)Q_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable seq requires at least one non-null buffer among: attn_impl.Q, attn_impl.K, attn_impl.V, attn_impl.O");
    return -1;
  }
  int32_t seq = ((int32_t)((int64_t*)attn_impl_Q_shape)[1]);
  void* attn_impl_Q_strides = (((DLTensor*)Q_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)Q_handle)[0].device.device_id);
  void* Q = (((DLTensor*)Q_handle)[0].data);
  if (!(((((DLTensor*)K_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input K ndim mismatch, expected 3", (long long)((((DLTensor*)K_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* attn_impl_K_strides = (((DLTensor*)K_handle)[0].strides);
  void* K = (((DLTensor*)K_handle)[0].data);
  if (!(((((DLTensor*)V_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input V ndim mismatch, expected 3", (long long)((((DLTensor*)V_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* attn_impl_V_strides = (((DLTensor*)V_handle)[0].strides);
  void* V = (((DLTensor*)V_handle)[0].data);
  if (!(((((DLTensor*)O_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input O ndim mismatch, expected 3", (long long)((((DLTensor*)O_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* attn_impl_O_strides = (((DLTensor*)O_handle)[0].strides);
  void* O = (((DLTensor*)O_handle)[0].data);
  if (!(((((((DLTensor*)Q_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Q_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Q_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel attn_impl input Q dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)attn_impl_Q_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input Q shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)attn_impl_Q_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)attn_impl_Q_shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input Q shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)attn_impl_Q_shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval;
  if ((attn_impl_Q_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)attn_impl_Q_strides)[2]);
  }
  if (!((condval == 1))) {
    int32_t condval_1;
    if ((attn_impl_Q_strides == NULL)) {
      condval_1 = 1;
    } else {
      condval_1 = ((int32_t)((int64_t*)attn_impl_Q_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input Q strides[2] violates packed ABI constraint", (long long)(condval_1), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((attn_impl_Q_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)attn_impl_Q_strides)[1]);
  }
  if (!(((condval_2 == 16) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel attn_impl input Q strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_3;
  if ((attn_impl_Q_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)attn_impl_Q_strides)[0]);
  }
  if (!((((seq * 16) == condval_3) || (seq == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel attn_impl input Q strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Q_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input Q byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Q_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Q_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input Q device_type mismatch, expected ext_dev", (long long)((((DLTensor*)Q_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(Q == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel attn_impl input Q data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)K_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)K_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)K_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel attn_impl input K dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)attn_impl_K_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input K shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)attn_impl_K_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)attn_impl_Q_shape)[1]) == ((int32_t)((int64_t*)attn_impl_K_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input K shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)attn_impl_Q_shape)[1])), (long long)(((int32_t)((int64_t*)attn_impl_K_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)attn_impl_K_shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input K shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)attn_impl_K_shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_4;
  if ((attn_impl_K_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)attn_impl_K_strides)[2]);
  }
  if (!((condval_4 == 1))) {
    int32_t condval_5;
    if ((attn_impl_K_strides == NULL)) {
      condval_5 = 1;
    } else {
      condval_5 = ((int32_t)((int64_t*)attn_impl_K_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input K strides[2] violates packed ABI constraint", (long long)(condval_5), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_6;
  if ((attn_impl_K_strides == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)attn_impl_K_strides)[1]);
  }
  if (!(((condval_6 == 16) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel attn_impl input K strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_7;
  if ((attn_impl_K_strides == NULL)) {
    condval_7 = 1;
  } else {
    condval_7 = ((int32_t)((int64_t*)attn_impl_K_strides)[0]);
  }
  if (!((((seq * 16) == condval_7) || (seq == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel attn_impl input K strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)K_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input K byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)K_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)K_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input K device_id violates packed ABI constraint", (long long)((((DLTensor*)K_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)K_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input K device_type mismatch, expected ext_dev", (long long)((((DLTensor*)K_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(K == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel attn_impl input K data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)V_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)V_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)V_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel attn_impl input V dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)attn_impl_V_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input V shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)attn_impl_V_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)attn_impl_Q_shape)[1]) == ((int32_t)((int64_t*)attn_impl_V_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input V shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)attn_impl_Q_shape)[1])), (long long)(((int32_t)((int64_t*)attn_impl_V_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)attn_impl_V_shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input V shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)attn_impl_V_shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_8;
  if ((attn_impl_V_strides == NULL)) {
    condval_8 = 1;
  } else {
    condval_8 = ((int32_t)((int64_t*)attn_impl_V_strides)[2]);
  }
  if (!((condval_8 == 1))) {
    int32_t condval_9;
    if ((attn_impl_V_strides == NULL)) {
      condval_9 = 1;
    } else {
      condval_9 = ((int32_t)((int64_t*)attn_impl_V_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input V strides[2] violates packed ABI constraint", (long long)(condval_9), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_10;
  if ((attn_impl_V_strides == NULL)) {
    condval_10 = 1;
  } else {
    condval_10 = ((int32_t)((int64_t*)attn_impl_V_strides)[1]);
  }
  if (!(((condval_10 == 16) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel attn_impl input V strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_11;
  if ((attn_impl_V_strides == NULL)) {
    condval_11 = 1;
  } else {
    condval_11 = ((int32_t)((int64_t*)attn_impl_V_strides)[0]);
  }
  if (!((((seq * 16) == condval_11) || (seq == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel attn_impl input V strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)V_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input V byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)V_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)V_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input V device_id violates packed ABI constraint", (long long)((((DLTensor*)V_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)V_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input V device_type mismatch, expected ext_dev", (long long)((((DLTensor*)V_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(V == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel attn_impl input V data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)O_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)O_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)O_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel attn_impl input O dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)attn_impl_O_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input O shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)attn_impl_O_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)attn_impl_Q_shape)[1]) == ((int32_t)((int64_t*)attn_impl_O_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input O shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)attn_impl_Q_shape)[1])), (long long)(((int32_t)((int64_t*)attn_impl_O_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)attn_impl_O_shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input O shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)attn_impl_O_shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_12;
  if ((attn_impl_O_strides == NULL)) {
    condval_12 = 1;
  } else {
    condval_12 = ((int32_t)((int64_t*)attn_impl_O_strides)[2]);
  }
  if (!((condval_12 == 1))) {
    int32_t condval_13;
    if ((attn_impl_O_strides == NULL)) {
      condval_13 = 1;
    } else {
      condval_13 = ((int32_t)((int64_t*)attn_impl_O_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input O strides[2] violates packed ABI constraint", (long long)(condval_13), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_14;
  if ((attn_impl_O_strides == NULL)) {
    condval_14 = 1;
  } else {
    condval_14 = ((int32_t)((int64_t*)attn_impl_O_strides)[1]);
  }
  if (!(((condval_14 == 16) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel attn_impl input O strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_15;
  if ((attn_impl_O_strides == NULL)) {
    condval_15 = 1;
  } else {
    condval_15 = ((int32_t)((int64_t*)attn_impl_O_strides)[0]);
  }
  if (!((((seq * 16) == condval_15) || (seq == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel attn_impl input O strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)O_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input O byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)O_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)O_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input O device_id violates packed ABI constraint", (long long)((((DLTensor*)O_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)O_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel attn_impl input O device_type mismatch, expected ext_dev", (long long)((((DLTensor*)O_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(O == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel attn_impl input O data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)12);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (K == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = K;
  if (O == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = O;
  if (Q == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = Q;
  if (V == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = V;
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = ((int64_t)seq);
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = ((int64_t)16);
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = (int64_t)64;
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = (int64_t)0;
  if (attn_impl_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "attn_impl_kernel", &attn_impl_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(attn_impl_kernel_packed, (TVMFFIAny*) stack_ffi_any, 7, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_attn_impl(self, args, num_args, result);
}
