// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* add_ln_impl_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_add_ln_impl(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_add_ln_impl(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[10];
  void* stack_ffi_any = stack;
  if (!((num_args == 6))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "add_ln_impl: num_args should be 6", (long long)(num_args), (long long)(6));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "add_ln_impl: args pointer is NULL");
    return -1;
  }
  int32_t X_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((X_handle_type_index == 0) || (X_handle_type_index == 4)) || (X_handle_type_index == 7)) || (64 <= X_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel add_ln_impl input X expected pointer or tensor handle");
    return -1;
  }
  int32_t Res_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((Res_handle_type_index == 0) || (Res_handle_type_index == 4)) || (Res_handle_type_index == 7)) || (64 <= Res_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel add_ln_impl input Res expected pointer or tensor handle");
    return -1;
  }
  int32_t G_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((G_handle_type_index == 0) || (G_handle_type_index == 4)) || (G_handle_type_index == 7)) || (64 <= G_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel add_ln_impl input G expected pointer or tensor handle");
    return -1;
  }
  int32_t Bt_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((Bt_handle_type_index == 0) || (Bt_handle_type_index == 4)) || (Bt_handle_type_index == 7)) || (64 <= Bt_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel add_ln_impl input Bt expected pointer or tensor handle");
    return -1;
  }
  int32_t Y_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((Y_handle_type_index == 0) || (Y_handle_type_index == 4)) || (Y_handle_type_index == 7)) || (64 <= Y_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel add_ln_impl input Y expected pointer or tensor handle");
    return -1;
  }
  int32_t Hout_handle_type_index = (((TVMFFIAny*)args)[5].type_index);
  if (!(((((Hout_handle_type_index == 0) || (Hout_handle_type_index == 4)) || (Hout_handle_type_index == 7)) || (64 <= Hout_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel add_ln_impl input Hout expected pointer or tensor handle");
    return -1;
  }
  void* X_handle = ((X_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* Res_handle = ((Res_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* G_handle = ((G_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* Bt_handle = ((Bt_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* Y_handle = ((Y_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  void* Hout_handle = ((Hout_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[5].v_ptr) + 24)) : (((TVMFFIAny*)args)[5].v_ptr));
  bool add_ln_impl_X_is_null = (X_handle == NULL);
  if (!(!add_ln_impl_X_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "add_ln_impl.X is expected to have non-NULL pointer");
    return -1;
  }
  bool add_ln_impl_Res_is_null = (Res_handle == NULL);
  if (!(!add_ln_impl_Res_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "add_ln_impl.Res is expected to have non-NULL pointer");
    return -1;
  }
  bool add_ln_impl_G_is_null = (G_handle == NULL);
  if (!(!add_ln_impl_G_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "add_ln_impl.G is expected to have non-NULL pointer");
    return -1;
  }
  bool add_ln_impl_Bt_is_null = (Bt_handle == NULL);
  if (!(!add_ln_impl_Bt_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "add_ln_impl.Bt is expected to have non-NULL pointer");
    return -1;
  }
  bool add_ln_impl_Y_is_null = (Y_handle == NULL);
  if (!(!add_ln_impl_Y_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "add_ln_impl.Y is expected to have non-NULL pointer");
    return -1;
  }
  bool add_ln_impl_Hout_is_null = (Hout_handle == NULL);
  if (!(!add_ln_impl_Hout_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "add_ln_impl.Hout is expected to have non-NULL pointer");
    return -1;
  }
  void* add_ln_impl_X_shape = (((DLTensor*)X_handle)[0].shape);
  void* add_ln_impl_Res_shape = (((DLTensor*)Res_handle)[0].shape);
  void* add_ln_impl_G_shape = (((DLTensor*)G_handle)[0].shape);
  void* add_ln_impl_Bt_shape = (((DLTensor*)Bt_handle)[0].shape);
  void* add_ln_impl_Y_shape = (((DLTensor*)Y_handle)[0].shape);
  void* add_ln_impl_Hout_shape = (((DLTensor*)Hout_handle)[0].shape);
  if (!(((((DLTensor*)X_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input X ndim mismatch, expected 2", (long long)((((DLTensor*)X_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable rows requires at least one non-null buffer among: add_ln_impl.X, add_ln_impl.Res, add_ln_impl.Y, add_ln_impl.Hout");
    return -1;
  }
  int32_t rows = ((int32_t)((int64_t*)add_ln_impl_X_shape)[0]);
  void* add_ln_impl_X_strides = (((DLTensor*)X_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)X_handle)[0].device.device_id);
  void* X = (((DLTensor*)X_handle)[0].data);
  if (!(((((DLTensor*)Res_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Res ndim mismatch, expected 2", (long long)((((DLTensor*)Res_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* add_ln_impl_Res_strides = (((DLTensor*)Res_handle)[0].strides);
  void* Res = (((DLTensor*)Res_handle)[0].data);
  if (!(((((DLTensor*)G_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input G ndim mismatch, expected 1", (long long)((((DLTensor*)G_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* add_ln_impl_G_strides = (((DLTensor*)G_handle)[0].strides);
  void* G = (((DLTensor*)G_handle)[0].data);
  if (!(((((DLTensor*)Bt_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Bt ndim mismatch, expected 1", (long long)((((DLTensor*)Bt_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* add_ln_impl_Bt_strides = (((DLTensor*)Bt_handle)[0].strides);
  void* Bt = (((DLTensor*)Bt_handle)[0].data);
  if (!(((((DLTensor*)Y_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Y ndim mismatch, expected 2", (long long)((((DLTensor*)Y_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* add_ln_impl_Y_strides = (((DLTensor*)Y_handle)[0].strides);
  void* Y = (((DLTensor*)Y_handle)[0].data);
  if (!(((((DLTensor*)Hout_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Hout ndim mismatch, expected 2", (long long)((((DLTensor*)Hout_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* add_ln_impl_Hout_strides = (((DLTensor*)Hout_handle)[0].strides);
  void* Hout = (((DLTensor*)Hout_handle)[0].data);
  if (!(((((((DLTensor*)X_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)X_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)X_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel add_ln_impl input X dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)add_ln_impl_X_shape)[1]) == 64))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input X shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)add_ln_impl_X_shape)[1])), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval;
  if ((add_ln_impl_X_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)add_ln_impl_X_strides)[1]);
  }
  if (!((condval == 1))) {
    int32_t condval_1;
    if ((add_ln_impl_X_strides == NULL)) {
      condval_1 = 1;
    } else {
      condval_1 = ((int32_t)((int64_t*)add_ln_impl_X_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input X strides[1] violates packed ABI constraint", (long long)(condval_1), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((add_ln_impl_X_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)add_ln_impl_X_strides)[0]);
  }
  if (!(((condval_2 == 64) || (rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel add_ln_impl input X strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)X_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input X byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)X_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)X_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input X device_type mismatch, expected ext_dev", (long long)((((DLTensor*)X_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(X == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel add_ln_impl input X data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Res_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Res_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Res_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel add_ln_impl input Res dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)add_ln_impl_X_shape)[0]) == ((int32_t)((int64_t*)add_ln_impl_Res_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Res shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)add_ln_impl_X_shape)[0])), (long long)(((int32_t)((int64_t*)add_ln_impl_Res_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)add_ln_impl_Res_shape)[1]) == 64))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Res shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)add_ln_impl_Res_shape)[1])), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((add_ln_impl_Res_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)add_ln_impl_Res_strides)[1]);
  }
  if (!((condval_3 == 1))) {
    int32_t condval_4;
    if ((add_ln_impl_Res_strides == NULL)) {
      condval_4 = 1;
    } else {
      condval_4 = ((int32_t)((int64_t*)add_ln_impl_Res_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Res strides[1] violates packed ABI constraint", (long long)(condval_4), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_5;
  if ((add_ln_impl_Res_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)add_ln_impl_Res_strides)[0]);
  }
  if (!(((condval_5 == 64) || (rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel add_ln_impl input Res strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Res_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Res byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Res_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Res_handle)[0].device.device_id) == (((DLTensor*)X_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Res device_id violates packed ABI constraint", (long long)((((DLTensor*)Res_handle)[0].device.device_id)), (long long)((((DLTensor*)X_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Res_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Res device_type mismatch, expected ext_dev", (long long)((((DLTensor*)Res_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(Res == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel add_ln_impl input Res data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)G_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)G_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)G_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel add_ln_impl input G dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)add_ln_impl_G_shape)[0]) == 64))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input G shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)add_ln_impl_G_shape)[0])), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_6;
  if ((add_ln_impl_G_strides == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)add_ln_impl_G_strides)[0]);
  }
  if (!((condval_6 == 1))) {
    int32_t condval_7;
    if ((add_ln_impl_G_strides == NULL)) {
      condval_7 = 1;
    } else {
      condval_7 = ((int32_t)((int64_t*)add_ln_impl_G_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input G strides[0] violates packed ABI constraint", (long long)(condval_7), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)G_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input G byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)G_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)G_handle)[0].device.device_id) == (((DLTensor*)X_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input G device_id violates packed ABI constraint", (long long)((((DLTensor*)G_handle)[0].device.device_id)), (long long)((((DLTensor*)X_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)G_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input G device_type mismatch, expected ext_dev", (long long)((((DLTensor*)G_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(G == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel add_ln_impl input G data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Bt_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Bt_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Bt_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel add_ln_impl input Bt dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)add_ln_impl_Bt_shape)[0]) == 64))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Bt shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)add_ln_impl_Bt_shape)[0])), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_8;
  if ((add_ln_impl_Bt_strides == NULL)) {
    condval_8 = 1;
  } else {
    condval_8 = ((int32_t)((int64_t*)add_ln_impl_Bt_strides)[0]);
  }
  if (!((condval_8 == 1))) {
    int32_t condval_9;
    if ((add_ln_impl_Bt_strides == NULL)) {
      condval_9 = 1;
    } else {
      condval_9 = ((int32_t)((int64_t*)add_ln_impl_Bt_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Bt strides[0] violates packed ABI constraint", (long long)(condval_9), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Bt_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Bt byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Bt_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Bt_handle)[0].device.device_id) == (((DLTensor*)X_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Bt device_id violates packed ABI constraint", (long long)((((DLTensor*)Bt_handle)[0].device.device_id)), (long long)((((DLTensor*)X_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Bt_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Bt device_type mismatch, expected ext_dev", (long long)((((DLTensor*)Bt_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(Bt == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel add_ln_impl input Bt data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Y_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Y_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Y_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel add_ln_impl input Y dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)add_ln_impl_X_shape)[0]) == ((int32_t)((int64_t*)add_ln_impl_Y_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Y shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)add_ln_impl_X_shape)[0])), (long long)(((int32_t)((int64_t*)add_ln_impl_Y_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)add_ln_impl_Y_shape)[1]) == 64))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Y shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)add_ln_impl_Y_shape)[1])), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_10;
  if ((add_ln_impl_Y_strides == NULL)) {
    condval_10 = 1;
  } else {
    condval_10 = ((int32_t)((int64_t*)add_ln_impl_Y_strides)[1]);
  }
  if (!((condval_10 == 1))) {
    int32_t condval_11;
    if ((add_ln_impl_Y_strides == NULL)) {
      condval_11 = 1;
    } else {
      condval_11 = ((int32_t)((int64_t*)add_ln_impl_Y_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Y strides[1] violates packed ABI constraint", (long long)(condval_11), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_12;
  if ((add_ln_impl_Y_strides == NULL)) {
    condval_12 = 1;
  } else {
    condval_12 = ((int32_t)((int64_t*)add_ln_impl_Y_strides)[0]);
  }
  if (!(((condval_12 == 64) || (rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel add_ln_impl input Y strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Y_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Y byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Y_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Y_handle)[0].device.device_id) == (((DLTensor*)X_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Y device_id violates packed ABI constraint", (long long)((((DLTensor*)Y_handle)[0].device.device_id)), (long long)((((DLTensor*)X_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Y_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Y device_type mismatch, expected ext_dev", (long long)((((DLTensor*)Y_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(Y == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel add_ln_impl input Y data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Hout_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Hout_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Hout_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel add_ln_impl input Hout dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)add_ln_impl_X_shape)[0]) == ((int32_t)((int64_t*)add_ln_impl_Hout_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Hout shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)add_ln_impl_X_shape)[0])), (long long)(((int32_t)((int64_t*)add_ln_impl_Hout_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)add_ln_impl_Hout_shape)[1]) == 64))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Hout shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)add_ln_impl_Hout_shape)[1])), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_13;
  if ((add_ln_impl_Hout_strides == NULL)) {
    condval_13 = 1;
  } else {
    condval_13 = ((int32_t)((int64_t*)add_ln_impl_Hout_strides)[1]);
  }
  if (!((condval_13 == 1))) {
    int32_t condval_14;
    if ((add_ln_impl_Hout_strides == NULL)) {
      condval_14 = 1;
    } else {
      condval_14 = ((int32_t)((int64_t*)add_ln_impl_Hout_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Hout strides[1] violates packed ABI constraint", (long long)(condval_14), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_15;
  if ((add_ln_impl_Hout_strides == NULL)) {
    condval_15 = 1;
  } else {
    condval_15 = ((int32_t)((int64_t*)add_ln_impl_Hout_strides)[0]);
  }
  if (!(((condval_15 == 64) || (rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel add_ln_impl input Hout strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Hout_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Hout byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Hout_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Hout_handle)[0].device.device_id) == (((DLTensor*)X_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Hout device_id violates packed ABI constraint", (long long)((((DLTensor*)Hout_handle)[0].device.device_id)), (long long)((((DLTensor*)X_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Hout_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel add_ln_impl input Hout device_type mismatch, expected ext_dev", (long long)((((DLTensor*)Hout_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(Hout == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel add_ln_impl input Hout data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)12);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (Bt == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = Bt;
  if (G == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = G;
  if (Hout == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = Hout;
  if (Res == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = Res;
  if (X == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = X;
  if (Y == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_ptr) = Y;
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)((rows + 15) >> 4));
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = (int64_t)8704;
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = (int64_t)0;
  if (add_ln_impl_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "add_ln_impl_kernel", &add_ln_impl_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(add_ln_impl_kernel_packed, (TVMFFIAny*) stack_ffi_any, 9, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_add_ln_impl(self, args, num_args, result);
}
