// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* ln_bwd_impl_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_ln_bwd_impl(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_ln_bwd_impl(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[10];
  void* stack_ffi_any = stack;
  if (!((num_args == 6))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "ln_bwd_impl: num_args should be 6", (long long)(num_args), (long long)(6));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "ln_bwd_impl: args pointer is NULL");
    return -1;
  }
  int32_t H_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((H_handle_type_index == 0) || (H_handle_type_index == 4)) || (H_handle_type_index == 7)) || (64 <= H_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel ln_bwd_impl input H expected pointer or tensor handle");
    return -1;
  }
  int32_t G_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((G_handle_type_index == 0) || (G_handle_type_index == 4)) || (G_handle_type_index == 7)) || (64 <= G_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel ln_bwd_impl input G expected pointer or tensor handle");
    return -1;
  }
  int32_t DY_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((DY_handle_type_index == 0) || (DY_handle_type_index == 4)) || (DY_handle_type_index == 7)) || (64 <= DY_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel ln_bwd_impl input DY expected pointer or tensor handle");
    return -1;
  }
  int32_t DX_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((DX_handle_type_index == 0) || (DX_handle_type_index == 4)) || (DX_handle_type_index == 7)) || (64 <= DX_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel ln_bwd_impl input DX expected pointer or tensor handle");
    return -1;
  }
  int32_t Dg_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((Dg_handle_type_index == 0) || (Dg_handle_type_index == 4)) || (Dg_handle_type_index == 7)) || (64 <= Dg_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel ln_bwd_impl input Dg expected pointer or tensor handle");
    return -1;
  }
  int32_t Db_handle_type_index = (((TVMFFIAny*)args)[5].type_index);
  if (!(((((Db_handle_type_index == 0) || (Db_handle_type_index == 4)) || (Db_handle_type_index == 7)) || (64 <= Db_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel ln_bwd_impl input Db expected pointer or tensor handle");
    return -1;
  }
  void* H_handle = ((H_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* G_handle = ((G_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* DY_handle = ((DY_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* DX_handle = ((DX_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* Dg_handle = ((Dg_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  void* Db_handle = ((Db_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[5].v_ptr) + 24)) : (((TVMFFIAny*)args)[5].v_ptr));
  bool ln_bwd_impl_H_is_null = (H_handle == NULL);
  if (!(!ln_bwd_impl_H_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "ln_bwd_impl.H is expected to have non-NULL pointer");
    return -1;
  }
  bool ln_bwd_impl_G_is_null = (G_handle == NULL);
  if (!(!ln_bwd_impl_G_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "ln_bwd_impl.G is expected to have non-NULL pointer");
    return -1;
  }
  bool ln_bwd_impl_DY_is_null = (DY_handle == NULL);
  if (!(!ln_bwd_impl_DY_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "ln_bwd_impl.DY is expected to have non-NULL pointer");
    return -1;
  }
  bool ln_bwd_impl_DX_is_null = (DX_handle == NULL);
  if (!(!ln_bwd_impl_DX_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "ln_bwd_impl.DX is expected to have non-NULL pointer");
    return -1;
  }
  bool ln_bwd_impl_Dg_is_null = (Dg_handle == NULL);
  if (!(!ln_bwd_impl_Dg_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "ln_bwd_impl.Dg is expected to have non-NULL pointer");
    return -1;
  }
  bool ln_bwd_impl_Db_is_null = (Db_handle == NULL);
  if (!(!ln_bwd_impl_Db_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "ln_bwd_impl.Db is expected to have non-NULL pointer");
    return -1;
  }
  void* ln_bwd_impl_H_shape = (((DLTensor*)H_handle)[0].shape);
  void* ln_bwd_impl_G_shape = (((DLTensor*)G_handle)[0].shape);
  void* ln_bwd_impl_DY_shape = (((DLTensor*)DY_handle)[0].shape);
  void* ln_bwd_impl_DX_shape = (((DLTensor*)DX_handle)[0].shape);
  void* ln_bwd_impl_Dg_shape = (((DLTensor*)Dg_handle)[0].shape);
  void* ln_bwd_impl_Db_shape = (((DLTensor*)Db_handle)[0].shape);
  if (!(((((DLTensor*)H_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input H ndim mismatch, expected 2", (long long)((((DLTensor*)H_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable rows requires at least one non-null buffer among: ln_bwd_impl.H, ln_bwd_impl.DY, ln_bwd_impl.DX");
    return -1;
  }
  int32_t rows = ((int32_t)((int64_t*)ln_bwd_impl_H_shape)[0]);
  void* ln_bwd_impl_H_strides = (((DLTensor*)H_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)H_handle)[0].device.device_id);
  void* H = (((DLTensor*)H_handle)[0].data);
  if (!(((((DLTensor*)G_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input G ndim mismatch, expected 1", (long long)((((DLTensor*)G_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* ln_bwd_impl_G_strides = (((DLTensor*)G_handle)[0].strides);
  void* G = (((DLTensor*)G_handle)[0].data);
  if (!(((((DLTensor*)DY_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input DY ndim mismatch, expected 2", (long long)((((DLTensor*)DY_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* ln_bwd_impl_DY_strides = (((DLTensor*)DY_handle)[0].strides);
  void* DY = (((DLTensor*)DY_handle)[0].data);
  if (!(((((DLTensor*)DX_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input DX ndim mismatch, expected 2", (long long)((((DLTensor*)DX_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* ln_bwd_impl_DX_strides = (((DLTensor*)DX_handle)[0].strides);
  void* DX = (((DLTensor*)DX_handle)[0].data);
  if (!(((((DLTensor*)Dg_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input Dg ndim mismatch, expected 1", (long long)((((DLTensor*)Dg_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* ln_bwd_impl_Dg_strides = (((DLTensor*)Dg_handle)[0].strides);
  void* Dg = (((DLTensor*)Dg_handle)[0].data);
  if (!(((((DLTensor*)Db_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input Db ndim mismatch, expected 1", (long long)((((DLTensor*)Db_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* ln_bwd_impl_Db_strides = (((DLTensor*)Db_handle)[0].strides);
  void* Db = (((DLTensor*)Db_handle)[0].data);
  if (!(((((((DLTensor*)H_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)H_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)H_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel ln_bwd_impl input H dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)ln_bwd_impl_H_shape)[1]) == 32))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input H shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)ln_bwd_impl_H_shape)[1])), (long long)(32));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval;
  if ((ln_bwd_impl_H_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)ln_bwd_impl_H_strides)[1]);
  }
  if (!((condval == 1))) {
    int32_t condval_1;
    if ((ln_bwd_impl_H_strides == NULL)) {
      condval_1 = 1;
    } else {
      condval_1 = ((int32_t)((int64_t*)ln_bwd_impl_H_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input H strides[1] violates packed ABI constraint", (long long)(condval_1), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((ln_bwd_impl_H_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)ln_bwd_impl_H_strides)[0]);
  }
  if (!(((condval_2 == 32) || (rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel ln_bwd_impl input H strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)H_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input H byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)H_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)H_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input H device_type mismatch, expected ext_dev", (long long)((((DLTensor*)H_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(H == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel ln_bwd_impl input H data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)G_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)G_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)G_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel ln_bwd_impl input G dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)ln_bwd_impl_G_shape)[0]) == 32))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input G shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)ln_bwd_impl_G_shape)[0])), (long long)(32));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((ln_bwd_impl_G_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)ln_bwd_impl_G_strides)[0]);
  }
  if (!((condval_3 == 1))) {
    int32_t condval_4;
    if ((ln_bwd_impl_G_strides == NULL)) {
      condval_4 = 1;
    } else {
      condval_4 = ((int32_t)((int64_t*)ln_bwd_impl_G_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input G strides[0] violates packed ABI constraint", (long long)(condval_4), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)G_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input G byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)G_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)G_handle)[0].device.device_id) == (((DLTensor*)H_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input G device_id violates packed ABI constraint", (long long)((((DLTensor*)G_handle)[0].device.device_id)), (long long)((((DLTensor*)H_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)G_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input G device_type mismatch, expected ext_dev", (long long)((((DLTensor*)G_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(G == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel ln_bwd_impl input G data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)DY_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)DY_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)DY_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel ln_bwd_impl input DY dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)ln_bwd_impl_H_shape)[0]) == ((int32_t)((int64_t*)ln_bwd_impl_DY_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input DY shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)ln_bwd_impl_H_shape)[0])), (long long)(((int32_t)((int64_t*)ln_bwd_impl_DY_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)ln_bwd_impl_DY_shape)[1]) == 32))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input DY shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)ln_bwd_impl_DY_shape)[1])), (long long)(32));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_5;
  if ((ln_bwd_impl_DY_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)ln_bwd_impl_DY_strides)[1]);
  }
  if (!((condval_5 == 1))) {
    int32_t condval_6;
    if ((ln_bwd_impl_DY_strides == NULL)) {
      condval_6 = 1;
    } else {
      condval_6 = ((int32_t)((int64_t*)ln_bwd_impl_DY_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input DY strides[1] violates packed ABI constraint", (long long)(condval_6), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_7;
  if ((ln_bwd_impl_DY_strides == NULL)) {
    condval_7 = 1;
  } else {
    condval_7 = ((int32_t)((int64_t*)ln_bwd_impl_DY_strides)[0]);
  }
  if (!(((condval_7 == 32) || (rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel ln_bwd_impl input DY strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)DY_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input DY byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)DY_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)DY_handle)[0].device.device_id) == (((DLTensor*)H_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input DY device_id violates packed ABI constraint", (long long)((((DLTensor*)DY_handle)[0].device.device_id)), (long long)((((DLTensor*)H_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)DY_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input DY device_type mismatch, expected ext_dev", (long long)((((DLTensor*)DY_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(DY == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel ln_bwd_impl input DY data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)DX_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)DX_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)DX_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel ln_bwd_impl input DX dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)ln_bwd_impl_H_shape)[0]) == ((int32_t)((int64_t*)ln_bwd_impl_DX_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input DX shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)ln_bwd_impl_H_shape)[0])), (long long)(((int32_t)((int64_t*)ln_bwd_impl_DX_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)ln_bwd_impl_DX_shape)[1]) == 32))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input DX shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)ln_bwd_impl_DX_shape)[1])), (long long)(32));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_8;
  if ((ln_bwd_impl_DX_strides == NULL)) {
    condval_8 = 1;
  } else {
    condval_8 = ((int32_t)((int64_t*)ln_bwd_impl_DX_strides)[1]);
  }
  if (!((condval_8 == 1))) {
    int32_t condval_9;
    if ((ln_bwd_impl_DX_strides == NULL)) {
      condval_9 = 1;
    } else {
      condval_9 = ((int32_t)((int64_t*)ln_bwd_impl_DX_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input DX strides[1] violates packed ABI constraint", (long long)(condval_9), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_10;
  if ((ln_bwd_impl_DX_strides == NULL)) {
    condval_10 = 1;
  } else {
    condval_10 = ((int32_t)((int64_t*)ln_bwd_impl_DX_strides)[0]);
  }
  if (!(((condval_10 == 32) || (rows == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel ln_bwd_impl input DX strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)DX_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input DX byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)DX_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)DX_handle)[0].device.device_id) == (((DLTensor*)H_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input DX device_id violates packed ABI constraint", (long long)((((DLTensor*)DX_handle)[0].device.device_id)), (long long)((((DLTensor*)H_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)DX_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input DX device_type mismatch, expected ext_dev", (long long)((((DLTensor*)DX_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((rows == 0) || !(DX == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel ln_bwd_impl input DX data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Dg_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Dg_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Dg_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel ln_bwd_impl input Dg dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)ln_bwd_impl_Dg_shape)[0]) == 32))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input Dg shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)ln_bwd_impl_Dg_shape)[0])), (long long)(32));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_11;
  if ((ln_bwd_impl_Dg_strides == NULL)) {
    condval_11 = 1;
  } else {
    condval_11 = ((int32_t)((int64_t*)ln_bwd_impl_Dg_strides)[0]);
  }
  if (!((condval_11 == 1))) {
    int32_t condval_12;
    if ((ln_bwd_impl_Dg_strides == NULL)) {
      condval_12 = 1;
    } else {
      condval_12 = ((int32_t)((int64_t*)ln_bwd_impl_Dg_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input Dg strides[0] violates packed ABI constraint", (long long)(condval_12), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Dg_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input Dg byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Dg_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Dg_handle)[0].device.device_id) == (((DLTensor*)H_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input Dg device_id violates packed ABI constraint", (long long)((((DLTensor*)Dg_handle)[0].device.device_id)), (long long)((((DLTensor*)H_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Dg_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input Dg device_type mismatch, expected ext_dev", (long long)((((DLTensor*)Dg_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(Dg == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel ln_bwd_impl input Dg data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Db_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Db_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Db_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel ln_bwd_impl input Db dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)ln_bwd_impl_Db_shape)[0]) == 32))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input Db shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)ln_bwd_impl_Db_shape)[0])), (long long)(32));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_13;
  if ((ln_bwd_impl_Db_strides == NULL)) {
    condval_13 = 1;
  } else {
    condval_13 = ((int32_t)((int64_t*)ln_bwd_impl_Db_strides)[0]);
  }
  if (!((condval_13 == 1))) {
    int32_t condval_14;
    if ((ln_bwd_impl_Db_strides == NULL)) {
      condval_14 = 1;
    } else {
      condval_14 = ((int32_t)((int64_t*)ln_bwd_impl_Db_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input Db strides[0] violates packed ABI constraint", (long long)(condval_14), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Db_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input Db byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Db_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Db_handle)[0].device.device_id) == (((DLTensor*)H_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input Db device_id violates packed ABI constraint", (long long)((((DLTensor*)Db_handle)[0].device.device_id)), (long long)((((DLTensor*)H_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Db_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel ln_bwd_impl input Db device_type mismatch, expected ext_dev", (long long)((((DLTensor*)Db_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(Db == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel ln_bwd_impl input Db data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)12);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (DX == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = DX;
  if (DY == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = DY;
  if (Db == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = Db;
  if (Dg == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = Dg;
  if (G == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = G;
  if (H == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_ptr) = H;
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = ((int64_t)rows);
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = (int64_t)4224;
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = (int64_t)0;
  if (ln_bwd_impl_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "ln_bwd_impl_kernel", &ln_bwd_impl_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(ln_bwd_impl_kernel_packed, (TVMFFIAny*) stack_ffi_any, 9, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_ln_bwd_impl(self, args, num_args, result);
}
