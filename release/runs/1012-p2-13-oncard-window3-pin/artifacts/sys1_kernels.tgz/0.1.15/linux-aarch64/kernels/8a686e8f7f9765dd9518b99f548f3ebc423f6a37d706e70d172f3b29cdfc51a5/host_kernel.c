// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* scatter_impl_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_scatter_impl(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_scatter_impl(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[7];
  void* stack_ffi_any = stack;
  if (!((num_args == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "scatter_impl: num_args should be 3", (long long)(num_args), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "scatter_impl: args pointer is NULL");
    return -1;
  }
  int32_t GOut_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((GOut_handle_type_index == 0) || (GOut_handle_type_index == 4)) || (GOut_handle_type_index == 7)) || (64 <= GOut_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel scatter_impl input GOut expected pointer or tensor handle");
    return -1;
  }
  int32_t Idx_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((Idx_handle_type_index == 0) || (Idx_handle_type_index == 4)) || (Idx_handle_type_index == 7)) || (64 <= Idx_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel scatter_impl input Idx expected pointer or tensor handle");
    return -1;
  }
  int32_t GRows_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((GRows_handle_type_index == 0) || (GRows_handle_type_index == 4)) || (GRows_handle_type_index == 7)) || (64 <= GRows_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel scatter_impl input GRows expected pointer or tensor handle");
    return -1;
  }
  void* GOut_handle = ((GOut_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* Idx_handle = ((Idx_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* GRows_handle = ((GRows_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  bool scatter_impl_GOut_is_null = (GOut_handle == NULL);
  if (!(!scatter_impl_GOut_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "scatter_impl.GOut is expected to have non-NULL pointer");
    return -1;
  }
  bool scatter_impl_Idx_is_null = (Idx_handle == NULL);
  if (!(!scatter_impl_Idx_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "scatter_impl.Idx is expected to have non-NULL pointer");
    return -1;
  }
  bool scatter_impl_GRows_is_null = (GRows_handle == NULL);
  if (!(!scatter_impl_GRows_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "scatter_impl.GRows is expected to have non-NULL pointer");
    return -1;
  }
  void* scatter_impl_GOut_shape = (((DLTensor*)GOut_handle)[0].shape);
  void* scatter_impl_Idx_shape = (((DLTensor*)Idx_handle)[0].shape);
  void* scatter_impl_GRows_shape = (((DLTensor*)GRows_handle)[0].shape);
  if (!(((((DLTensor*)GOut_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel scatter_impl input GOut ndim mismatch, expected 2", (long long)((((DLTensor*)GOut_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable picked requires at least one non-null buffer among: scatter_impl.GOut, scatter_impl.Idx");
    return -1;
  }
  int32_t picked = ((int32_t)((int64_t*)scatter_impl_GOut_shape)[0]);
  void* scatter_impl_GOut_strides = (((DLTensor*)GOut_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)GOut_handle)[0].device.device_id);
  void* GOut = (((DLTensor*)GOut_handle)[0].data);
  if (!(((((DLTensor*)Idx_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel scatter_impl input Idx ndim mismatch, expected 1", (long long)((((DLTensor*)Idx_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* scatter_impl_Idx_strides = (((DLTensor*)Idx_handle)[0].strides);
  void* Idx = (((DLTensor*)Idx_handle)[0].data);
  if (!(((((DLTensor*)GRows_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel scatter_impl input GRows ndim mismatch, expected 2", (long long)((((DLTensor*)GRows_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t total = ((int32_t)((int64_t*)scatter_impl_GRows_shape)[0]);
  void* scatter_impl_GRows_strides = (((DLTensor*)GRows_handle)[0].strides);
  void* GRows = (((DLTensor*)GRows_handle)[0].data);
  if (!(((((((DLTensor*)GOut_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)GOut_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)GOut_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel scatter_impl input GOut dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)scatter_impl_GOut_shape)[1]) == 32))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel scatter_impl input GOut shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)scatter_impl_GOut_shape)[1])), (long long)(32));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval;
  if ((scatter_impl_GOut_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)scatter_impl_GOut_strides)[1]);
  }
  if (!((condval == 1))) {
    int32_t condval_1;
    if ((scatter_impl_GOut_strides == NULL)) {
      condval_1 = 1;
    } else {
      condval_1 = ((int32_t)((int64_t*)scatter_impl_GOut_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel scatter_impl input GOut strides[1] violates packed ABI constraint", (long long)(condval_1), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((scatter_impl_GOut_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)scatter_impl_GOut_strides)[0]);
  }
  if (!(((condval_2 == 32) || (picked == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel scatter_impl input GOut strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)GOut_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel scatter_impl input GOut byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)GOut_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)GOut_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel scatter_impl input GOut device_type mismatch, expected ext_dev", (long long)((((DLTensor*)GOut_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((picked == 0) || !(GOut == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel scatter_impl input GOut data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Idx_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)Idx_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Idx_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel scatter_impl input Idx dtype mismatch, expected int32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)scatter_impl_GOut_shape)[0]) == ((int32_t)((int64_t*)scatter_impl_Idx_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel scatter_impl input Idx shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)scatter_impl_GOut_shape)[0])), (long long)(((int32_t)((int64_t*)scatter_impl_Idx_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((scatter_impl_Idx_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)scatter_impl_Idx_strides)[0]);
  }
  if (!(((condval_3 == 1) || (picked == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel scatter_impl input Idx strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Idx_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel scatter_impl input Idx byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Idx_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Idx_handle)[0].device.device_id) == (((DLTensor*)GOut_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel scatter_impl input Idx device_id violates packed ABI constraint", (long long)((((DLTensor*)Idx_handle)[0].device.device_id)), (long long)((((DLTensor*)GOut_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Idx_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel scatter_impl input Idx device_type mismatch, expected ext_dev", (long long)((((DLTensor*)Idx_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((picked == 0) || !(Idx == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel scatter_impl input Idx data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)GRows_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)GRows_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)GRows_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel scatter_impl input GRows dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)scatter_impl_GRows_shape)[1]) == 32))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel scatter_impl input GRows shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)scatter_impl_GRows_shape)[1])), (long long)(32));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_4;
  if ((scatter_impl_GRows_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)scatter_impl_GRows_strides)[1]);
  }
  if (!((condval_4 == 1))) {
    int32_t condval_5;
    if ((scatter_impl_GRows_strides == NULL)) {
      condval_5 = 1;
    } else {
      condval_5 = ((int32_t)((int64_t*)scatter_impl_GRows_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel scatter_impl input GRows strides[1] violates packed ABI constraint", (long long)(condval_5), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_6;
  if ((scatter_impl_GRows_strides == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)scatter_impl_GRows_strides)[0]);
  }
  if (!(((condval_6 == 32) || (total == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel scatter_impl input GRows strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)GRows_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel scatter_impl input GRows byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)GRows_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)GRows_handle)[0].device.device_id) == (((DLTensor*)GOut_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel scatter_impl input GRows device_id violates packed ABI constraint", (long long)((((DLTensor*)GRows_handle)[0].device.device_id)), (long long)((((DLTensor*)GOut_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)GRows_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel scatter_impl input GRows device_type mismatch, expected ext_dev", (long long)((((DLTensor*)GRows_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((total == 0) || !(GRows == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel scatter_impl input GRows data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)12);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (GOut == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = GOut;
  if (GRows == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = GRows;
  if (Idx == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = Idx;
  (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = ((int64_t)picked);
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = ((int64_t)total);
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = (int64_t)0;
  if (scatter_impl_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "scatter_impl_kernel", &scatter_impl_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(scatter_impl_kernel_packed, (TVMFFIAny*) stack_ffi_any, 6, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_scatter_impl(self, args, num_args, result);
}
