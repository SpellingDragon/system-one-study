// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* gdn_delta_fwd_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_gdn_delta_fwd(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_gdn_delta_fwd(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[12];
  void* stack_ffi_any = stack;
  if (!((num_args == 9))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "gdn_delta_fwd: num_args should be 9", (long long)(num_args), (long long)(9));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_delta_fwd: args pointer is NULL");
    return -1;
  }
  int32_t Q_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((Q_handle_type_index == 0) || (Q_handle_type_index == 4)) || (Q_handle_type_index == 7)) || (64 <= Q_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input Q expected pointer or tensor handle");
    return -1;
  }
  int32_t K_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((K_handle_type_index == 0) || (K_handle_type_index == 4)) || (K_handle_type_index == 7)) || (64 <= K_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input K expected pointer or tensor handle");
    return -1;
  }
  int32_t V_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((V_handle_type_index == 0) || (V_handle_type_index == 4)) || (V_handle_type_index == 7)) || (64 <= V_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input V expected pointer or tensor handle");
    return -1;
  }
  int32_t BETA_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((BETA_handle_type_index == 0) || (BETA_handle_type_index == 4)) || (BETA_handle_type_index == 7)) || (64 <= BETA_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input BETA expected pointer or tensor handle");
    return -1;
  }
  int32_t G_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((G_handle_type_index == 0) || (G_handle_type_index == 4)) || (G_handle_type_index == 7)) || (64 <= G_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input G expected pointer or tensor handle");
    return -1;
  }
  int32_t H0_handle_type_index = (((TVMFFIAny*)args)[5].type_index);
  if (!(((((H0_handle_type_index == 0) || (H0_handle_type_index == 4)) || (H0_handle_type_index == 7)) || (64 <= H0_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input H0 expected pointer or tensor handle");
    return -1;
  }
  int32_t HIST_handle_type_index = (((TVMFFIAny*)args)[6].type_index);
  if (!(((((HIST_handle_type_index == 0) || (HIST_handle_type_index == 4)) || (HIST_handle_type_index == 7)) || (64 <= HIST_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input HIST expected pointer or tensor handle");
    return -1;
  }
  int32_t SOUT_handle_type_index = (((TVMFFIAny*)args)[7].type_index);
  if (!(((((SOUT_handle_type_index == 0) || (SOUT_handle_type_index == 4)) || (SOUT_handle_type_index == 7)) || (64 <= SOUT_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input SOUT expected pointer or tensor handle");
    return -1;
  }
  int32_t O_handle_type_index = (((TVMFFIAny*)args)[8].type_index);
  if (!(((((O_handle_type_index == 0) || (O_handle_type_index == 4)) || (O_handle_type_index == 7)) || (64 <= O_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input O expected pointer or tensor handle");
    return -1;
  }
  void* Q_handle = ((Q_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* K_handle = ((K_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* V_handle = ((V_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* BETA_handle = ((BETA_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* G_handle = ((G_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  void* H0_handle = ((H0_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[5].v_ptr) + 24)) : (((TVMFFIAny*)args)[5].v_ptr));
  void* HIST_handle = ((HIST_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[6].v_ptr) + 24)) : (((TVMFFIAny*)args)[6].v_ptr));
  void* SOUT_handle = ((SOUT_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[7].v_ptr) + 24)) : (((TVMFFIAny*)args)[7].v_ptr));
  void* O_handle = ((O_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[8].v_ptr) + 24)) : (((TVMFFIAny*)args)[8].v_ptr));
  bool gdn_delta_fwd_Q_is_null = (Q_handle == NULL);
  if (!(!gdn_delta_fwd_Q_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_delta_fwd.Q is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_delta_fwd_K_is_null = (K_handle == NULL);
  if (!(!gdn_delta_fwd_K_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_delta_fwd.K is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_delta_fwd_V_is_null = (V_handle == NULL);
  if (!(!gdn_delta_fwd_V_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_delta_fwd.V is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_delta_fwd_BETA_is_null = (BETA_handle == NULL);
  if (!(!gdn_delta_fwd_BETA_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_delta_fwd.BETA is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_delta_fwd_G_is_null = (G_handle == NULL);
  if (!(!gdn_delta_fwd_G_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_delta_fwd.G is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_delta_fwd_H0_is_null = (H0_handle == NULL);
  if (!(!gdn_delta_fwd_H0_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_delta_fwd.H0 is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_delta_fwd_HIST_is_null = (HIST_handle == NULL);
  if (!(!gdn_delta_fwd_HIST_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_delta_fwd.HIST is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_delta_fwd_SOUT_is_null = (SOUT_handle == NULL);
  if (!(!gdn_delta_fwd_SOUT_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_delta_fwd.SOUT is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_delta_fwd_O_is_null = (O_handle == NULL);
  if (!(!gdn_delta_fwd_O_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_delta_fwd.O is expected to have non-NULL pointer");
    return -1;
  }
  void* gdn_delta_fwd_Q_shape = (((DLTensor*)Q_handle)[0].shape);
  void* gdn_delta_fwd_K_shape = (((DLTensor*)K_handle)[0].shape);
  void* gdn_delta_fwd_V_shape = (((DLTensor*)V_handle)[0].shape);
  void* gdn_delta_fwd_BETA_shape = (((DLTensor*)BETA_handle)[0].shape);
  void* gdn_delta_fwd_G_shape = (((DLTensor*)G_handle)[0].shape);
  void* gdn_delta_fwd_H0_shape = (((DLTensor*)H0_handle)[0].shape);
  void* gdn_delta_fwd_HIST_shape = (((DLTensor*)HIST_handle)[0].shape);
  void* gdn_delta_fwd_SOUT_shape = (((DLTensor*)SOUT_handle)[0].shape);
  void* gdn_delta_fwd_O_shape = (((DLTensor*)O_handle)[0].shape);
  if (!(((((DLTensor*)Q_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input Q ndim mismatch, expected 3", (long long)((((DLTensor*)Q_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_delta_fwd_Q_strides = (((DLTensor*)Q_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)Q_handle)[0].device.device_id);
  void* Q = (((DLTensor*)Q_handle)[0].data);
  if (!(((((DLTensor*)K_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input K ndim mismatch, expected 3", (long long)((((DLTensor*)K_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_delta_fwd_K_strides = (((DLTensor*)K_handle)[0].strides);
  void* K = (((DLTensor*)K_handle)[0].data);
  if (!(((((DLTensor*)V_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input V ndim mismatch, expected 3", (long long)((((DLTensor*)V_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_delta_fwd_V_strides = (((DLTensor*)V_handle)[0].strides);
  void* V = (((DLTensor*)V_handle)[0].data);
  if (!(((((DLTensor*)BETA_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input BETA ndim mismatch, expected 2", (long long)((((DLTensor*)BETA_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_delta_fwd_BETA_strides = (((DLTensor*)BETA_handle)[0].strides);
  void* BETA = (((DLTensor*)BETA_handle)[0].data);
  if (!(((((DLTensor*)G_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input G ndim mismatch, expected 2", (long long)((((DLTensor*)G_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_delta_fwd_G_strides = (((DLTensor*)G_handle)[0].strides);
  void* G = (((DLTensor*)G_handle)[0].data);
  if (!(((((DLTensor*)H0_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input H0 ndim mismatch, expected 3", (long long)((((DLTensor*)H0_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_delta_fwd_H0_strides = (((DLTensor*)H0_handle)[0].strides);
  void* H0 = (((DLTensor*)H0_handle)[0].data);
  if (!(((((DLTensor*)HIST_handle)[0].ndim) == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input HIST ndim mismatch, expected 4", (long long)((((DLTensor*)HIST_handle)[0].ndim)), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_delta_fwd_HIST_strides = (((DLTensor*)HIST_handle)[0].strides);
  void* HIST = (((DLTensor*)HIST_handle)[0].data);
  if (!(((((DLTensor*)SOUT_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input SOUT ndim mismatch, expected 3", (long long)((((DLTensor*)SOUT_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_delta_fwd_SOUT_strides = (((DLTensor*)SOUT_handle)[0].strides);
  void* SOUT = (((DLTensor*)SOUT_handle)[0].data);
  if (!(((((DLTensor*)O_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input O ndim mismatch, expected 3", (long long)((((DLTensor*)O_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_delta_fwd_O_strides = (((DLTensor*)O_handle)[0].strides);
  void* O = (((DLTensor*)O_handle)[0].data);
  if (!(((((((DLTensor*)Q_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Q_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Q_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input Q dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_Q_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input Q shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_Q_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_Q_shape)[1]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input Q shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_Q_shape)[1])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_Q_shape)[2]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input Q shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_Q_shape)[2])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval;
  if ((gdn_delta_fwd_Q_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)gdn_delta_fwd_Q_strides)[2]);
  }
  if (!((condval == 1))) {
    int32_t condval_1;
    if ((gdn_delta_fwd_Q_strides == NULL)) {
      condval_1 = 1;
    } else {
      condval_1 = ((int32_t)((int64_t*)gdn_delta_fwd_Q_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input Q strides[2] violates packed ABI constraint", (long long)(condval_1), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((gdn_delta_fwd_Q_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)gdn_delta_fwd_Q_strides)[1]);
  }
  if (!((condval_2 == 8))) {
    int32_t condval_3;
    if ((gdn_delta_fwd_Q_strides == NULL)) {
      condval_3 = 1;
    } else {
      condval_3 = ((int32_t)((int64_t*)gdn_delta_fwd_Q_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input Q strides[1] violates packed ABI constraint", (long long)(condval_3), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_4;
  if ((gdn_delta_fwd_Q_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)gdn_delta_fwd_Q_strides)[0]);
  }
  if (!((condval_4 == 64))) {
    int32_t condval_5;
    if ((gdn_delta_fwd_Q_strides == NULL)) {
      condval_5 = 1;
    } else {
      condval_5 = ((int32_t)((int64_t*)gdn_delta_fwd_Q_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input Q strides[0] violates packed ABI constraint", (long long)(condval_5), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Q_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input Q byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Q_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Q_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input Q device_type mismatch, expected ext_dev", (long long)((((DLTensor*)Q_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(Q == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input Q data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)K_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)K_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)K_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input K dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_K_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input K shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_K_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_K_shape)[1]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input K shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_K_shape)[1])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_K_shape)[2]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input K shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_K_shape)[2])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_6;
  if ((gdn_delta_fwd_K_strides == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)gdn_delta_fwd_K_strides)[2]);
  }
  if (!((condval_6 == 1))) {
    int32_t condval_7;
    if ((gdn_delta_fwd_K_strides == NULL)) {
      condval_7 = 1;
    } else {
      condval_7 = ((int32_t)((int64_t*)gdn_delta_fwd_K_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input K strides[2] violates packed ABI constraint", (long long)(condval_7), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_8;
  if ((gdn_delta_fwd_K_strides == NULL)) {
    condval_8 = 1;
  } else {
    condval_8 = ((int32_t)((int64_t*)gdn_delta_fwd_K_strides)[1]);
  }
  if (!((condval_8 == 8))) {
    int32_t condval_9;
    if ((gdn_delta_fwd_K_strides == NULL)) {
      condval_9 = 1;
    } else {
      condval_9 = ((int32_t)((int64_t*)gdn_delta_fwd_K_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input K strides[1] violates packed ABI constraint", (long long)(condval_9), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_10;
  if ((gdn_delta_fwd_K_strides == NULL)) {
    condval_10 = 1;
  } else {
    condval_10 = ((int32_t)((int64_t*)gdn_delta_fwd_K_strides)[0]);
  }
  if (!((condval_10 == 64))) {
    int32_t condval_11;
    if ((gdn_delta_fwd_K_strides == NULL)) {
      condval_11 = 1;
    } else {
      condval_11 = ((int32_t)((int64_t*)gdn_delta_fwd_K_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input K strides[0] violates packed ABI constraint", (long long)(condval_11), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)K_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input K byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)K_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)K_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input K device_id violates packed ABI constraint", (long long)((((DLTensor*)K_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)K_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input K device_type mismatch, expected ext_dev", (long long)((((DLTensor*)K_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(K == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input K data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)V_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)V_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)V_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input V dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_V_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input V shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_V_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_V_shape)[1]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input V shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_V_shape)[1])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_V_shape)[2]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input V shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_V_shape)[2])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_12;
  if ((gdn_delta_fwd_V_strides == NULL)) {
    condval_12 = 1;
  } else {
    condval_12 = ((int32_t)((int64_t*)gdn_delta_fwd_V_strides)[2]);
  }
  if (!((condval_12 == 1))) {
    int32_t condval_13;
    if ((gdn_delta_fwd_V_strides == NULL)) {
      condval_13 = 1;
    } else {
      condval_13 = ((int32_t)((int64_t*)gdn_delta_fwd_V_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input V strides[2] violates packed ABI constraint", (long long)(condval_13), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_14;
  if ((gdn_delta_fwd_V_strides == NULL)) {
    condval_14 = 1;
  } else {
    condval_14 = ((int32_t)((int64_t*)gdn_delta_fwd_V_strides)[1]);
  }
  if (!((condval_14 == 8))) {
    int32_t condval_15;
    if ((gdn_delta_fwd_V_strides == NULL)) {
      condval_15 = 1;
    } else {
      condval_15 = ((int32_t)((int64_t*)gdn_delta_fwd_V_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input V strides[1] violates packed ABI constraint", (long long)(condval_15), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_16;
  if ((gdn_delta_fwd_V_strides == NULL)) {
    condval_16 = 1;
  } else {
    condval_16 = ((int32_t)((int64_t*)gdn_delta_fwd_V_strides)[0]);
  }
  if (!((condval_16 == 64))) {
    int32_t condval_17;
    if ((gdn_delta_fwd_V_strides == NULL)) {
      condval_17 = 1;
    } else {
      condval_17 = ((int32_t)((int64_t*)gdn_delta_fwd_V_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input V strides[0] violates packed ABI constraint", (long long)(condval_17), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)V_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input V byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)V_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)V_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input V device_id violates packed ABI constraint", (long long)((((DLTensor*)V_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)V_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input V device_type mismatch, expected ext_dev", (long long)((((DLTensor*)V_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(V == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input V data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)BETA_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)BETA_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)BETA_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input BETA dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_BETA_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input BETA shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_BETA_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_BETA_shape)[1]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input BETA shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_BETA_shape)[1])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_18;
  if ((gdn_delta_fwd_BETA_strides == NULL)) {
    condval_18 = 1;
  } else {
    condval_18 = ((int32_t)((int64_t*)gdn_delta_fwd_BETA_strides)[1]);
  }
  if (!((condval_18 == 1))) {
    int32_t condval_19;
    if ((gdn_delta_fwd_BETA_strides == NULL)) {
      condval_19 = 1;
    } else {
      condval_19 = ((int32_t)((int64_t*)gdn_delta_fwd_BETA_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input BETA strides[1] violates packed ABI constraint", (long long)(condval_19), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_20;
  if ((gdn_delta_fwd_BETA_strides == NULL)) {
    condval_20 = 1;
  } else {
    condval_20 = ((int32_t)((int64_t*)gdn_delta_fwd_BETA_strides)[0]);
  }
  if (!((condval_20 == 8))) {
    int32_t condval_21;
    if ((gdn_delta_fwd_BETA_strides == NULL)) {
      condval_21 = 1;
    } else {
      condval_21 = ((int32_t)((int64_t*)gdn_delta_fwd_BETA_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input BETA strides[0] violates packed ABI constraint", (long long)(condval_21), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)BETA_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input BETA byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)BETA_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)BETA_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input BETA device_id violates packed ABI constraint", (long long)((((DLTensor*)BETA_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)BETA_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input BETA device_type mismatch, expected ext_dev", (long long)((((DLTensor*)BETA_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(BETA == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input BETA data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)G_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)G_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)G_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input G dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_G_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input G shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_G_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_G_shape)[1]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input G shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_G_shape)[1])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_22;
  if ((gdn_delta_fwd_G_strides == NULL)) {
    condval_22 = 1;
  } else {
    condval_22 = ((int32_t)((int64_t*)gdn_delta_fwd_G_strides)[1]);
  }
  if (!((condval_22 == 1))) {
    int32_t condval_23;
    if ((gdn_delta_fwd_G_strides == NULL)) {
      condval_23 = 1;
    } else {
      condval_23 = ((int32_t)((int64_t*)gdn_delta_fwd_G_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input G strides[1] violates packed ABI constraint", (long long)(condval_23), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_24;
  if ((gdn_delta_fwd_G_strides == NULL)) {
    condval_24 = 1;
  } else {
    condval_24 = ((int32_t)((int64_t*)gdn_delta_fwd_G_strides)[0]);
  }
  if (!((condval_24 == 8))) {
    int32_t condval_25;
    if ((gdn_delta_fwd_G_strides == NULL)) {
      condval_25 = 1;
    } else {
      condval_25 = ((int32_t)((int64_t*)gdn_delta_fwd_G_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input G strides[0] violates packed ABI constraint", (long long)(condval_25), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)G_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input G byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)G_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)G_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input G device_id violates packed ABI constraint", (long long)((((DLTensor*)G_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)G_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input G device_type mismatch, expected ext_dev", (long long)((((DLTensor*)G_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(G == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input G data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)H0_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)H0_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)H0_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input H0 dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_H0_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input H0 shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_H0_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_H0_shape)[1]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input H0 shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_H0_shape)[1])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_H0_shape)[2]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input H0 shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_H0_shape)[2])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_26;
  if ((gdn_delta_fwd_H0_strides == NULL)) {
    condval_26 = 1;
  } else {
    condval_26 = ((int32_t)((int64_t*)gdn_delta_fwd_H0_strides)[2]);
  }
  if (!((condval_26 == 1))) {
    int32_t condval_27;
    if ((gdn_delta_fwd_H0_strides == NULL)) {
      condval_27 = 1;
    } else {
      condval_27 = ((int32_t)((int64_t*)gdn_delta_fwd_H0_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input H0 strides[2] violates packed ABI constraint", (long long)(condval_27), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_28;
  if ((gdn_delta_fwd_H0_strides == NULL)) {
    condval_28 = 1;
  } else {
    condval_28 = ((int32_t)((int64_t*)gdn_delta_fwd_H0_strides)[1]);
  }
  if (!((condval_28 == 8))) {
    int32_t condval_29;
    if ((gdn_delta_fwd_H0_strides == NULL)) {
      condval_29 = 1;
    } else {
      condval_29 = ((int32_t)((int64_t*)gdn_delta_fwd_H0_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input H0 strides[1] violates packed ABI constraint", (long long)(condval_29), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_30;
  if ((gdn_delta_fwd_H0_strides == NULL)) {
    condval_30 = 1;
  } else {
    condval_30 = ((int32_t)((int64_t*)gdn_delta_fwd_H0_strides)[0]);
  }
  if (!((condval_30 == 64))) {
    int32_t condval_31;
    if ((gdn_delta_fwd_H0_strides == NULL)) {
      condval_31 = 1;
    } else {
      condval_31 = ((int32_t)((int64_t*)gdn_delta_fwd_H0_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input H0 strides[0] violates packed ABI constraint", (long long)(condval_31), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)H0_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input H0 byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)H0_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)H0_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input H0 device_id violates packed ABI constraint", (long long)((((DLTensor*)H0_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)H0_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input H0 device_type mismatch, expected ext_dev", (long long)((((DLTensor*)H0_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(H0 == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input H0 data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)HIST_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)HIST_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)HIST_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input HIST dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_HIST_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input HIST shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_HIST_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_HIST_shape)[1]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input HIST shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_HIST_shape)[1])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_HIST_shape)[2]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input HIST shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_HIST_shape)[2])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_HIST_shape)[3]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input HIST shape[3] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_HIST_shape)[3])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_32;
  if ((gdn_delta_fwd_HIST_strides == NULL)) {
    condval_32 = 1;
  } else {
    condval_32 = ((int32_t)((int64_t*)gdn_delta_fwd_HIST_strides)[3]);
  }
  if (!((condval_32 == 1))) {
    int32_t condval_33;
    if ((gdn_delta_fwd_HIST_strides == NULL)) {
      condval_33 = 1;
    } else {
      condval_33 = ((int32_t)((int64_t*)gdn_delta_fwd_HIST_strides)[3]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input HIST strides[3] violates packed ABI constraint", (long long)(condval_33), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_34;
  if ((gdn_delta_fwd_HIST_strides == NULL)) {
    condval_34 = 1;
  } else {
    condval_34 = ((int32_t)((int64_t*)gdn_delta_fwd_HIST_strides)[2]);
  }
  if (!((condval_34 == 8))) {
    int32_t condval_35;
    if ((gdn_delta_fwd_HIST_strides == NULL)) {
      condval_35 = 1;
    } else {
      condval_35 = ((int32_t)((int64_t*)gdn_delta_fwd_HIST_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input HIST strides[2] violates packed ABI constraint", (long long)(condval_35), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_36;
  if ((gdn_delta_fwd_HIST_strides == NULL)) {
    condval_36 = 1;
  } else {
    condval_36 = ((int32_t)((int64_t*)gdn_delta_fwd_HIST_strides)[1]);
  }
  if (!((condval_36 == 64))) {
    int32_t condval_37;
    if ((gdn_delta_fwd_HIST_strides == NULL)) {
      condval_37 = 1;
    } else {
      condval_37 = ((int32_t)((int64_t*)gdn_delta_fwd_HIST_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input HIST strides[1] violates packed ABI constraint", (long long)(condval_37), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_38;
  if ((gdn_delta_fwd_HIST_strides == NULL)) {
    condval_38 = 1;
  } else {
    condval_38 = ((int32_t)((int64_t*)gdn_delta_fwd_HIST_strides)[0]);
  }
  if (!((condval_38 == 512))) {
    int32_t condval_39;
    if ((gdn_delta_fwd_HIST_strides == NULL)) {
      condval_39 = 1;
    } else {
      condval_39 = ((int32_t)((int64_t*)gdn_delta_fwd_HIST_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input HIST strides[0] violates packed ABI constraint", (long long)(condval_39), (long long)(512));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)HIST_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input HIST byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)HIST_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)HIST_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input HIST device_id violates packed ABI constraint", (long long)((((DLTensor*)HIST_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)HIST_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input HIST device_type mismatch, expected ext_dev", (long long)((((DLTensor*)HIST_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(HIST == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input HIST data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)SOUT_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)SOUT_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)SOUT_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input SOUT dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_SOUT_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input SOUT shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_SOUT_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_SOUT_shape)[1]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input SOUT shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_SOUT_shape)[1])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_SOUT_shape)[2]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input SOUT shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_SOUT_shape)[2])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_40;
  if ((gdn_delta_fwd_SOUT_strides == NULL)) {
    condval_40 = 1;
  } else {
    condval_40 = ((int32_t)((int64_t*)gdn_delta_fwd_SOUT_strides)[2]);
  }
  if (!((condval_40 == 1))) {
    int32_t condval_41;
    if ((gdn_delta_fwd_SOUT_strides == NULL)) {
      condval_41 = 1;
    } else {
      condval_41 = ((int32_t)((int64_t*)gdn_delta_fwd_SOUT_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input SOUT strides[2] violates packed ABI constraint", (long long)(condval_41), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_42;
  if ((gdn_delta_fwd_SOUT_strides == NULL)) {
    condval_42 = 1;
  } else {
    condval_42 = ((int32_t)((int64_t*)gdn_delta_fwd_SOUT_strides)[1]);
  }
  if (!((condval_42 == 8))) {
    int32_t condval_43;
    if ((gdn_delta_fwd_SOUT_strides == NULL)) {
      condval_43 = 1;
    } else {
      condval_43 = ((int32_t)((int64_t*)gdn_delta_fwd_SOUT_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input SOUT strides[1] violates packed ABI constraint", (long long)(condval_43), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_44;
  if ((gdn_delta_fwd_SOUT_strides == NULL)) {
    condval_44 = 1;
  } else {
    condval_44 = ((int32_t)((int64_t*)gdn_delta_fwd_SOUT_strides)[0]);
  }
  if (!((condval_44 == 64))) {
    int32_t condval_45;
    if ((gdn_delta_fwd_SOUT_strides == NULL)) {
      condval_45 = 1;
    } else {
      condval_45 = ((int32_t)((int64_t*)gdn_delta_fwd_SOUT_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input SOUT strides[0] violates packed ABI constraint", (long long)(condval_45), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)SOUT_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input SOUT byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)SOUT_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)SOUT_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input SOUT device_id violates packed ABI constraint", (long long)((((DLTensor*)SOUT_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)SOUT_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input SOUT device_type mismatch, expected ext_dev", (long long)((((DLTensor*)SOUT_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(SOUT == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input SOUT data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)O_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)O_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)O_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input O dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_O_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input O shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_O_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_O_shape)[1]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input O shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_O_shape)[1])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_delta_fwd_O_shape)[2]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input O shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_delta_fwd_O_shape)[2])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_46;
  if ((gdn_delta_fwd_O_strides == NULL)) {
    condval_46 = 1;
  } else {
    condval_46 = ((int32_t)((int64_t*)gdn_delta_fwd_O_strides)[2]);
  }
  if (!((condval_46 == 1))) {
    int32_t condval_47;
    if ((gdn_delta_fwd_O_strides == NULL)) {
      condval_47 = 1;
    } else {
      condval_47 = ((int32_t)((int64_t*)gdn_delta_fwd_O_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input O strides[2] violates packed ABI constraint", (long long)(condval_47), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_48;
  if ((gdn_delta_fwd_O_strides == NULL)) {
    condval_48 = 1;
  } else {
    condval_48 = ((int32_t)((int64_t*)gdn_delta_fwd_O_strides)[1]);
  }
  if (!((condval_48 == 8))) {
    int32_t condval_49;
    if ((gdn_delta_fwd_O_strides == NULL)) {
      condval_49 = 1;
    } else {
      condval_49 = ((int32_t)((int64_t*)gdn_delta_fwd_O_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input O strides[1] violates packed ABI constraint", (long long)(condval_49), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_50;
  if ((gdn_delta_fwd_O_strides == NULL)) {
    condval_50 = 1;
  } else {
    condval_50 = ((int32_t)((int64_t*)gdn_delta_fwd_O_strides)[0]);
  }
  if (!((condval_50 == 64))) {
    int32_t condval_51;
    if ((gdn_delta_fwd_O_strides == NULL)) {
      condval_51 = 1;
    } else {
      condval_51 = ((int32_t)((int64_t*)gdn_delta_fwd_O_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input O strides[0] violates packed ABI constraint", (long long)(condval_51), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)O_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input O byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)O_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)O_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input O device_id violates packed ABI constraint", (long long)((((DLTensor*)O_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)O_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_delta_fwd input O device_type mismatch, expected ext_dev", (long long)((((DLTensor*)O_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(O == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_delta_fwd input O data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)12);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (BETA == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = BETA;
  if (G == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = G;
  if (H0 == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = H0;
  if (HIST == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = HIST;
  if (K == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = K;
  if (O == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_ptr) = O;
  if (Q == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_ptr) = Q;
  if (SOUT == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_ptr) = SOUT;
  if (V == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_ptr) = V;
  (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = (int64_t)96;
  (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = (int64_t)0;
  if (gdn_delta_fwd_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "gdn_delta_fwd_kernel", &gdn_delta_fwd_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(gdn_delta_fwd_kernel_packed, (TVMFFIAny*) stack_ffi_any, 11, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_gdn_delta_fwd(self, args, num_args, result);
}
