// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* rope_impl_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_rope_impl(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_rope_impl(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[6];
  void* stack_ffi_any = stack;
  if (!((num_args == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "rope_impl: num_args should be 3", (long long)(num_args), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "rope_impl: args pointer is NULL");
    return -1;
  }
  int32_t QKV_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((QKV_handle_type_index == 0) || (QKV_handle_type_index == 4)) || (QKV_handle_type_index == 7)) || (64 <= QKV_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_impl input QKV expected pointer or tensor handle");
    return -1;
  }
  int32_t Cos_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((Cos_handle_type_index == 0) || (Cos_handle_type_index == 4)) || (Cos_handle_type_index == 7)) || (64 <= Cos_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_impl input Cos expected pointer or tensor handle");
    return -1;
  }
  int32_t Sin_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((Sin_handle_type_index == 0) || (Sin_handle_type_index == 4)) || (Sin_handle_type_index == 7)) || (64 <= Sin_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_impl input Sin expected pointer or tensor handle");
    return -1;
  }
  void* QKV_handle = ((QKV_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* Cos_handle = ((Cos_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* Sin_handle = ((Sin_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  bool rope_impl_QKV_is_null = (QKV_handle == NULL);
  if (!(!rope_impl_QKV_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "rope_impl.QKV is expected to have non-NULL pointer");
    return -1;
  }
  bool rope_impl_Cos_is_null = (Cos_handle == NULL);
  if (!(!rope_impl_Cos_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "rope_impl.Cos is expected to have non-NULL pointer");
    return -1;
  }
  bool rope_impl_Sin_is_null = (Sin_handle == NULL);
  if (!(!rope_impl_Sin_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "rope_impl.Sin is expected to have non-NULL pointer");
    return -1;
  }
  void* rope_impl_QKV_shape = (((DLTensor*)QKV_handle)[0].shape);
  void* rope_impl_Cos_shape = (((DLTensor*)Cos_handle)[0].shape);
  void* rope_impl_Sin_shape = (((DLTensor*)Sin_handle)[0].shape);
  if (!(((((DLTensor*)QKV_handle)[0].ndim) == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input QKV ndim mismatch, expected 4", (long long)((((DLTensor*)QKV_handle)[0].ndim)), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable tokens requires at least one non-null buffer among: rope_impl.QKV, rope_impl.Cos, rope_impl.Sin");
    return -1;
  }
  int32_t tokens = ((int32_t)((int64_t*)rope_impl_QKV_shape)[0]);
  void* rope_impl_QKV_strides = (((DLTensor*)QKV_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)QKV_handle)[0].device.device_id);
  void* QKV = (((DLTensor*)QKV_handle)[0].data);
  if (!(((((DLTensor*)Cos_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input Cos ndim mismatch, expected 2", (long long)((((DLTensor*)Cos_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* rope_impl_Cos_strides = (((DLTensor*)Cos_handle)[0].strides);
  void* Cos = (((DLTensor*)Cos_handle)[0].data);
  if (!(((((DLTensor*)Sin_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input Sin ndim mismatch, expected 2", (long long)((((DLTensor*)Sin_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* rope_impl_Sin_strides = (((DLTensor*)Sin_handle)[0].strides);
  void* Sin = (((DLTensor*)Sin_handle)[0].data);
  if (!(((((((DLTensor*)QKV_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)QKV_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)QKV_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_impl input QKV dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)rope_impl_QKV_shape)[1]) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input QKV shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)rope_impl_QKV_shape)[1])), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)rope_impl_QKV_shape)[2]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input QKV shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)rope_impl_QKV_shape)[2])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)rope_impl_QKV_shape)[3]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input QKV shape[3] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)rope_impl_QKV_shape)[3])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval;
  if ((rope_impl_QKV_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)rope_impl_QKV_strides)[3]);
  }
  if (!((condval == 1))) {
    int32_t condval_1;
    if ((rope_impl_QKV_strides == NULL)) {
      condval_1 = 1;
    } else {
      condval_1 = ((int32_t)((int64_t*)rope_impl_QKV_strides)[3]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input QKV strides[3] violates packed ABI constraint", (long long)(condval_1), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((rope_impl_QKV_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)rope_impl_QKV_strides)[2]);
  }
  if (!((condval_2 == 8))) {
    int32_t condval_3;
    if ((rope_impl_QKV_strides == NULL)) {
      condval_3 = 1;
    } else {
      condval_3 = ((int32_t)((int64_t*)rope_impl_QKV_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input QKV strides[2] violates packed ABI constraint", (long long)(condval_3), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_4;
  if ((rope_impl_QKV_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)rope_impl_QKV_strides)[1]);
  }
  if (!((condval_4 == 16))) {
    int32_t condval_5;
    if ((rope_impl_QKV_strides == NULL)) {
      condval_5 = 1;
    } else {
      condval_5 = ((int32_t)((int64_t*)rope_impl_QKV_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input QKV strides[1] violates packed ABI constraint", (long long)(condval_5), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_6;
  if ((rope_impl_QKV_strides == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)rope_impl_QKV_strides)[0]);
  }
  if (!(((condval_6 == 48) || (tokens == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_impl input QKV strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)QKV_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input QKV byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)QKV_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)QKV_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input QKV device_type mismatch, expected ext_dev", (long long)((((DLTensor*)QKV_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((tokens == 0) || !(QKV == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_impl input QKV data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Cos_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Cos_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Cos_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_impl input Cos dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)rope_impl_QKV_shape)[0]) == ((int32_t)((int64_t*)rope_impl_Cos_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input Cos shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)rope_impl_QKV_shape)[0])), (long long)(((int32_t)((int64_t*)rope_impl_Cos_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)rope_impl_Cos_shape)[1]) == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input Cos shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)rope_impl_Cos_shape)[1])), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_7;
  if ((rope_impl_Cos_strides == NULL)) {
    condval_7 = 1;
  } else {
    condval_7 = ((int32_t)((int64_t*)rope_impl_Cos_strides)[1]);
  }
  if (!((condval_7 == 1))) {
    int32_t condval_8;
    if ((rope_impl_Cos_strides == NULL)) {
      condval_8 = 1;
    } else {
      condval_8 = ((int32_t)((int64_t*)rope_impl_Cos_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input Cos strides[1] violates packed ABI constraint", (long long)(condval_8), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_9;
  if ((rope_impl_Cos_strides == NULL)) {
    condval_9 = 1;
  } else {
    condval_9 = ((int32_t)((int64_t*)rope_impl_Cos_strides)[0]);
  }
  if (!(((condval_9 == 4) || (tokens == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_impl input Cos strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Cos_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input Cos byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Cos_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Cos_handle)[0].device.device_id) == (((DLTensor*)QKV_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input Cos device_id violates packed ABI constraint", (long long)((((DLTensor*)Cos_handle)[0].device.device_id)), (long long)((((DLTensor*)QKV_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Cos_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input Cos device_type mismatch, expected ext_dev", (long long)((((DLTensor*)Cos_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((tokens == 0) || !(Cos == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_impl input Cos data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Sin_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Sin_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Sin_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_impl input Sin dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)rope_impl_QKV_shape)[0]) == ((int32_t)((int64_t*)rope_impl_Sin_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input Sin shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)rope_impl_QKV_shape)[0])), (long long)(((int32_t)((int64_t*)rope_impl_Sin_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)rope_impl_Sin_shape)[1]) == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input Sin shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)rope_impl_Sin_shape)[1])), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_10;
  if ((rope_impl_Sin_strides == NULL)) {
    condval_10 = 1;
  } else {
    condval_10 = ((int32_t)((int64_t*)rope_impl_Sin_strides)[1]);
  }
  if (!((condval_10 == 1))) {
    int32_t condval_11;
    if ((rope_impl_Sin_strides == NULL)) {
      condval_11 = 1;
    } else {
      condval_11 = ((int32_t)((int64_t*)rope_impl_Sin_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input Sin strides[1] violates packed ABI constraint", (long long)(condval_11), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_12;
  if ((rope_impl_Sin_strides == NULL)) {
    condval_12 = 1;
  } else {
    condval_12 = ((int32_t)((int64_t*)rope_impl_Sin_strides)[0]);
  }
  if (!(((condval_12 == 4) || (tokens == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_impl input Sin strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Sin_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input Sin byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Sin_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Sin_handle)[0].device.device_id) == (((DLTensor*)QKV_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input Sin device_id violates packed ABI constraint", (long long)((((DLTensor*)Sin_handle)[0].device.device_id)), (long long)((((DLTensor*)QKV_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Sin_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel rope_impl input Sin device_type mismatch, expected ext_dev", (long long)((((DLTensor*)Sin_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((tokens == 0) || !(Sin == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel rope_impl input Sin data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)12);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (Cos == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = Cos;
  if (QKV == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = QKV;
  if (Sin == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = Sin;
  (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = ((int64_t)tokens);
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = ((int64_t)8);
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = (int64_t)0;
  if (rope_impl_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "rope_impl_kernel", &rope_impl_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(rope_impl_kernel_packed, (TVMFFIAny*) stack_ffi_any, 5, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_rope_impl(self, args, num_args, result);
}
