// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* main_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t TVMFFIEnvTensorAlloc(void*, void*);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[8];
  void* stack_ffi_any = stack;
  if (!((num_args == 5))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "main: num_args should be 5", (long long)(num_args), (long long)(5));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "main: args pointer is NULL");
    return -1;
  }
  int32_t HID_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((HID_handle_type_index == 0) || (HID_handle_type_index == 4)) || (HID_handle_type_index == 7)) || (64 <= HID_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel main input HID expected pointer or tensor handle");
    return -1;
  }
  int32_t POS_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((POS_handle_type_index == 0) || (POS_handle_type_index == 4)) || (POS_handle_type_index == 7)) || (64 <= POS_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel main input POS expected pointer or tensor handle");
    return -1;
  }
  int32_t W_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((W_handle_type_index == 0) || (W_handle_type_index == 4)) || (W_handle_type_index == 7)) || (64 <= W_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel main input W expected pointer or tensor handle");
    return -1;
  }
  int32_t IDS_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((IDS_handle_type_index == 0) || (IDS_handle_type_index == 4)) || (IDS_handle_type_index == 7)) || (64 <= IDS_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel main input IDS expected pointer or tensor handle");
    return -1;
  }
  int32_t allocator_anchor_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!((allocator_anchor_type_index == 70))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "main: allocator anchor must be a Tensor", (long long)(allocator_anchor_type_index), (long long)(70));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!((((TVMFFIAny*)args)[4].v_ptr) == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "main: allocator anchor is NULL");
    return -1;
  }
  if (!(((((DLTensor*)((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + (int64_t)24)))[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "main: allocator anchor has the wrong device type", (long long)((((DLTensor*)((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + (int64_t)24)))[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t dev_id = (((DLTensor*)((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + (int64_t)24)))[0].device.device_id);
  void* HID_handle = ((HID_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* POS_handle = ((POS_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* W_handle = ((W_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* IDS_handle = ((IDS_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  bool main_HID_is_null = (HID_handle == NULL);
  if (!(!main_HID_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "main.HID is expected to have non-NULL pointer");
    return -1;
  }
  bool main_POS_is_null = (POS_handle == NULL);
  if (!(!main_POS_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "main.POS is expected to have non-NULL pointer");
    return -1;
  }
  bool main_W_is_null = (W_handle == NULL);
  if (!(!main_W_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "main.W is expected to have non-NULL pointer");
    return -1;
  }
  bool main_IDS_is_null = (IDS_handle == NULL);
  if (!(!main_IDS_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "main.IDS is expected to have non-NULL pointer");
    return -1;
  }
  void* main_HID_shape = (((DLTensor*)HID_handle)[0].shape);
  void* main_POS_shape = (((DLTensor*)POS_handle)[0].shape);
  void* main_W_shape = (((DLTensor*)W_handle)[0].shape);
  void* main_IDS_shape = (((DLTensor*)IDS_handle)[0].shape);
  if (!(((((DLTensor*)HID_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input HID ndim mismatch, expected 3", (long long)((((DLTensor*)HID_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* main_HID_strides = (((DLTensor*)HID_handle)[0].strides);
  void* HID = (((DLTensor*)HID_handle)[0].data);
  if (!(((((DLTensor*)POS_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input POS ndim mismatch, expected 1", (long long)((((DLTensor*)POS_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* main_POS_strides = (((DLTensor*)POS_handle)[0].strides);
  void* POS = (((DLTensor*)POS_handle)[0].data);
  if (!(((((DLTensor*)W_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input W ndim mismatch, expected 2", (long long)((((DLTensor*)W_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* main_W_strides = (((DLTensor*)W_handle)[0].strides);
  void* W = (((DLTensor*)W_handle)[0].data);
  if (!(((((DLTensor*)IDS_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input IDS ndim mismatch, expected 1", (long long)((((DLTensor*)IDS_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* main_IDS_strides = (((DLTensor*)IDS_handle)[0].strides);
  void* IDS = (((DLTensor*)IDS_handle)[0].data);
  if (!(((((((DLTensor*)HID_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)HID_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)HID_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel main input HID dtype mismatch, expected float16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)main_HID_shape)[0]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input HID shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)main_HID_shape)[0])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)main_HID_shape)[1]) == 32))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input HID shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)main_HID_shape)[1])), (long long)(32));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)main_HID_shape)[2]) == 512))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input HID shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)main_HID_shape)[2])), (long long)(512));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval;
  if ((main_HID_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)main_HID_strides)[2]);
  }
  if (!((condval == 1))) {
    int32_t condval_1;
    if ((main_HID_strides == NULL)) {
      condval_1 = 1;
    } else {
      condval_1 = ((int32_t)((int64_t*)main_HID_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input HID strides[2] violates packed ABI constraint", (long long)(condval_1), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((main_HID_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)main_HID_strides)[1]);
  }
  if (!((condval_2 == 512))) {
    int32_t condval_3;
    if ((main_HID_strides == NULL)) {
      condval_3 = 1;
    } else {
      condval_3 = ((int32_t)((int64_t*)main_HID_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input HID strides[1] violates packed ABI constraint", (long long)(condval_3), (long long)(512));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_4;
  if ((main_HID_strides == NULL)) {
    condval_4 = 1;
  } else {
    condval_4 = ((int32_t)((int64_t*)main_HID_strides)[0]);
  }
  if (!((condval_4 == 16384))) {
    int32_t condval_5;
    if ((main_HID_strides == NULL)) {
      condval_5 = 1;
    } else {
      condval_5 = ((int32_t)((int64_t*)main_HID_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input HID strides[0] violates packed ABI constraint", (long long)(condval_5), (long long)(16384));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)HID_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input HID byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)HID_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)HID_handle)[0].device.device_id) == dev_id))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input HID device_id violates packed ABI constraint", (long long)((((DLTensor*)HID_handle)[0].device.device_id)), (long long)(dev_id));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)HID_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input HID device_type mismatch, expected ext_dev", (long long)((((DLTensor*)HID_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(HID == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel main input HID data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)POS_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)POS_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)POS_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel main input POS dtype mismatch, expected int32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)main_POS_shape)[0]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input POS shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)main_POS_shape)[0])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_6;
  if ((main_POS_strides == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)main_POS_strides)[0]);
  }
  if (!((condval_6 == 1))) {
    int32_t condval_7;
    if ((main_POS_strides == NULL)) {
      condval_7 = 1;
    } else {
      condval_7 = ((int32_t)((int64_t*)main_POS_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input POS strides[0] violates packed ABI constraint", (long long)(condval_7), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)POS_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input POS byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)POS_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)POS_handle)[0].device.device_id) == dev_id))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input POS device_id violates packed ABI constraint", (long long)((((DLTensor*)POS_handle)[0].device.device_id)), (long long)(dev_id));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)POS_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input POS device_type mismatch, expected ext_dev", (long long)((((DLTensor*)POS_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(POS == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel main input POS data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)W_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)W_handle)[0].dtype.bits) == (uint8_t)16)) && ((((DLTensor*)W_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel main input W dtype mismatch, expected float16");
    return -1;
  }
  if (!((((int32_t)((int64_t*)main_W_shape)[0]) == 4096))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input W shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)main_W_shape)[0])), (long long)(4096));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)main_W_shape)[1]) == 512))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input W shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)main_W_shape)[1])), (long long)(512));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_8;
  if ((main_W_strides == NULL)) {
    condval_8 = 1;
  } else {
    condval_8 = ((int32_t)((int64_t*)main_W_strides)[1]);
  }
  if (!((condval_8 == 1))) {
    int32_t condval_9;
    if ((main_W_strides == NULL)) {
      condval_9 = 1;
    } else {
      condval_9 = ((int32_t)((int64_t*)main_W_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input W strides[1] violates packed ABI constraint", (long long)(condval_9), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_10;
  if ((main_W_strides == NULL)) {
    condval_10 = 1;
  } else {
    condval_10 = ((int32_t)((int64_t*)main_W_strides)[0]);
  }
  if (!((condval_10 == 512))) {
    int32_t condval_11;
    if ((main_W_strides == NULL)) {
      condval_11 = 1;
    } else {
      condval_11 = ((int32_t)((int64_t*)main_W_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input W strides[0] violates packed ABI constraint", (long long)(condval_11), (long long)(512));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)W_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input W byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)W_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)W_handle)[0].device.device_id) == dev_id))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input W device_id violates packed ABI constraint", (long long)((((DLTensor*)W_handle)[0].device.device_id)), (long long)(dev_id));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)W_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input W device_type mismatch, expected ext_dev", (long long)((((DLTensor*)W_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(W == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel main input W data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)IDS_handle)[0].dtype.code) == (uint8_t)0) && ((((DLTensor*)IDS_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)IDS_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel main input IDS dtype mismatch, expected int32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)main_IDS_shape)[0]) == 26))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input IDS shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)main_IDS_shape)[0])), (long long)(26));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_12;
  if ((main_IDS_strides == NULL)) {
    condval_12 = 1;
  } else {
    condval_12 = ((int32_t)((int64_t*)main_IDS_strides)[0]);
  }
  if (!((condval_12 == 1))) {
    int32_t condval_13;
    if ((main_IDS_strides == NULL)) {
      condval_13 = 1;
    } else {
      condval_13 = ((int32_t)((int64_t*)main_IDS_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input IDS strides[0] violates packed ABI constraint", (long long)(condval_13), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)IDS_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input IDS byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)IDS_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)IDS_handle)[0].device.device_id) == dev_id))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input IDS device_id violates packed ABI constraint", (long long)((((DLTensor*)IDS_handle)[0].device.device_id)), (long long)(dev_id));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)IDS_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input IDS device_type mismatch, expected ext_dev", (long long)((((DLTensor*)IDS_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(IDS == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel main input IDS data pointer is NULL");
    return -1;
  }
  TL_ALIGN(128) TVMFFIAny stack_1[1];
  void* callee_allocated_output_storage = stack_1;
  TVMFFIAny stack_2[1];
  void* callee_allocated_output_shape_storage = stack_2;
  TVMFFIAny stack_3[3];
  void* callee_allocated_output_prototype_storage = stack_3;
  (((int64_t*)callee_allocated_output_shape_storage)[0]) = (int64_t)8;
  (((int64_t*)callee_allocated_output_shape_storage)[1]) = (int64_t)26;
  uint64_t v_ = (uint64_t)0;
  (((DLTensor*)callee_allocated_output_prototype_storage)[0].data) = (*(void* *)(&(v_)));
  (((DLTensor*)callee_allocated_output_prototype_storage)[0].shape) = (int64_t*)((void*)((char*)callee_allocated_output_shape_storage + (int64_t)0));
  uint64_t v__1 = (uint64_t)0;
  (((DLTensor*)callee_allocated_output_prototype_storage)[0].strides) = (int64_t*)(*(void* *)(&(v__1)));
  (((DLTensor*)callee_allocated_output_prototype_storage)[0].ndim) = 2;
  (((DLTensor*)callee_allocated_output_prototype_storage)[0].dtype.code) = (uint8_t)2;
  (((DLTensor*)callee_allocated_output_prototype_storage)[0].dtype.bits) = (uint8_t)32;
  (((DLTensor*)callee_allocated_output_prototype_storage)[0].dtype.lanes) = (uint16_t)1;
  (((DLTensor*)callee_allocated_output_prototype_storage)[0].byte_offset) = (uint64_t)0;
  (((DLTensor*)callee_allocated_output_prototype_storage)[0].device.device_id) = dev_id;
  (((DLTensor*)callee_allocated_output_prototype_storage)[0].device.device_type) = (DLDeviceType)12;
  int32_t S_allocation_status = TVMFFIEnvTensorAlloc((((DLTensor*)callee_allocated_output_prototype_storage) + 0), ((void*)((char*)callee_allocated_output_storage + (int64_t)8)));
  if (S_allocation_status != 0) {
    return S_allocation_status;
  }
  void* S_handle = ((void*)((char*)(((TVMFFIAny*)callee_allocated_output_storage)[0].v_ptr) + (int64_t)24));
  bool main_S_is_null = (S_handle == NULL);
  if (!(!main_S_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "main.S is expected to have non-NULL pointer");
    return -1;
  }
  void* main_S_shape = (((DLTensor*)S_handle)[0].shape);
  if (!(((((DLTensor*)S_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input S ndim mismatch, expected 2", (long long)((((DLTensor*)S_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* main_S_strides = (((DLTensor*)S_handle)[0].strides);
  void* S = (((DLTensor*)S_handle)[0].data);
  if (!(((((((DLTensor*)S_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)S_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)S_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel main input S dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)main_S_shape)[0]) == 8))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input S shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)main_S_shape)[0])), (long long)(8));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)main_S_shape)[1]) == 26))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input S shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)main_S_shape)[1])), (long long)(26));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_14;
  if ((main_S_strides == NULL)) {
    condval_14 = 1;
  } else {
    condval_14 = ((int32_t)((int64_t*)main_S_strides)[1]);
  }
  if (!((condval_14 == 1))) {
    int32_t condval_15;
    if ((main_S_strides == NULL)) {
      condval_15 = 1;
    } else {
      condval_15 = ((int32_t)((int64_t*)main_S_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input S strides[1] violates packed ABI constraint", (long long)(condval_15), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_16;
  if ((main_S_strides == NULL)) {
    condval_16 = 1;
  } else {
    condval_16 = ((int32_t)((int64_t*)main_S_strides)[0]);
  }
  if (!((condval_16 == 26))) {
    int32_t condval_17;
    if ((main_S_strides == NULL)) {
      condval_17 = 1;
    } else {
      condval_17 = ((int32_t)((int64_t*)main_S_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input S strides[0] violates packed ABI constraint", (long long)(condval_17), (long long)(26));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)S_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input S byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)S_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)S_handle)[0].device.device_id) == dev_id))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input S device_id violates packed ABI constraint", (long long)((((DLTensor*)S_handle)[0].device.device_id)), (long long)(dev_id));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)S_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel main input S device_type mismatch, expected ext_dev", (long long)((((DLTensor*)S_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(S == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel main input S data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)12);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (HID == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = HID;
  if (IDS == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = IDS;
  if (POS == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = POS;
  if (S == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = S;
  if (W == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = W;
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = (int64_t)61440;
  (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = (int64_t)0;
  if (main_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "main_kernel", &main_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(main_kernel_packed, (TVMFFIAny*) stack_ffi_any, 7, &result_2) != 0) {
    return -1;
  }
  (((TVMFFIAny*)result)[0].type_index) = 70;
  (((TVMFFIAny*)result)[0].zero_padding) = 0;
  (((TVMFFIAny*)result)[0].v_int64) = 0;
  (((TVMFFIAny*)result)[0].v_ptr) = (((TVMFFIAny*)callee_allocated_output_storage)[0].v_ptr);
  return 0;
}

