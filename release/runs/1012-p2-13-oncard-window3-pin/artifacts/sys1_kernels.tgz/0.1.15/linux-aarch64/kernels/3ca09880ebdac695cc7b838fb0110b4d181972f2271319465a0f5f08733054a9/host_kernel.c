// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* conv_impl_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_conv_impl(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_conv_impl(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[7];
  void* stack_ffi_any = stack;
  if (!((num_args == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "conv_impl: num_args should be 4", (long long)(num_args), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "conv_impl: args pointer is NULL");
    return -1;
  }
  int32_t X_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((X_handle_type_index == 0) || (X_handle_type_index == 4)) || (X_handle_type_index == 7)) || (64 <= X_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel conv_impl input X expected pointer or tensor handle");
    return -1;
  }
  int32_t W_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((W_handle_type_index == 0) || (W_handle_type_index == 4)) || (W_handle_type_index == 7)) || (64 <= W_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel conv_impl input W expected pointer or tensor handle");
    return -1;
  }
  int32_t Bias_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((Bias_handle_type_index == 0) || (Bias_handle_type_index == 4)) || (Bias_handle_type_index == 7)) || (64 <= Bias_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel conv_impl input Bias expected pointer or tensor handle");
    return -1;
  }
  int32_t Y_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((Y_handle_type_index == 0) || (Y_handle_type_index == 4)) || (Y_handle_type_index == 7)) || (64 <= Y_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel conv_impl input Y expected pointer or tensor handle");
    return -1;
  }
  void* X_handle = ((X_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* W_handle = ((W_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* Bias_handle = ((Bias_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* Y_handle = ((Y_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  bool conv_impl_X_is_null = (X_handle == NULL);
  if (!(!conv_impl_X_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "conv_impl.X is expected to have non-NULL pointer");
    return -1;
  }
  bool conv_impl_W_is_null = (W_handle == NULL);
  if (!(!conv_impl_W_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "conv_impl.W is expected to have non-NULL pointer");
    return -1;
  }
  bool conv_impl_Bias_is_null = (Bias_handle == NULL);
  if (!(!conv_impl_Bias_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "conv_impl.Bias is expected to have non-NULL pointer");
    return -1;
  }
  bool conv_impl_Y_is_null = (Y_handle == NULL);
  if (!(!conv_impl_Y_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "conv_impl.Y is expected to have non-NULL pointer");
    return -1;
  }
  void* conv_impl_X_shape = (((DLTensor*)X_handle)[0].shape);
  void* conv_impl_W_shape = (((DLTensor*)W_handle)[0].shape);
  void* conv_impl_Bias_shape = (((DLTensor*)Bias_handle)[0].shape);
  void* conv_impl_Y_shape = (((DLTensor*)Y_handle)[0].shape);
  if (!(((((DLTensor*)X_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input X ndim mismatch, expected 3", (long long)((((DLTensor*)X_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable length requires at least one non-null buffer among: conv_impl.X, conv_impl.Y");
    return -1;
  }
  int32_t length = ((int32_t)((int64_t*)conv_impl_X_shape)[2]);
  void* conv_impl_X_strides = (((DLTensor*)X_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)X_handle)[0].device.device_id);
  void* X = (((DLTensor*)X_handle)[0].data);
  if (!(((((DLTensor*)W_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input W ndim mismatch, expected 2", (long long)((((DLTensor*)W_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* conv_impl_W_strides = (((DLTensor*)W_handle)[0].strides);
  void* W = (((DLTensor*)W_handle)[0].data);
  if (!(((((DLTensor*)Bias_handle)[0].ndim) == 1))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input Bias ndim mismatch, expected 1", (long long)((((DLTensor*)Bias_handle)[0].ndim)), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* conv_impl_Bias_strides = (((DLTensor*)Bias_handle)[0].strides);
  void* Bias = (((DLTensor*)Bias_handle)[0].data);
  if (!(((((DLTensor*)Y_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input Y ndim mismatch, expected 3", (long long)((((DLTensor*)Y_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* conv_impl_Y_strides = (((DLTensor*)Y_handle)[0].strides);
  void* Y = (((DLTensor*)Y_handle)[0].data);
  if (!(((((((DLTensor*)X_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)X_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)X_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel conv_impl input X dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)conv_impl_X_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input X shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)conv_impl_X_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)conv_impl_X_shape)[1]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input X shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)conv_impl_X_shape)[1])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval;
  if ((conv_impl_X_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)conv_impl_X_strides)[2]);
  }
  if (!(((condval == 1) || (length == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel conv_impl input X strides[2] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_1;
  if ((conv_impl_X_strides == NULL)) {
    condval_1 = 1;
  } else {
    condval_1 = ((int32_t)((int64_t*)conv_impl_X_strides)[1]);
  }
  if (!(((((int32_t)((int64_t*)conv_impl_X_shape)[2]) == condval_1) || (((int32_t)((int64_t*)conv_impl_X_shape)[2]) == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel conv_impl input X strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_2;
  if ((conv_impl_X_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)conv_impl_X_strides)[0]);
  }
  if (!((((length * 16) == condval_2) || (length == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel conv_impl input X strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)X_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input X byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)X_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)X_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input X device_type mismatch, expected ext_dev", (long long)((((DLTensor*)X_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((length == 0) || !(X == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel conv_impl input X data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)W_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)W_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)W_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel conv_impl input W dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)conv_impl_W_shape)[0]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input W shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)conv_impl_W_shape)[0])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)conv_impl_W_shape)[1]) == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input W shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)conv_impl_W_shape)[1])), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((conv_impl_W_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)conv_impl_W_strides)[1]);
  }
  if (!((condval_3 == 1))) {
    int32_t condval_4;
    if ((conv_impl_W_strides == NULL)) {
      condval_4 = 1;
    } else {
      condval_4 = ((int32_t)((int64_t*)conv_impl_W_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input W strides[1] violates packed ABI constraint", (long long)(condval_4), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_5;
  if ((conv_impl_W_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)conv_impl_W_strides)[0]);
  }
  if (!((condval_5 == 4))) {
    int32_t condval_6;
    if ((conv_impl_W_strides == NULL)) {
      condval_6 = 1;
    } else {
      condval_6 = ((int32_t)((int64_t*)conv_impl_W_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input W strides[0] violates packed ABI constraint", (long long)(condval_6), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)W_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input W byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)W_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)W_handle)[0].device.device_id) == (((DLTensor*)X_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input W device_id violates packed ABI constraint", (long long)((((DLTensor*)W_handle)[0].device.device_id)), (long long)((((DLTensor*)X_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)W_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input W device_type mismatch, expected ext_dev", (long long)((((DLTensor*)W_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(W == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel conv_impl input W data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Bias_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Bias_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Bias_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel conv_impl input Bias dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)conv_impl_Bias_shape)[0]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input Bias shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)conv_impl_Bias_shape)[0])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_7;
  if ((conv_impl_Bias_strides == NULL)) {
    condval_7 = 1;
  } else {
    condval_7 = ((int32_t)((int64_t*)conv_impl_Bias_strides)[0]);
  }
  if (!((condval_7 == 1))) {
    int32_t condval_8;
    if ((conv_impl_Bias_strides == NULL)) {
      condval_8 = 1;
    } else {
      condval_8 = ((int32_t)((int64_t*)conv_impl_Bias_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input Bias strides[0] violates packed ABI constraint", (long long)(condval_8), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Bias_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input Bias byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Bias_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Bias_handle)[0].device.device_id) == (((DLTensor*)X_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input Bias device_id violates packed ABI constraint", (long long)((((DLTensor*)Bias_handle)[0].device.device_id)), (long long)((((DLTensor*)X_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Bias_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input Bias device_type mismatch, expected ext_dev", (long long)((((DLTensor*)Bias_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(Bias == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel conv_impl input Bias data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Y_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Y_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Y_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel conv_impl input Y dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)conv_impl_Y_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input Y shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)conv_impl_Y_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)conv_impl_Y_shape)[1]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input Y shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)conv_impl_Y_shape)[1])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)conv_impl_X_shape)[2]) == ((int32_t)((int64_t*)conv_impl_Y_shape)[2])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input Y shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)conv_impl_X_shape)[2])), (long long)(((int32_t)((int64_t*)conv_impl_Y_shape)[2])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_9;
  if ((conv_impl_Y_strides == NULL)) {
    condval_9 = 1;
  } else {
    condval_9 = ((int32_t)((int64_t*)conv_impl_Y_strides)[2]);
  }
  if (!(((condval_9 == 1) || (length == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel conv_impl input Y strides[2] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_10;
  if ((conv_impl_Y_strides == NULL)) {
    condval_10 = 1;
  } else {
    condval_10 = ((int32_t)((int64_t*)conv_impl_Y_strides)[1]);
  }
  if (!(((((int32_t)((int64_t*)conv_impl_X_shape)[2]) == condval_10) || (((int32_t)((int64_t*)conv_impl_X_shape)[2]) == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel conv_impl input Y strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_11;
  if ((conv_impl_Y_strides == NULL)) {
    condval_11 = 1;
  } else {
    condval_11 = ((int32_t)((int64_t*)conv_impl_Y_strides)[0]);
  }
  if (!((((length * 16) == condval_11) || (length == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel conv_impl input Y strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Y_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input Y byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Y_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Y_handle)[0].device.device_id) == (((DLTensor*)X_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input Y device_id violates packed ABI constraint", (long long)((((DLTensor*)Y_handle)[0].device.device_id)), (long long)((((DLTensor*)X_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Y_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel conv_impl input Y device_type mismatch, expected ext_dev", (long long)((((DLTensor*)Y_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((length == 0) || !(Y == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel conv_impl input Y data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)12);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (Bias == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = Bias;
  if (W == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = W;
  if (X == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = X;
  if (Y == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = Y;
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = ((int64_t)length);
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = ((int64_t)8);
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = (int64_t)0;
  if (conv_impl_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "conv_impl_kernel", &conv_impl_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(conv_impl_kernel_packed, (TVMFFIAny*) stack_ffi_any, 6, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_conv_impl(self, args, num_args, result);
}
