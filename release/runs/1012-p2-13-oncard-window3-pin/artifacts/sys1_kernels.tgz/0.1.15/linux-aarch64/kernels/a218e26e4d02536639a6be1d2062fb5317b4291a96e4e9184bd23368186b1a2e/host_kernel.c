// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* dw_impl_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_dw_impl(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_dw_impl(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[7];
  void* stack_ffi_any = stack;
  if (!((num_args == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "dw_impl: num_args should be 3", (long long)(num_args), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "dw_impl: args pointer is NULL");
    return -1;
  }
  int32_t dY_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((dY_handle_type_index == 0) || (dY_handle_type_index == 4)) || (dY_handle_type_index == 7)) || (64 <= dY_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dw_impl input dY expected pointer or tensor handle");
    return -1;
  }
  int32_t A_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((A_handle_type_index == 0) || (A_handle_type_index == 4)) || (A_handle_type_index == 7)) || (64 <= A_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dw_impl input A expected pointer or tensor handle");
    return -1;
  }
  int32_t GW_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((GW_handle_type_index == 0) || (GW_handle_type_index == 4)) || (GW_handle_type_index == 7)) || (64 <= GW_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dw_impl input GW expected pointer or tensor handle");
    return -1;
  }
  void* dY_handle = ((dY_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* A_handle = ((A_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* GW_handle = ((GW_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  bool dw_impl_dY_is_null = (dY_handle == NULL);
  if (!(!dw_impl_dY_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "dw_impl.dY is expected to have non-NULL pointer");
    return -1;
  }
  bool dw_impl_A_is_null = (A_handle == NULL);
  if (!(!dw_impl_A_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "dw_impl.A is expected to have non-NULL pointer");
    return -1;
  }
  bool dw_impl_GW_is_null = (GW_handle == NULL);
  if (!(!dw_impl_GW_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "dw_impl.GW is expected to have non-NULL pointer");
    return -1;
  }
  void* dw_impl_dY_shape = (((DLTensor*)dY_handle)[0].shape);
  void* dw_impl_A_shape = (((DLTensor*)A_handle)[0].shape);
  void* dw_impl_GW_shape = (((DLTensor*)GW_handle)[0].shape);
  if (!(((((DLTensor*)dY_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dw_impl input dY ndim mismatch, expected 2", (long long)((((DLTensor*)dY_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable m requires at least one non-null buffer among: dw_impl.dY, dw_impl.A");
    return -1;
  }
  int32_t m = ((int32_t)((int64_t*)dw_impl_dY_shape)[0]);
  void* dw_impl_dY_strides = (((DLTensor*)dY_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)dY_handle)[0].device.device_id);
  void* dY = (((DLTensor*)dY_handle)[0].data);
  if (!(((((DLTensor*)A_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dw_impl input A ndim mismatch, expected 2", (long long)((((DLTensor*)A_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* dw_impl_A_strides = (((DLTensor*)A_handle)[0].strides);
  void* A = (((DLTensor*)A_handle)[0].data);
  if (!(((((DLTensor*)GW_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dw_impl input GW ndim mismatch, expected 2", (long long)((((DLTensor*)GW_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* dw_impl_GW_strides = (((DLTensor*)GW_handle)[0].strides);
  void* GW = (((DLTensor*)GW_handle)[0].data);
  if (!(((((((DLTensor*)dY_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)dY_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)dY_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dw_impl input dY dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)dw_impl_dY_shape)[1]) == 32))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dw_impl input dY shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dw_impl_dY_shape)[1])), (long long)(32));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval;
  if ((dw_impl_dY_strides == NULL)) {
    condval = 1;
  } else {
    condval = ((int32_t)((int64_t*)dw_impl_dY_strides)[1]);
  }
  if (!((condval == 1))) {
    int32_t condval_1;
    if ((dw_impl_dY_strides == NULL)) {
      condval_1 = 1;
    } else {
      condval_1 = ((int32_t)((int64_t*)dw_impl_dY_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dw_impl input dY strides[1] violates packed ABI constraint", (long long)(condval_1), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_2;
  if ((dw_impl_dY_strides == NULL)) {
    condval_2 = 1;
  } else {
    condval_2 = ((int32_t)((int64_t*)dw_impl_dY_strides)[0]);
  }
  if (!(((condval_2 == 32) || (m == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dw_impl input dY strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)dY_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dw_impl input dY byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)dY_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)dY_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dw_impl input dY device_type mismatch, expected ext_dev", (long long)((((DLTensor*)dY_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((m == 0) || !(dY == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dw_impl input dY data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)A_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)A_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)A_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dw_impl input A dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)dw_impl_dY_shape)[0]) == ((int32_t)((int64_t*)dw_impl_A_shape)[0])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dw_impl input A shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dw_impl_dY_shape)[0])), (long long)(((int32_t)((int64_t*)dw_impl_A_shape)[0])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)dw_impl_A_shape)[1]) == 64))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dw_impl input A shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dw_impl_A_shape)[1])), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((dw_impl_A_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)dw_impl_A_strides)[1]);
  }
  if (!((condval_3 == 1))) {
    int32_t condval_4;
    if ((dw_impl_A_strides == NULL)) {
      condval_4 = 1;
    } else {
      condval_4 = ((int32_t)((int64_t*)dw_impl_A_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dw_impl input A strides[1] violates packed ABI constraint", (long long)(condval_4), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_5;
  if ((dw_impl_A_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)dw_impl_A_strides)[0]);
  }
  if (!(((condval_5 == 64) || (m == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dw_impl input A strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)A_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dw_impl input A byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)A_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)A_handle)[0].device.device_id) == (((DLTensor*)dY_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dw_impl input A device_id violates packed ABI constraint", (long long)((((DLTensor*)A_handle)[0].device.device_id)), (long long)((((DLTensor*)dY_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)A_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dw_impl input A device_type mismatch, expected ext_dev", (long long)((((DLTensor*)A_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((m == 0) || !(A == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dw_impl input A data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)GW_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)GW_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)GW_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dw_impl input GW dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)dw_impl_GW_shape)[0]) == 32))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dw_impl input GW shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dw_impl_GW_shape)[0])), (long long)(32));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)dw_impl_GW_shape)[1]) == 64))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dw_impl input GW shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)dw_impl_GW_shape)[1])), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_6;
  if ((dw_impl_GW_strides == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)dw_impl_GW_strides)[1]);
  }
  if (!((condval_6 == 1))) {
    int32_t condval_7;
    if ((dw_impl_GW_strides == NULL)) {
      condval_7 = 1;
    } else {
      condval_7 = ((int32_t)((int64_t*)dw_impl_GW_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dw_impl input GW strides[1] violates packed ABI constraint", (long long)(condval_7), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_8;
  if ((dw_impl_GW_strides == NULL)) {
    condval_8 = 1;
  } else {
    condval_8 = ((int32_t)((int64_t*)dw_impl_GW_strides)[0]);
  }
  if (!((condval_8 == 64))) {
    int32_t condval_9;
    if ((dw_impl_GW_strides == NULL)) {
      condval_9 = 1;
    } else {
      condval_9 = ((int32_t)((int64_t*)dw_impl_GW_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dw_impl input GW strides[0] violates packed ABI constraint", (long long)(condval_9), (long long)(64));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)GW_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dw_impl input GW byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)GW_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)GW_handle)[0].device.device_id) == (((DLTensor*)dY_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dw_impl input GW device_id violates packed ABI constraint", (long long)((((DLTensor*)GW_handle)[0].device.device_id)), (long long)((((DLTensor*)dY_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)GW_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel dw_impl input GW device_type mismatch, expected ext_dev", (long long)((((DLTensor*)GW_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(GW == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel dw_impl input GW data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)12);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (A == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = A;
  if (GW == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = GW;
  if (dY == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = dY;
  (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = ((int64_t)m);
  (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = ((int64_t)1);
  (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = (int64_t)14336;
  (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = (int64_t)0;
  if (dw_impl_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "dw_impl_kernel", &dw_impl_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(dw_impl_kernel_packed, (TVMFFIAny*) stack_ffi_any, 6, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_dw_impl(self, args, num_args, result);
}
