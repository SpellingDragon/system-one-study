// tilelang target: {"kind":"c","tag":"","keys":["cpu"]}
#define TVM_EXPORTS
#include "tvm/runtime/base.h"
#include "tvm/runtime/c_backend_api.h"
#include "tvm/ffi/c_api.h"
#include <math.h>
#include <stdio.h>
#include <stdbool.h>
#if defined(_MSC_VER)
#define TL_ALIGN(N) __declspec(align(N))
#else
#define TL_ALIGN(N) __attribute__((aligned(N)))
#endif
#ifdef __OBJC__
#include "tvm/runtime/device_api.h"
#include "tvm/ffi/function.h"
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#include <torch/mps.h>
#endif
void* __tvm_ffi__library_ctx = NULL;
static void* __tvm_set_device_packed = NULL;
static void* gdn_bwd_impl_kernel_packed = NULL;
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_gdn_bwd_impl(void* self_handle, void* args, int32_t num_args, void* result);
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_gdn_bwd_impl(void* self_handle, void* args, int32_t num_args, void* result) {
  TL_ALIGN(128) TVMFFIAny stack[17];
  void* stack_ffi_any = stack;
  if (!((num_args == 14))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "gdn_bwd_impl: num_args should be 14", (long long)(num_args), (long long)(14));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(args == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_bwd_impl: args pointer is NULL");
    return -1;
  }
  int32_t Q_handle_type_index = (((TVMFFIAny*)args)[0].type_index);
  if (!(((((Q_handle_type_index == 0) || (Q_handle_type_index == 4)) || (Q_handle_type_index == 7)) || (64 <= Q_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Q expected pointer or tensor handle");
    return -1;
  }
  int32_t K_handle_type_index = (((TVMFFIAny*)args)[1].type_index);
  if (!(((((K_handle_type_index == 0) || (K_handle_type_index == 4)) || (K_handle_type_index == 7)) || (64 <= K_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input K expected pointer or tensor handle");
    return -1;
  }
  int32_t V_handle_type_index = (((TVMFFIAny*)args)[2].type_index);
  if (!(((((V_handle_type_index == 0) || (V_handle_type_index == 4)) || (V_handle_type_index == 7)) || (64 <= V_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input V expected pointer or tensor handle");
    return -1;
  }
  int32_t G_handle_type_index = (((TVMFFIAny*)args)[3].type_index);
  if (!(((((G_handle_type_index == 0) || (G_handle_type_index == 4)) || (G_handle_type_index == 7)) || (64 <= G_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input G expected pointer or tensor handle");
    return -1;
  }
  int32_t Beta_handle_type_index = (((TVMFFIAny*)args)[4].type_index);
  if (!(((((Beta_handle_type_index == 0) || (Beta_handle_type_index == 4)) || (Beta_handle_type_index == 7)) || (64 <= Beta_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Beta expected pointer or tensor handle");
    return -1;
  }
  int32_t DO_handle_type_index = (((TVMFFIAny*)args)[5].type_index);
  if (!(((((DO_handle_type_index == 0) || (DO_handle_type_index == 4)) || (DO_handle_type_index == 7)) || (64 <= DO_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DO expected pointer or tensor handle");
    return -1;
  }
  int32_t Hist_handle_type_index = (((TVMFFIAny*)args)[6].type_index);
  if (!(((((Hist_handle_type_index == 0) || (Hist_handle_type_index == 4)) || (Hist_handle_type_index == 7)) || (64 <= Hist_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Hist expected pointer or tensor handle");
    return -1;
  }
  int32_t Lam_handle_type_index = (((TVMFFIAny*)args)[7].type_index);
  if (!(((((Lam_handle_type_index == 0) || (Lam_handle_type_index == 4)) || (Lam_handle_type_index == 7)) || (64 <= Lam_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Lam expected pointer or tensor handle");
    return -1;
  }
  int32_t DQ_handle_type_index = (((TVMFFIAny*)args)[8].type_index);
  if (!(((((DQ_handle_type_index == 0) || (DQ_handle_type_index == 4)) || (DQ_handle_type_index == 7)) || (64 <= DQ_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DQ expected pointer or tensor handle");
    return -1;
  }
  int32_t DKG_handle_type_index = (((TVMFFIAny*)args)[9].type_index);
  if (!(((((DKG_handle_type_index == 0) || (DKG_handle_type_index == 4)) || (DKG_handle_type_index == 7)) || (64 <= DKG_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DKG expected pointer or tensor handle");
    return -1;
  }
  int32_t DV__handle_type_index = (((TVMFFIAny*)args)[10].type_index);
  if (!(((((DV__handle_type_index == 0) || (DV__handle_type_index == 4)) || (DV__handle_type_index == 7)) || (64 <= DV__handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DV_ expected pointer or tensor handle");
    return -1;
  }
  int32_t DBeta_handle_type_index = (((TVMFFIAny*)args)[11].type_index);
  if (!(((((DBeta_handle_type_index == 0) || (DBeta_handle_type_index == 4)) || (DBeta_handle_type_index == 7)) || (64 <= DBeta_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DBeta expected pointer or tensor handle");
    return -1;
  }
  int32_t DG_handle_type_index = (((TVMFFIAny*)args)[12].type_index);
  if (!(((((DG_handle_type_index == 0) || (DG_handle_type_index == 4)) || (DG_handle_type_index == 7)) || (64 <= DG_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DG expected pointer or tensor handle");
    return -1;
  }
  int32_t DH0_handle_type_index = (((TVMFFIAny*)args)[13].type_index);
  if (!(((((DH0_handle_type_index == 0) || (DH0_handle_type_index == 4)) || (DH0_handle_type_index == 7)) || (64 <= DH0_handle_type_index)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DH0 expected pointer or tensor handle");
    return -1;
  }
  void* Q_handle = ((Q_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[0].v_ptr) + 24)) : (((TVMFFIAny*)args)[0].v_ptr));
  void* K_handle = ((K_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[1].v_ptr) + 24)) : (((TVMFFIAny*)args)[1].v_ptr));
  void* V_handle = ((V_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[2].v_ptr) + 24)) : (((TVMFFIAny*)args)[2].v_ptr));
  void* G_handle = ((G_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[3].v_ptr) + 24)) : (((TVMFFIAny*)args)[3].v_ptr));
  void* Beta_handle = ((Beta_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[4].v_ptr) + 24)) : (((TVMFFIAny*)args)[4].v_ptr));
  void* DO_handle = ((DO_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[5].v_ptr) + 24)) : (((TVMFFIAny*)args)[5].v_ptr));
  void* Hist_handle = ((Hist_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[6].v_ptr) + 24)) : (((TVMFFIAny*)args)[6].v_ptr));
  void* Lam_handle = ((Lam_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[7].v_ptr) + 24)) : (((TVMFFIAny*)args)[7].v_ptr));
  void* DQ_handle = ((DQ_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[8].v_ptr) + 24)) : (((TVMFFIAny*)args)[8].v_ptr));
  void* DKG_handle = ((DKG_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[9].v_ptr) + 24)) : (((TVMFFIAny*)args)[9].v_ptr));
  void* DV__handle = ((DV__handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[10].v_ptr) + 24)) : (((TVMFFIAny*)args)[10].v_ptr));
  void* DBeta_handle = ((DBeta_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[11].v_ptr) + 24)) : (((TVMFFIAny*)args)[11].v_ptr));
  void* DG_handle = ((DG_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[12].v_ptr) + 24)) : (((TVMFFIAny*)args)[12].v_ptr));
  void* DH0_handle = ((DH0_handle_type_index == 70) ? ((void*)((char*)(((TVMFFIAny*)args)[13].v_ptr) + 24)) : (((TVMFFIAny*)args)[13].v_ptr));
  bool gdn_bwd_impl_Q_is_null = (Q_handle == NULL);
  if (!(!gdn_bwd_impl_Q_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_bwd_impl.Q is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_bwd_impl_K_is_null = (K_handle == NULL);
  if (!(!gdn_bwd_impl_K_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_bwd_impl.K is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_bwd_impl_V_is_null = (V_handle == NULL);
  if (!(!gdn_bwd_impl_V_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_bwd_impl.V is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_bwd_impl_G_is_null = (G_handle == NULL);
  if (!(!gdn_bwd_impl_G_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_bwd_impl.G is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_bwd_impl_Beta_is_null = (Beta_handle == NULL);
  if (!(!gdn_bwd_impl_Beta_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_bwd_impl.Beta is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_bwd_impl_DO_is_null = (DO_handle == NULL);
  if (!(!gdn_bwd_impl_DO_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_bwd_impl.DO is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_bwd_impl_Hist_is_null = (Hist_handle == NULL);
  if (!(!gdn_bwd_impl_Hist_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_bwd_impl.Hist is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_bwd_impl_Lam_is_null = (Lam_handle == NULL);
  bool gdn_bwd_impl_DQ_is_null = (DQ_handle == NULL);
  if (!(!gdn_bwd_impl_DQ_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_bwd_impl.DQ is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_bwd_impl_DKG_is_null = (DKG_handle == NULL);
  if (!(!gdn_bwd_impl_DKG_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_bwd_impl.DKG is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_bwd_impl_DV__is_null = (DV__handle == NULL);
  if (!(!gdn_bwd_impl_DV__is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_bwd_impl.DV_ is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_bwd_impl_DBeta_is_null = (DBeta_handle == NULL);
  if (!(!gdn_bwd_impl_DBeta_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_bwd_impl.DBeta is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_bwd_impl_DG_is_null = (DG_handle == NULL);
  if (!(!gdn_bwd_impl_DG_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_bwd_impl.DG is expected to have non-NULL pointer");
    return -1;
  }
  bool gdn_bwd_impl_DH0_is_null = (DH0_handle == NULL);
  if (!(!gdn_bwd_impl_DH0_is_null)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "gdn_bwd_impl.DH0 is expected to have non-NULL pointer");
    return -1;
  }
  void* gdn_bwd_impl_Q_shape = (((DLTensor*)Q_handle)[0].shape);
  void* gdn_bwd_impl_K_shape = (((DLTensor*)K_handle)[0].shape);
  void* gdn_bwd_impl_V_shape = (((DLTensor*)V_handle)[0].shape);
  void* gdn_bwd_impl_G_shape = (((DLTensor*)G_handle)[0].shape);
  void* gdn_bwd_impl_Beta_shape = (((DLTensor*)Beta_handle)[0].shape);
  void* gdn_bwd_impl_DO_shape = (((DLTensor*)DO_handle)[0].shape);
  void* gdn_bwd_impl_Hist_shape = (((DLTensor*)Hist_handle)[0].shape);
  void* condval;
  if (!gdn_bwd_impl_Lam_is_null) {
    condval = (((DLTensor*)Lam_handle)[0].shape);
  } else {
    uint64_t v_ = (uint64_t)0;
    condval = (*(void* *)(&(v_)));
  }
  void* gdn_bwd_impl_Lam_shape = condval;
  void* gdn_bwd_impl_DQ_shape = (((DLTensor*)DQ_handle)[0].shape);
  void* gdn_bwd_impl_DKG_shape = (((DLTensor*)DKG_handle)[0].shape);
  void* gdn_bwd_impl_DV__shape = (((DLTensor*)DV__handle)[0].shape);
  void* gdn_bwd_impl_DBeta_shape = (((DLTensor*)DBeta_handle)[0].shape);
  void* gdn_bwd_impl_DG_shape = (((DLTensor*)DG_handle)[0].shape);
  void* gdn_bwd_impl_DH0_shape = (((DLTensor*)DH0_handle)[0].shape);
  if (!(((((DLTensor*)Q_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input Q ndim mismatch, expected 3", (long long)((((DLTensor*)Q_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((bool)1)) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "Symbolic shape variable seq requires at least one non-null buffer among: gdn_bwd_impl.Q, gdn_bwd_impl.K, gdn_bwd_impl.V, gdn_bwd_impl.G, gdn_bwd_impl.Beta, gdn_bwd_impl.DO, gdn_bwd_impl.Hist, gdn_bwd_impl.DQ, gdn_bwd_impl.DKG, gdn_bwd_impl.DV_, gdn_bwd_impl.DBeta, gdn_bwd_impl.DG");
    return -1;
  }
  int32_t seq = ((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1]);
  void* gdn_bwd_impl_Q_strides = (((DLTensor*)Q_handle)[0].strides);
  int32_t dev_id = (((DLTensor*)Q_handle)[0].device.device_id);
  void* Q = (((DLTensor*)Q_handle)[0].data);
  if (!(((((DLTensor*)K_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input K ndim mismatch, expected 3", (long long)((((DLTensor*)K_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_bwd_impl_K_strides = (((DLTensor*)K_handle)[0].strides);
  void* K = (((DLTensor*)K_handle)[0].data);
  if (!(((((DLTensor*)V_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input V ndim mismatch, expected 3", (long long)((((DLTensor*)V_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_bwd_impl_V_strides = (((DLTensor*)V_handle)[0].strides);
  void* V = (((DLTensor*)V_handle)[0].data);
  if (!(((((DLTensor*)G_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input G ndim mismatch, expected 3", (long long)((((DLTensor*)G_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_bwd_impl_G_strides = (((DLTensor*)G_handle)[0].strides);
  void* G = (((DLTensor*)G_handle)[0].data);
  if (!(((((DLTensor*)Beta_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input Beta ndim mismatch, expected 2", (long long)((((DLTensor*)Beta_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_bwd_impl_Beta_strides = (((DLTensor*)Beta_handle)[0].strides);
  void* Beta = (((DLTensor*)Beta_handle)[0].data);
  if (!(((((DLTensor*)DO_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DO ndim mismatch, expected 3", (long long)((((DLTensor*)DO_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_bwd_impl_DO_strides = (((DLTensor*)DO_handle)[0].strides);
  void* DO = (((DLTensor*)DO_handle)[0].data);
  if (!(((((DLTensor*)Hist_handle)[0].ndim) == 4))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input Hist ndim mismatch, expected 4", (long long)((((DLTensor*)Hist_handle)[0].ndim)), (long long)(4));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_bwd_impl_Hist_strides = (((DLTensor*)Hist_handle)[0].strides);
  void* Hist = (((DLTensor*)Hist_handle)[0].data);
  if (!((gdn_bwd_impl_Lam_is_null || ((((DLTensor*)Lam_handle)[0].ndim) == 3)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Lam ndim mismatch, expected 3");
    return -1;
  }
  void* condval_1;
  if (!gdn_bwd_impl_Lam_is_null) {
    condval_1 = (((DLTensor*)Lam_handle)[0].strides);
  } else {
    uint64_t v__1 = (uint64_t)0;
    condval_1 = (*(void* *)(&(v__1)));
  }
  void* gdn_bwd_impl_Lam_strides = condval_1;
  void* condval_2;
  if (!gdn_bwd_impl_Lam_is_null) {
    condval_2 = (((DLTensor*)Lam_handle)[0].data);
  } else {
    uint64_t v__2 = (uint64_t)0;
    condval_2 = (*(void* *)(&(v__2)));
  }
  void* Lam = condval_2;
  if (!(((((DLTensor*)DQ_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DQ ndim mismatch, expected 3", (long long)((((DLTensor*)DQ_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_bwd_impl_DQ_strides = (((DLTensor*)DQ_handle)[0].strides);
  void* DQ = (((DLTensor*)DQ_handle)[0].data);
  if (!(((((DLTensor*)DKG_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DKG ndim mismatch, expected 3", (long long)((((DLTensor*)DKG_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_bwd_impl_DKG_strides = (((DLTensor*)DKG_handle)[0].strides);
  void* DKG = (((DLTensor*)DKG_handle)[0].data);
  if (!(((((DLTensor*)DV__handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DV_ ndim mismatch, expected 3", (long long)((((DLTensor*)DV__handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_bwd_impl_DV__strides = (((DLTensor*)DV__handle)[0].strides);
  void* DV_ = (((DLTensor*)DV__handle)[0].data);
  if (!(((((DLTensor*)DBeta_handle)[0].ndim) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DBeta ndim mismatch, expected 2", (long long)((((DLTensor*)DBeta_handle)[0].ndim)), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_bwd_impl_DBeta_strides = (((DLTensor*)DBeta_handle)[0].strides);
  void* DBeta = (((DLTensor*)DBeta_handle)[0].data);
  if (!(((((DLTensor*)DG_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DG ndim mismatch, expected 3", (long long)((((DLTensor*)DG_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_bwd_impl_DG_strides = (((DLTensor*)DG_handle)[0].strides);
  void* DG = (((DLTensor*)DG_handle)[0].data);
  if (!(((((DLTensor*)DH0_handle)[0].ndim) == 3))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DH0 ndim mismatch, expected 3", (long long)((((DLTensor*)DH0_handle)[0].ndim)), (long long)(3));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  void* gdn_bwd_impl_DH0_strides = (((DLTensor*)DH0_handle)[0].strides);
  void* DH0 = (((DLTensor*)DH0_handle)[0].data);
  if (!(((((((DLTensor*)Q_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Q_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Q_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Q dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input Q shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input Q shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_3;
  if ((gdn_bwd_impl_Q_strides == NULL)) {
    condval_3 = 1;
  } else {
    condval_3 = ((int32_t)((int64_t*)gdn_bwd_impl_Q_strides)[2]);
  }
  if (!((condval_3 == 1))) {
    int32_t condval_4;
    if ((gdn_bwd_impl_Q_strides == NULL)) {
      condval_4 = 1;
    } else {
      condval_4 = ((int32_t)((int64_t*)gdn_bwd_impl_Q_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input Q strides[2] violates packed ABI constraint", (long long)(condval_4), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_5;
  if ((gdn_bwd_impl_Q_strides == NULL)) {
    condval_5 = 1;
  } else {
    condval_5 = ((int32_t)((int64_t*)gdn_bwd_impl_Q_strides)[1]);
  }
  if (!(((condval_5 == 16) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Q strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_6;
  if ((gdn_bwd_impl_Q_strides == NULL)) {
    condval_6 = 1;
  } else {
    condval_6 = ((int32_t)((int64_t*)gdn_bwd_impl_Q_strides)[0]);
  }
  if (!((((seq * 16) == condval_6) || (seq == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Q strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Q_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input Q byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Q_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Q_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input Q device_type mismatch, expected ext_dev", (long long)((((DLTensor*)Q_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(Q == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Q data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)K_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)K_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)K_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input K dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_K_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input K shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_K_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1]) == ((int32_t)((int64_t*)gdn_bwd_impl_K_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input K shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1])), (long long)(((int32_t)((int64_t*)gdn_bwd_impl_K_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_K_shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input K shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_K_shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_7;
  if ((gdn_bwd_impl_K_strides == NULL)) {
    condval_7 = 1;
  } else {
    condval_7 = ((int32_t)((int64_t*)gdn_bwd_impl_K_strides)[2]);
  }
  if (!((condval_7 == 1))) {
    int32_t condval_8;
    if ((gdn_bwd_impl_K_strides == NULL)) {
      condval_8 = 1;
    } else {
      condval_8 = ((int32_t)((int64_t*)gdn_bwd_impl_K_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input K strides[2] violates packed ABI constraint", (long long)(condval_8), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_9;
  if ((gdn_bwd_impl_K_strides == NULL)) {
    condval_9 = 1;
  } else {
    condval_9 = ((int32_t)((int64_t*)gdn_bwd_impl_K_strides)[1]);
  }
  if (!(((condval_9 == 16) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input K strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_10;
  if ((gdn_bwd_impl_K_strides == NULL)) {
    condval_10 = 1;
  } else {
    condval_10 = ((int32_t)((int64_t*)gdn_bwd_impl_K_strides)[0]);
  }
  if (!((((seq * 16) == condval_10) || (seq == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input K strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)K_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input K byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)K_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)K_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input K device_id violates packed ABI constraint", (long long)((((DLTensor*)K_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)K_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input K device_type mismatch, expected ext_dev", (long long)((((DLTensor*)K_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(K == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input K data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)V_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)V_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)V_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input V dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_V_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input V shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_V_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1]) == ((int32_t)((int64_t*)gdn_bwd_impl_V_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input V shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1])), (long long)(((int32_t)((int64_t*)gdn_bwd_impl_V_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_V_shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input V shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_V_shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_11;
  if ((gdn_bwd_impl_V_strides == NULL)) {
    condval_11 = 1;
  } else {
    condval_11 = ((int32_t)((int64_t*)gdn_bwd_impl_V_strides)[2]);
  }
  if (!((condval_11 == 1))) {
    int32_t condval_12;
    if ((gdn_bwd_impl_V_strides == NULL)) {
      condval_12 = 1;
    } else {
      condval_12 = ((int32_t)((int64_t*)gdn_bwd_impl_V_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input V strides[2] violates packed ABI constraint", (long long)(condval_12), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_13;
  if ((gdn_bwd_impl_V_strides == NULL)) {
    condval_13 = 1;
  } else {
    condval_13 = ((int32_t)((int64_t*)gdn_bwd_impl_V_strides)[1]);
  }
  if (!(((condval_13 == 16) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input V strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_14;
  if ((gdn_bwd_impl_V_strides == NULL)) {
    condval_14 = 1;
  } else {
    condval_14 = ((int32_t)((int64_t*)gdn_bwd_impl_V_strides)[0]);
  }
  if (!((((seq * 16) == condval_14) || (seq == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input V strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)V_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input V byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)V_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)V_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input V device_id violates packed ABI constraint", (long long)((((DLTensor*)V_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)V_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input V device_type mismatch, expected ext_dev", (long long)((((DLTensor*)V_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(V == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input V data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)G_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)G_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)G_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input G dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_G_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input G shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_G_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1]) == ((int32_t)((int64_t*)gdn_bwd_impl_G_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input G shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1])), (long long)(((int32_t)((int64_t*)gdn_bwd_impl_G_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_G_shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input G shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_G_shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_15;
  if ((gdn_bwd_impl_G_strides == NULL)) {
    condval_15 = 1;
  } else {
    condval_15 = ((int32_t)((int64_t*)gdn_bwd_impl_G_strides)[2]);
  }
  if (!((condval_15 == 1))) {
    int32_t condval_16;
    if ((gdn_bwd_impl_G_strides == NULL)) {
      condval_16 = 1;
    } else {
      condval_16 = ((int32_t)((int64_t*)gdn_bwd_impl_G_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input G strides[2] violates packed ABI constraint", (long long)(condval_16), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_17;
  if ((gdn_bwd_impl_G_strides == NULL)) {
    condval_17 = 1;
  } else {
    condval_17 = ((int32_t)((int64_t*)gdn_bwd_impl_G_strides)[1]);
  }
  if (!(((condval_17 == 16) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input G strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_18;
  if ((gdn_bwd_impl_G_strides == NULL)) {
    condval_18 = 1;
  } else {
    condval_18 = ((int32_t)((int64_t*)gdn_bwd_impl_G_strides)[0]);
  }
  if (!((((seq * 16) == condval_18) || (seq == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input G strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)G_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input G byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)G_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)G_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input G device_id violates packed ABI constraint", (long long)((((DLTensor*)G_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)G_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input G device_type mismatch, expected ext_dev", (long long)((((DLTensor*)G_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(G == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input G data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Beta_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Beta_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Beta_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Beta dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_Beta_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input Beta shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_Beta_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1]) == ((int32_t)((int64_t*)gdn_bwd_impl_Beta_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input Beta shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1])), (long long)(((int32_t)((int64_t*)gdn_bwd_impl_Beta_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_19;
  if ((gdn_bwd_impl_Beta_strides == NULL)) {
    condval_19 = 1;
  } else {
    condval_19 = ((int32_t)((int64_t*)gdn_bwd_impl_Beta_strides)[1]);
  }
  if (!(((condval_19 == 1) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Beta strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_20;
  if ((gdn_bwd_impl_Beta_strides == NULL)) {
    condval_20 = 1;
  } else {
    condval_20 = ((int32_t)((int64_t*)gdn_bwd_impl_Beta_strides)[0]);
  }
  if (!(((((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1]) == condval_20) || (((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1]) == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Beta strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Beta_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input Beta byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Beta_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Beta_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input Beta device_id violates packed ABI constraint", (long long)((((DLTensor*)Beta_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Beta_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input Beta device_type mismatch, expected ext_dev", (long long)((((DLTensor*)Beta_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(Beta == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Beta data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)DO_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)DO_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)DO_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DO dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_DO_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DO shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_DO_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1]) == ((int32_t)((int64_t*)gdn_bwd_impl_DO_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DO shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1])), (long long)(((int32_t)((int64_t*)gdn_bwd_impl_DO_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_DO_shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DO shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_DO_shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_21;
  if ((gdn_bwd_impl_DO_strides == NULL)) {
    condval_21 = 1;
  } else {
    condval_21 = ((int32_t)((int64_t*)gdn_bwd_impl_DO_strides)[2]);
  }
  if (!((condval_21 == 1))) {
    int32_t condval_22;
    if ((gdn_bwd_impl_DO_strides == NULL)) {
      condval_22 = 1;
    } else {
      condval_22 = ((int32_t)((int64_t*)gdn_bwd_impl_DO_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DO strides[2] violates packed ABI constraint", (long long)(condval_22), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_23;
  if ((gdn_bwd_impl_DO_strides == NULL)) {
    condval_23 = 1;
  } else {
    condval_23 = ((int32_t)((int64_t*)gdn_bwd_impl_DO_strides)[1]);
  }
  if (!(((condval_23 == 16) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DO strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_24;
  if ((gdn_bwd_impl_DO_strides == NULL)) {
    condval_24 = 1;
  } else {
    condval_24 = ((int32_t)((int64_t*)gdn_bwd_impl_DO_strides)[0]);
  }
  if (!((((seq * 16) == condval_24) || (seq == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DO strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)DO_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DO byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)DO_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)DO_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DO device_id violates packed ABI constraint", (long long)((((DLTensor*)DO_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)DO_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DO device_type mismatch, expected ext_dev", (long long)((((DLTensor*)DO_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(DO == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DO data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)Hist_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)Hist_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)Hist_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Hist dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_Hist_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input Hist shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_Hist_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1]) == ((int32_t)((int64_t*)gdn_bwd_impl_Hist_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input Hist shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1])), (long long)(((int32_t)((int64_t*)gdn_bwd_impl_Hist_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_Hist_shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input Hist shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_Hist_shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_Hist_shape)[3]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input Hist shape[3] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_Hist_shape)[3])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_25;
  if ((gdn_bwd_impl_Hist_strides == NULL)) {
    condval_25 = 1;
  } else {
    condval_25 = ((int32_t)((int64_t*)gdn_bwd_impl_Hist_strides)[3]);
  }
  if (!((condval_25 == 1))) {
    int32_t condval_26;
    if ((gdn_bwd_impl_Hist_strides == NULL)) {
      condval_26 = 1;
    } else {
      condval_26 = ((int32_t)((int64_t*)gdn_bwd_impl_Hist_strides)[3]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input Hist strides[3] violates packed ABI constraint", (long long)(condval_26), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_27;
  if ((gdn_bwd_impl_Hist_strides == NULL)) {
    condval_27 = 1;
  } else {
    condval_27 = ((int32_t)((int64_t*)gdn_bwd_impl_Hist_strides)[2]);
  }
  if (!((condval_27 == 16))) {
    int32_t condval_28;
    if ((gdn_bwd_impl_Hist_strides == NULL)) {
      condval_28 = 1;
    } else {
      condval_28 = ((int32_t)((int64_t*)gdn_bwd_impl_Hist_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input Hist strides[2] violates packed ABI constraint", (long long)(condval_28), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_29;
  if ((gdn_bwd_impl_Hist_strides == NULL)) {
    condval_29 = 1;
  } else {
    condval_29 = ((int32_t)((int64_t*)gdn_bwd_impl_Hist_strides)[1]);
  }
  if (!(((condval_29 == 256) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Hist strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_30;
  if ((gdn_bwd_impl_Hist_strides == NULL)) {
    condval_30 = 1;
  } else {
    condval_30 = ((int32_t)((int64_t*)gdn_bwd_impl_Hist_strides)[0]);
  }
  if (!((((seq * 256) == condval_30) || (seq == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Hist strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)Hist_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input Hist byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)Hist_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Hist_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input Hist device_id violates packed ABI constraint", (long long)((((DLTensor*)Hist_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)Hist_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input Hist device_type mismatch, expected ext_dev", (long long)((((DLTensor*)Hist_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(Hist == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Hist data pointer is NULL");
    return -1;
  }
  uint8_t condval_31;
  if (!gdn_bwd_impl_Lam_is_null) {
    condval_31 = (((DLTensor*)Lam_handle)[0].dtype.code);
  } else {
    condval_31 = (uint8_t)2;
  }
  uint8_t condval_32;
  if (!gdn_bwd_impl_Lam_is_null) {
    condval_32 = (((DLTensor*)Lam_handle)[0].dtype.bits);
  } else {
    condval_32 = (uint8_t)32;
  }
  uint16_t condval_33;
  if (!gdn_bwd_impl_Lam_is_null) {
    condval_33 = (((DLTensor*)Lam_handle)[0].dtype.lanes);
  } else {
    condval_33 = (uint16_t)1;
  }
  if (!((gdn_bwd_impl_Lam_is_null || (((condval_31 == (uint8_t)2) && (condval_32 == (uint8_t)32)) && (condval_33 == (uint16_t)1))))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Lam dtype mismatch, expected float32");
    return -1;
  }
  int32_t condval_34;
  if (!gdn_bwd_impl_Lam_is_null) {
    condval_34 = ((int32_t)((int64_t*)gdn_bwd_impl_Lam_shape)[0]);
  } else {
    condval_34 = 0;
  }
  if (!((gdn_bwd_impl_Lam_is_null || (condval_34 == 2)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Lam shape[0] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_35;
  if (!gdn_bwd_impl_Lam_is_null) {
    condval_35 = ((int32_t)((int64_t*)gdn_bwd_impl_Lam_shape)[1]);
  } else {
    condval_35 = 0;
  }
  if (!((gdn_bwd_impl_Lam_is_null || (condval_35 == 16)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Lam shape[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_36;
  if (!gdn_bwd_impl_Lam_is_null) {
    condval_36 = ((int32_t)((int64_t*)gdn_bwd_impl_Lam_shape)[2]);
  } else {
    condval_36 = 0;
  }
  if (!((gdn_bwd_impl_Lam_is_null || (condval_36 == 16)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Lam shape[2] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_37;
  if ((gdn_bwd_impl_Lam_strides == NULL)) {
    condval_37 = 1;
  } else {
    condval_37 = ((int32_t)((int64_t*)gdn_bwd_impl_Lam_strides)[2]);
  }
  if (!((gdn_bwd_impl_Lam_is_null || (condval_37 == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Lam strides[2] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_38;
  if ((gdn_bwd_impl_Lam_strides == NULL)) {
    condval_38 = 1;
  } else {
    condval_38 = ((int32_t)((int64_t*)gdn_bwd_impl_Lam_strides)[1]);
  }
  if (!((gdn_bwd_impl_Lam_is_null || (condval_38 == 16)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Lam strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_39;
  if ((gdn_bwd_impl_Lam_strides == NULL)) {
    condval_39 = 1;
  } else {
    condval_39 = ((int32_t)((int64_t*)gdn_bwd_impl_Lam_strides)[0]);
  }
  if (!((gdn_bwd_impl_Lam_is_null || (condval_39 == 256)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Lam strides[0] violates packed ABI constraint");
    return -1;
  }
  uint64_t condval_40;
  if (!gdn_bwd_impl_Lam_is_null) {
    condval_40 = (((DLTensor*)Lam_handle)[0].byte_offset);
  } else {
    condval_40 = (uint64_t)0;
  }
  if (!((gdn_bwd_impl_Lam_is_null || ((uint64_t)0 == condval_40)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Lam byte_offset violates packed ABI constraint");
    return -1;
  }
  int32_t condval_41;
  if (!gdn_bwd_impl_Lam_is_null) {
    condval_41 = (((DLTensor*)Lam_handle)[0].device.device_id);
  } else {
    condval_41 = 0;
  }
  if (!((gdn_bwd_impl_Lam_is_null || (condval_41 == (((DLTensor*)Q_handle)[0].device.device_id))))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Lam device_id violates packed ABI constraint");
    return -1;
  }
  int32_t condval_42;
  if (!gdn_bwd_impl_Lam_is_null) {
    condval_42 = (((DLTensor*)Lam_handle)[0].device.device_type);
  } else {
    condval_42 = 0;
  }
  if (!((gdn_bwd_impl_Lam_is_null || (condval_42 == 12)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Lam device_type mismatch, expected ext_dev");
    return -1;
  }
  if (!((gdn_bwd_impl_Lam_is_null || !(Lam == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input Lam data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)DQ_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)DQ_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)DQ_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DQ dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_DQ_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DQ shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_DQ_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1]) == ((int32_t)((int64_t*)gdn_bwd_impl_DQ_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DQ shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1])), (long long)(((int32_t)((int64_t*)gdn_bwd_impl_DQ_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_DQ_shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DQ shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_DQ_shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_43;
  if ((gdn_bwd_impl_DQ_strides == NULL)) {
    condval_43 = 1;
  } else {
    condval_43 = ((int32_t)((int64_t*)gdn_bwd_impl_DQ_strides)[2]);
  }
  if (!((condval_43 == 1))) {
    int32_t condval_44;
    if ((gdn_bwd_impl_DQ_strides == NULL)) {
      condval_44 = 1;
    } else {
      condval_44 = ((int32_t)((int64_t*)gdn_bwd_impl_DQ_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DQ strides[2] violates packed ABI constraint", (long long)(condval_44), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_45;
  if ((gdn_bwd_impl_DQ_strides == NULL)) {
    condval_45 = 1;
  } else {
    condval_45 = ((int32_t)((int64_t*)gdn_bwd_impl_DQ_strides)[1]);
  }
  if (!(((condval_45 == 16) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DQ strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_46;
  if ((gdn_bwd_impl_DQ_strides == NULL)) {
    condval_46 = 1;
  } else {
    condval_46 = ((int32_t)((int64_t*)gdn_bwd_impl_DQ_strides)[0]);
  }
  if (!((((seq * 16) == condval_46) || (seq == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DQ strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)DQ_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DQ byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)DQ_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)DQ_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DQ device_id violates packed ABI constraint", (long long)((((DLTensor*)DQ_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)DQ_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DQ device_type mismatch, expected ext_dev", (long long)((((DLTensor*)DQ_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(DQ == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DQ data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)DKG_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)DKG_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)DKG_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DKG dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_DKG_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DKG shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_DKG_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1]) == ((int32_t)((int64_t*)gdn_bwd_impl_DKG_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DKG shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1])), (long long)(((int32_t)((int64_t*)gdn_bwd_impl_DKG_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_DKG_shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DKG shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_DKG_shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_47;
  if ((gdn_bwd_impl_DKG_strides == NULL)) {
    condval_47 = 1;
  } else {
    condval_47 = ((int32_t)((int64_t*)gdn_bwd_impl_DKG_strides)[2]);
  }
  if (!((condval_47 == 1))) {
    int32_t condval_48;
    if ((gdn_bwd_impl_DKG_strides == NULL)) {
      condval_48 = 1;
    } else {
      condval_48 = ((int32_t)((int64_t*)gdn_bwd_impl_DKG_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DKG strides[2] violates packed ABI constraint", (long long)(condval_48), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_49;
  if ((gdn_bwd_impl_DKG_strides == NULL)) {
    condval_49 = 1;
  } else {
    condval_49 = ((int32_t)((int64_t*)gdn_bwd_impl_DKG_strides)[1]);
  }
  if (!(((condval_49 == 16) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DKG strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_50;
  if ((gdn_bwd_impl_DKG_strides == NULL)) {
    condval_50 = 1;
  } else {
    condval_50 = ((int32_t)((int64_t*)gdn_bwd_impl_DKG_strides)[0]);
  }
  if (!((((seq * 16) == condval_50) || (seq == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DKG strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)DKG_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DKG byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)DKG_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)DKG_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DKG device_id violates packed ABI constraint", (long long)((((DLTensor*)DKG_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)DKG_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DKG device_type mismatch, expected ext_dev", (long long)((((DLTensor*)DKG_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(DKG == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DKG data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)DV__handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)DV__handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)DV__handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DV_ dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_DV__shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DV_ shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_DV__shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1]) == ((int32_t)((int64_t*)gdn_bwd_impl_DV__shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DV_ shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1])), (long long)(((int32_t)((int64_t*)gdn_bwd_impl_DV__shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_DV__shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DV_ shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_DV__shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_51;
  if ((gdn_bwd_impl_DV__strides == NULL)) {
    condval_51 = 1;
  } else {
    condval_51 = ((int32_t)((int64_t*)gdn_bwd_impl_DV__strides)[2]);
  }
  if (!((condval_51 == 1))) {
    int32_t condval_52;
    if ((gdn_bwd_impl_DV__strides == NULL)) {
      condval_52 = 1;
    } else {
      condval_52 = ((int32_t)((int64_t*)gdn_bwd_impl_DV__strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DV_ strides[2] violates packed ABI constraint", (long long)(condval_52), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_53;
  if ((gdn_bwd_impl_DV__strides == NULL)) {
    condval_53 = 1;
  } else {
    condval_53 = ((int32_t)((int64_t*)gdn_bwd_impl_DV__strides)[1]);
  }
  if (!(((condval_53 == 16) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DV_ strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_54;
  if ((gdn_bwd_impl_DV__strides == NULL)) {
    condval_54 = 1;
  } else {
    condval_54 = ((int32_t)((int64_t*)gdn_bwd_impl_DV__strides)[0]);
  }
  if (!((((seq * 16) == condval_54) || (seq == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DV_ strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)DV__handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DV_ byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)DV__handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)DV__handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DV_ device_id violates packed ABI constraint", (long long)((((DLTensor*)DV__handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)DV__handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DV_ device_type mismatch, expected ext_dev", (long long)((((DLTensor*)DV__handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(DV_ == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DV_ data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)DBeta_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)DBeta_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)DBeta_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DBeta dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_DBeta_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DBeta shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_DBeta_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1]) == ((int32_t)((int64_t*)gdn_bwd_impl_DBeta_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DBeta shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1])), (long long)(((int32_t)((int64_t*)gdn_bwd_impl_DBeta_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_55;
  if ((gdn_bwd_impl_DBeta_strides == NULL)) {
    condval_55 = 1;
  } else {
    condval_55 = ((int32_t)((int64_t*)gdn_bwd_impl_DBeta_strides)[1]);
  }
  if (!(((condval_55 == 1) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DBeta strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_56;
  if ((gdn_bwd_impl_DBeta_strides == NULL)) {
    condval_56 = 1;
  } else {
    condval_56 = ((int32_t)((int64_t*)gdn_bwd_impl_DBeta_strides)[0]);
  }
  if (!(((((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1]) == condval_56) || (((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1]) == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DBeta strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)DBeta_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DBeta byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)DBeta_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)DBeta_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DBeta device_id violates packed ABI constraint", (long long)((((DLTensor*)DBeta_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)DBeta_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DBeta device_type mismatch, expected ext_dev", (long long)((((DLTensor*)DBeta_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(DBeta == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DBeta data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)DG_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)DG_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)DG_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DG dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_DG_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DG shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_DG_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1]) == ((int32_t)((int64_t*)gdn_bwd_impl_DG_shape)[1])))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DG shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_Q_shape)[1])), (long long)(((int32_t)((int64_t*)gdn_bwd_impl_DG_shape)[1])));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_DG_shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DG shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_DG_shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_57;
  if ((gdn_bwd_impl_DG_strides == NULL)) {
    condval_57 = 1;
  } else {
    condval_57 = ((int32_t)((int64_t*)gdn_bwd_impl_DG_strides)[2]);
  }
  if (!((condval_57 == 1))) {
    int32_t condval_58;
    if ((gdn_bwd_impl_DG_strides == NULL)) {
      condval_58 = 1;
    } else {
      condval_58 = ((int32_t)((int64_t*)gdn_bwd_impl_DG_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DG strides[2] violates packed ABI constraint", (long long)(condval_58), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_59;
  if ((gdn_bwd_impl_DG_strides == NULL)) {
    condval_59 = 1;
  } else {
    condval_59 = ((int32_t)((int64_t*)gdn_bwd_impl_DG_strides)[1]);
  }
  if (!(((condval_59 == 16) || (seq == 1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DG strides[1] violates packed ABI constraint");
    return -1;
  }
  int32_t condval_60;
  if ((gdn_bwd_impl_DG_strides == NULL)) {
    condval_60 = 1;
  } else {
    condval_60 = ((int32_t)((int64_t*)gdn_bwd_impl_DG_strides)[0]);
  }
  if (!((((seq * 16) == condval_60) || (seq == 0)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DG strides[0] violates packed ABI constraint");
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)DG_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DG byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)DG_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)DG_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DG device_id violates packed ABI constraint", (long long)((((DLTensor*)DG_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)DG_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DG device_type mismatch, expected ext_dev", (long long)((((DLTensor*)DG_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((seq == 0) || !(DG == NULL)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DG data pointer is NULL");
    return -1;
  }
  if (!(((((((DLTensor*)DH0_handle)[0].dtype.code) == (uint8_t)2) && ((((DLTensor*)DH0_handle)[0].dtype.bits) == (uint8_t)32)) && ((((DLTensor*)DH0_handle)[0].dtype.lanes) == (uint16_t)1)))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DH0 dtype mismatch, expected float32");
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_DH0_shape)[0]) == 2))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DH0 shape[0] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_DH0_shape)[0])), (long long)(2));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_DH0_shape)[1]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DH0 shape[1] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_DH0_shape)[1])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!((((int32_t)((int64_t*)gdn_bwd_impl_DH0_shape)[2]) == 16))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DH0 shape[2] violates packed ABI constraint", (long long)(((int32_t)((int64_t*)gdn_bwd_impl_DH0_shape)[2])), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_61;
  if ((gdn_bwd_impl_DH0_strides == NULL)) {
    condval_61 = 1;
  } else {
    condval_61 = ((int32_t)((int64_t*)gdn_bwd_impl_DH0_strides)[2]);
  }
  if (!((condval_61 == 1))) {
    int32_t condval_62;
    if ((gdn_bwd_impl_DH0_strides == NULL)) {
      condval_62 = 1;
    } else {
      condval_62 = ((int32_t)((int64_t*)gdn_bwd_impl_DH0_strides)[2]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DH0 strides[2] violates packed ABI constraint", (long long)(condval_62), (long long)(1));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_63;
  if ((gdn_bwd_impl_DH0_strides == NULL)) {
    condval_63 = 1;
  } else {
    condval_63 = ((int32_t)((int64_t*)gdn_bwd_impl_DH0_strides)[1]);
  }
  if (!((condval_63 == 16))) {
    int32_t condval_64;
    if ((gdn_bwd_impl_DH0_strides == NULL)) {
      condval_64 = 1;
    } else {
      condval_64 = ((int32_t)((int64_t*)gdn_bwd_impl_DH0_strides)[1]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DH0 strides[1] violates packed ABI constraint", (long long)(condval_64), (long long)(16));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  int32_t condval_65;
  if ((gdn_bwd_impl_DH0_strides == NULL)) {
    condval_65 = 1;
  } else {
    condval_65 = ((int32_t)((int64_t*)gdn_bwd_impl_DH0_strides)[0]);
  }
  if (!((condval_65 == 256))) {
    int32_t condval_66;
    if ((gdn_bwd_impl_DH0_strides == NULL)) {
      condval_66 = 1;
    } else {
      condval_66 = ((int32_t)((int64_t*)gdn_bwd_impl_DH0_strides)[0]);
    }
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DH0 strides[0] violates packed ABI constraint", (long long)(condval_66), (long long)(256));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((uint64_t)0 == (((DLTensor*)DH0_handle)[0].byte_offset)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DH0 byte_offset violates packed ABI constraint", (long long)((uint64_t)0), (long long)((((DLTensor*)DH0_handle)[0].byte_offset)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)DH0_handle)[0].device.device_id) == (((DLTensor*)Q_handle)[0].device.device_id)))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DH0 device_id violates packed ABI constraint", (long long)((((DLTensor*)DH0_handle)[0].device.device_id)), (long long)((((DLTensor*)Q_handle)[0].device.device_id)));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(((((DLTensor*)DH0_handle)[0].device.device_type) == 12))) {
    char __tvm_assert_msg_buf[512];
    snprintf(__tvm_assert_msg_buf, 512, "%s; expected: %lld, got: %lld", "kernel gdn_bwd_impl input DH0 device_type mismatch, expected ext_dev", (long long)((((DLTensor*)DH0_handle)[0].device.device_type)), (long long)(12));
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", __tvm_assert_msg_buf);
    return -1;
  }
  if (!(!(DH0 == NULL))) {
    TVMFFIErrorSetRaisedFromCStr("RuntimeError", "kernel gdn_bwd_impl input DH0 data pointer is NULL");
    return -1;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = ((int64_t)12);
  (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = ((int64_t)dev_id);
  (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = (int64_t)0;
  if (__tvm_set_device_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "__tvm_set_device", &__tvm_set_device_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_1;
  result_1.type_index = kTVMFFINone;
  result_1.zero_padding = 0;
  result_1.v_int64 = 0;
  if (TVMFFIFunctionCall(__tvm_set_device_packed, (TVMFFIAny*) stack_ffi_any, 2, &result_1) != 0) {
    return -1;
  }
  if (Beta == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[0].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[0].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[0].v_ptr) = Beta;
  if (DBeta == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[1].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[1].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[1].v_ptr) = DBeta;
  if (DG == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[2].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[2].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[2].v_ptr) = DG;
  if (DH0 == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[3].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[3].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[3].v_ptr) = DH0;
  if (DKG == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[4].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[4].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[4].v_ptr) = DKG;
  if (DO == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[5].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[5].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[5].v_ptr) = DO;
  if (DQ == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[6].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[6].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[6].v_ptr) = DQ;
  if (DV_ == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[7].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[7].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[7].v_ptr) = DV_;
  if (G == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[8].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[8].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[8].v_ptr) = G;
  if (Hist == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[9].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[9].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[9].v_ptr) = Hist;
  if (K == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[10].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[10].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[10].v_ptr) = K;
  if (Q == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[11].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[11].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[11].v_ptr) = Q;
  if (V == NULL) {
    (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 0;
  } else {
    (((TVMFFIAny*)stack_ffi_any)[12].type_index) = 4;
  }
  (((TVMFFIAny*)stack_ffi_any)[12].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_int64) = 0;
  (((TVMFFIAny*)stack_ffi_any)[12].v_ptr) = V;
  (((TVMFFIAny*)stack_ffi_any)[13].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[13].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[13].v_int64) = ((int64_t)seq);
  (((TVMFFIAny*)stack_ffi_any)[14].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[14].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[14].v_int64) = ((int64_t)2);
  (((TVMFFIAny*)stack_ffi_any)[15].type_index) = 1;
  (((TVMFFIAny*)stack_ffi_any)[15].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[15].v_int64) = (int64_t)1472;
  (((TVMFFIAny*)stack_ffi_any)[16].type_index) = 0;
  (((TVMFFIAny*)stack_ffi_any)[16].zero_padding) = 0;
  (((TVMFFIAny*)stack_ffi_any)[16].v_int64) = (int64_t)0;
  if (gdn_bwd_impl_kernel_packed == NULL) {
    if (TVMBackendGetFuncFromEnv(__tvm_ffi__library_ctx, "gdn_bwd_impl_kernel", &gdn_bwd_impl_kernel_packed) != 0) {
      return -1;
    }
  }
  TVMFFIAny result_2;
  result_2.type_index = kTVMFFINone;
  result_2.zero_padding = 0;
  result_2.v_int64 = 0;
  if (TVMFFIFunctionCall(gdn_bwd_impl_kernel_packed, (TVMFFIAny*) stack_ffi_any, 16, &result_2) != 0) {
    return -1;
  }
  return 0;
}

// CodegenC: NOTE: Auto-generated entry function
#ifdef __cplusplus
extern "C"
#endif
int32_t __tvm_ffi_main(void* self, void* args,int num_args, void* result) {
  return __tvm_ffi_gdn_bwd_impl(self, args, num_args, result);
}
